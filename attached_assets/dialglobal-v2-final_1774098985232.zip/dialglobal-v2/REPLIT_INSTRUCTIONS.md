# DialGlobal v2.1 — Replit Setup Instructions

## Quick Start

1. Upload this project folder to Replit
2. In the Shell, run:
   ```
   npm install
   npm start
   ```
3. The app will open in the browser preview

## Environment Variables (.env)
Copy `.env.example` to `.env` and fill in:
```
REACT_APP_TELNYX_API_KEY=your_telnyx_key_here
REACT_APP_STRIPE_PUBLISHABLE_KEY=your_stripe_key_here
```

---

## What's New in v2.1

### ✅ Mobile-First UI
- Completely redesigned for mobile with Plus Jakarta Sans font
- Smooth spring animations throughout
- Playful micro-interactions on all buttons and cards

### ✅ Call Recording
- Toggle per number in Dashboard card (expanded view) or NumberDetail
- Legal consent notice shown when enabled
- Calls screen shows recording playback UI for voicemails

### ✅ Call Forwarding
- Toggle per number with forwarding number input field
- Available in Dashboard (expanded card) and NumberDetail

### ✅ Incoming Calls
- Full incoming call overlay (IncomingCallOverlay component)
- Simulated via green phone button on Dashboard or Calls screen
- Accept/Decline with toast feedback
- For real VoIP: integrate Telnyx JS SDK or React Native SDK

### ✅ Push Notifications
- Toggle in Settings → "Push Notifications" (controls context state)
- "VoIP Background Calls" row explains the required setup
- For production: use Firebase Cloud Messaging (FCM) + Telnyx webhooks
  - Telnyx sends webhook to your backend on incoming call
  - Backend triggers FCM push to wake the app
  - App answers via Telnyx WebRTC SDK

### ✅ Features Embedded in App (not Settings)
- Call Recording, Call Forwarding, DND toggles → inline in each number card
- eSIM, Spam Blocker, Auto-Reply, Contacts → Quick Access grid on Dashboard

### ✅ eSIM (Telnyx Wireless)
Integration path:
```
POST https://api.telnyx.com/v2/sim_cards
Authorization: Bearer YOUR_API_KEY
{ "type": "eSIM" }
```
Then provision data plans via Telnyx Wireless Data Plans API.
Plans are white-labeled — no Telnyx branding shown to users.

### ✅ Pricing Model (Telnyx Reseller)
Telnyx wholesale costs:
- ~$0.50-$1.00/number/month
- ~$0.004/min inbound, ~$0.005/min outbound
- ~$0.004/SMS inbound, ~$0.005/SMS outbound

Our plans (with ~70%+ margins):
| Plan     | Price    | Telnyx Cost (est.) | Margin |
|----------|----------|--------------------|--------|
| Free     | $0       | ~$0.80             | Loss-leader (acquisition) |
| Starter  | $4.99/mo | ~$1.40             | ~72%   |
| Pro      | $9.99/mo | ~$2.50             | ~75%   |
| Global   | $19.99/mo| ~$5.00             | ~75%   |

Annual billing (20% off) still maintains >65% margin.

---

## Telnyx Integration TODOs

### Phone Numbers
```js
// List available numbers
GET /v2/available_phone_numbers?country_code=US&limit=5

// Purchase number
POST /v2/phone_numbers
{ "phone_number": "+14155551234", "connection_id": "YOUR_SIP_CONNECTION_ID" }
```

### Calls (WebRTC)
```js
import { TelnyxRTC } from "@telnyx/webrtc";
const client = new TelnyxRTC({ login: "sip_user", password: "sip_pass" });
client.on("telnyx.notification", (n) => {
  if (n.type === "callInvite") { /* show IncomingCallOverlay */ }
});
```

### SMS
```js
POST /v2/messages
{ "from": "+14155551234", "to": "+447900112233", "text": "Hello!" }
```

### eSIM
```js
POST /v2/sim_cards
{ "type": "eSIM" }
// Then manage data plans at:
GET /v2/sim_card_data_usage_notifications
```

---

## Stripe Payments
```js
// In api.js:
export async function createCheckout(planId, billing) {
  const res = await fetch("/api/create-checkout", {
    method: "POST",
    body: JSON.stringify({ planId, billing })
  });
  const { url } = await res.json();
  window.location.href = url; // redirect to Stripe
}
```

---

## File Structure
```
src/
├── App.jsx              — Root, routing, overlays
├── context/AppContext.js — Global state
├── components/
│   ├── UI.jsx           — Shared UI components
│   └── TabBar.jsx       — Bottom navigation
├── screens/
│   ├── Dashboard.jsx    — Home (numbers + quick access)
│   ├── Calls.jsx        — Call log + recording
│   ├── Inbox.jsx        — SMS + voicemail
│   ├── Settings.jsx     — Preferences + account
│   ├── Paywall.jsx      — 4-tier pricing
│   ├── ESim.jsx         — eSIM plans via Telnyx
│   ├── NumberDetail.jsx — Per-number features
│   ├── Picker.jsx       — Buy new number
│   ├── Onboarding.jsx   — First-run flow
│   ├── Auth.jsx         — Login / signup
│   ├── Profile.jsx      — User profile
│   ├── AutoReply.jsx    — Away messages
│   ├── SpamBlocker.jsx  — Block categories
│   ├── Contacts.jsx     — Contact list
│   └── Credits.jsx      — Buy usage credits
├── data/mockData.js     — Countries, plans, mock data
└── styles/globals.css   — Design tokens + animations
```
