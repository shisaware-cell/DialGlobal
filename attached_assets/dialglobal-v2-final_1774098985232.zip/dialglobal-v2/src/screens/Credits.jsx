import React, { useState } from "react";
import { Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";

const CREDIT_PACKS = [
  { id:"c1", credits:500,  price:4.99,  bonus:null    },
  { id:"c2", credits:1200, price:9.99,  bonus:"+200"  },
  { id:"c3", credits:3000, price:19.99, bonus:"+500"  },
  { id:"c4", credits:8000, price:49.99, bonus:"+2000" },
];

export default function Credits() {
  const { goBack, credits, addCredits } = useApp();
  const [loading, setLoading] = useState(null);

  const buy = (pack) => {
    setLoading(pack.id);
    setTimeout(() => {
      addCredits(pack.credits + (pack.bonus ? parseInt(pack.bonus.slice(1)) : 0));
      setLoading(null);
    }, 1600);
  };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:"var(--bg-base)", overflow:"hidden" }}>
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
          <button onClick={goBack} style={{ background:"none", border:"none", display:"flex", padding:4, cursor:"pointer" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text-primary)" strokeWidth="2.2" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
          </button>
          <h2 style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)" }}>Credits</h2>
        </div>
        <div style={{ background:"linear-gradient(135deg,var(--accent),var(--accent-dark))",
          borderRadius:"var(--r-lg)", padding:"16px", textAlign:"center",
          boxShadow:"var(--shadow-accent)" }}>
          <div style={{ fontSize:11, fontWeight:700, color:"rgba(255,255,255,0.7)", letterSpacing:1.5, marginBottom:4 }}>AVAILABLE CREDITS</div>
          <div style={{ fontSize:40, fontWeight:800, color:"#fff", letterSpacing:"-1px" }}>{credits.toLocaleString()}</div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.7)", marginTop:2 }}>Use for extra calls & SMS beyond your plan</div>
        </div>
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:"14px 16px" }}>
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)", letterSpacing:1.6, marginBottom:10 }}>TOP UP CREDITS</div>
        {CREDIT_PACKS.map((pack, i) => (
          <div key={pack.id} className="fade-up" style={{ display:"flex", alignItems:"center",
            background:"var(--bg-surface)", borderRadius:"var(--r-lg)", padding:"14px 16px",
            marginBottom:10, border:"1px solid var(--border)", animationDelay:`${i*0.07}s`,
            boxShadow:"var(--shadow-sm)" }}>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
                <span style={{ fontSize:16, fontWeight:800, color:"var(--text-primary)" }}>
                  ⭐ {pack.credits.toLocaleString()}
                </span>
                {pack.bonus && (
                  <span style={{ fontSize:10, fontWeight:800, color:"var(--green)",
                    background:"var(--green-dim)", padding:"2px 8px", borderRadius:99 }}>
                    {pack.bonus} bonus
                  </span>
                )}
              </div>
              <div style={{ fontSize:11.5, color:"var(--text-muted)" }}>
                ~{Math.floor(pack.credits/10)} min calls or {pack.credits} SMS
              </div>
            </div>
            <button onClick={() => buy(pack)} disabled={loading===pack.id} className="press"
              style={{ height:40, padding:"0 18px", background:"var(--accent)",
                border:"none", borderRadius:"var(--r-md)", color:"var(--bg-base)",
                fontSize:13.5, fontWeight:800, cursor:"pointer",
                display:"flex", alignItems:"center", gap:8,
                boxShadow:"var(--shadow-accent)" }}>
              {loading===pack.id
                ? <Spinner size={16} color="var(--bg-base)"/>
                : `$${pack.price}`}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
