// src/screens/ESim.jsx — Real eSIM reselling via Telnyx Wireless API
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { ESIM_PLANS } from "../data/mockData";

function DataBar({ used=0, total=1 }) {
  const pct = Math.min((used/total)*100, 100);
  return (
    <div style={{width:"100%",height:6,borderRadius:3,background:"var(--bg-raised)",overflow:"hidden"}}>
      <div style={{width:`${pct}%`,height:"100%",borderRadius:3,
        background:"linear-gradient(90deg,var(--accent),var(--accent-light))",
        transition:"width 0.4s ease"}}/>
    </div>
  );
}

export default function ESim() {
  const { goBack, navigate, activeEsim, activateEsim, currentPlan } = useApp();
  const [mode, setMode]       = useState("plans"); // "plans" | "detail" | "scan" | "manual" | "activating" | "done"
  const [selected, setSelected] = useState(null);
  const [loading, setLoading]   = useState(false);
  const [qrInput, setQrInput]   = useState("");
  const [step, setStep]         = useState(1);

  const isPro = ["pro","global"].includes(currentPlan);

  const handleBuyActivate = () => {
    setLoading(true);
    setMode("activating");
    // TODO: POST /v2/sim_cards with type=esim to Telnyx API via your backend
    // Backend: telnyx.simCards.create({ type:"eSIM" }) then provision data plan
    setTimeout(() => {
      setLoading(false);
      activateEsim(selected);
      setMode("done");
    }, 3000);
  };

  if (mode === "activating") return (
    <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
      justifyContent:"center",background:"var(--bg-base)",padding:"32px",gap:20}}>
      <div style={{width:80,height:80,borderRadius:"50%",background:"var(--accent-dim)",
        display:"flex",alignItems:"center",justifyContent:"center"}}>
        <Spinner size={36} color="var(--accent)"/>
      </div>
      <div style={{textAlign:"center"}}>
        <h3 style={{fontSize:18,fontWeight:800,color:"var(--text-primary)",marginBottom:8}}>Activating eSIM…</h3>
        <p style={{fontSize:12.5,color:"var(--text-muted)",lineHeight:1.6}}>
          Provisioning your eSIM via Telnyx Wireless.<br/>This takes about 10 seconds.
        </p>
      </div>
      {[
        {label:"Purchasing profile",   done:true},
        {label:"Assigning to account", done:step>1},
        {label:"Activating coverage",  done:step>2},
      ].map((s,i)=>(
        <div key={i} style={{display:"flex",alignItems:"center",gap:10,width:"100%",maxWidth:260}}>
          <div style={{width:20,height:20,borderRadius:"50%",
            background:s.done?"var(--green)":"var(--bg-raised)",
            display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            {s.done
              ? <Ic d="M20 6L9 17l-5-5" size={10} color="#fff" sw={3}/>
              : <div style={{width:6,height:6,borderRadius:"50%",background:"var(--border-strong)"}}/>
            }
          </div>
          <span style={{fontSize:12.5,color:s.done?"var(--text-primary)":"var(--text-muted)",fontWeight:s.done?600:400}}>
            {s.label}
          </span>
        </div>
      ))}
    </div>
  );

  if (mode === "done") return (
    <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
      justifyContent:"center",background:"var(--bg-base)",padding:"32px"}}>
      <div style={{fontSize:72,marginBottom:20,animation:"pop 0.5s ease"}}>📶</div>
      <h2 style={{fontSize:24,fontWeight:800,color:"var(--text-primary)",textAlign:"center",
        marginBottom:8,letterSpacing:"-0.5px"}}>eSIM Activated!</h2>
      <p style={{fontSize:13,color:"var(--text-secondary)",textAlign:"center",lineHeight:1.7,marginBottom:24}}>
        Your eSIM is ready. Install it in your device settings under "Add Cellular Plan."
      </p>

      {/* Active plan card */}
      <div style={{width:"100%",background:"var(--bg-surface)",border:"1px solid var(--border)",
        borderRadius:"var(--r-xl)",padding:"20px",marginBottom:24}}>
        <div style={{fontSize:30,textAlign:"center",marginBottom:10}}>{selected?.emoji}</div>
        <div style={{fontSize:16,fontWeight:800,color:"var(--text-primary)",textAlign:"center",marginBottom:4}}>
          {selected?.region}
        </div>
        <div style={{fontSize:12,color:"var(--text-muted)",textAlign:"center",marginBottom:16}}>
          {selected?.data} · {selected?.days} days
        </div>
        <DataBar used={0} total={selected?.dataGB||1}/>
        <div style={{display:"flex",justifyContent:"space-between",marginTop:6}}>
          <span style={{fontSize:11,color:"var(--text-muted)"}}>0 MB used</span>
          <span style={{fontSize:11,color:"var(--text-muted)"}}>{selected?.data} remaining</span>
        </div>
        <div style={{display:"flex",justifyContent:"center",marginTop:14}}>
          <div style={{display:"inline-flex",alignItems:"center",gap:7,background:"var(--green-dim)",
            borderRadius:99,padding:"5px 14px"}}>
            <div style={{width:7,height:7,borderRadius:"50%",background:"var(--green)",
              animation:"pulse 1.5s ease infinite"}}/>
            <span style={{fontSize:12,fontWeight:700,color:"var(--green)"}}>Active · Expires {selected?.days} days</span>
          </div>
        </div>
      </div>

      {/* Install instructions */}
      <div style={{width:"100%",background:"var(--bg-raised)",borderRadius:"var(--r-md)",padding:"14px",marginBottom:24}}>
        <div style={{fontSize:11,fontWeight:800,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:10}}>HOW TO INSTALL</div>
        {[
          "Go to Settings → Cellular → Add Cellular Plan",
          "Scan the QR code sent to your email",
          "Select DialGlobal eSIM when prompted",
          "Toggle it as your data line when travelling",
        ].map((step,i)=>(
          <div key={i} style={{display:"flex",gap:10,marginBottom:i<3?8:0}}>
            <div style={{width:20,height:20,borderRadius:"50%",background:"var(--accent)",
              display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
              <span style={{fontSize:10,fontWeight:800,color:"var(--bg-base)"}}>{i+1}</span>
            </div>
            <span style={{fontSize:12,color:"var(--text-secondary)",lineHeight:1.5}}>{step}</span>
          </div>
        ))}
      </div>

      <button className="press" onClick={() => navigate("home")} style={{width:"100%",height:52,
        background:"var(--accent)",border:"none",borderRadius:"var(--r-md)",
        color:"var(--bg-base)",fontSize:15,fontWeight:800,
        boxShadow:"var(--shadow-accent)",cursor:"pointer"}}>
        Done
      </button>
    </div>
  );

  if (mode === "scan" || mode === "manual") return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={()=>setMode("plans")} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <h2 style={{fontSize:18,fontWeight:800,color:"var(--text-primary)"}}>
            {mode==="scan"?"Scan QR Code":"Enter Activation Code"}
          </h2>
        </div>
      </div>
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",padding:"32px 24px"}}>
        {mode==="scan" ? (
          <>
            <div style={{width:220,height:220,background:"var(--bg-raised)",border:"2px dashed var(--border-strong)",
              borderRadius:20,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
              marginBottom:24,gap:12}}>
              <div style={{fontSize:48}}>📷</div>
              <div style={{fontSize:13,color:"var(--text-muted)",textAlign:"center",lineHeight:1.5}}>Camera will open here<br/>on a real device</div>
            </div>
            <p style={{fontSize:13,color:"var(--text-secondary)",textAlign:"center",marginBottom:24,lineHeight:1.6}}>
              Point your camera at the QR code from your eSIM confirmation email.
            </p>
            <button onClick={()=>setMode("manual")} style={{fontSize:13,color:"var(--accent)",
              fontWeight:700,background:"none",border:"none",cursor:"pointer"}}>
              Enter code manually →
            </button>
          </>
        ) : (
          <>
            <div style={{fontSize:48,marginBottom:16}}>🔢</div>
            <p style={{fontSize:13,color:"var(--text-secondary)",textAlign:"center",marginBottom:20,lineHeight:1.6}}>
              Enter the LPA activation code from your eSIM QR
            </p>
            <input value={qrInput} onChange={e=>setQrInput(e.target.value)}
              placeholder="LPA:1$sm-v4-059.esp.t-mobile.com$ABCDEF"
              style={{width:"100%",height:48,borderRadius:"var(--r-md)",border:"1.5px solid var(--border)",
                background:"var(--bg-input)",padding:"0 14px",fontSize:12,color:"var(--text-primary)",
                outline:"none",fontFamily:"var(--font-mono)",marginBottom:16}}/>
            <button className="press" onClick={handleBuyActivate} disabled={!qrInput.trim()}
              style={{width:"100%",height:52,background:qrInput.trim()?"var(--accent)":"var(--bg-raised)",
                border:"none",borderRadius:"var(--r-md)",
                color:qrInput.trim()?"var(--bg-base)":"var(--text-muted)",
                fontSize:14,fontWeight:800,cursor:qrInput.trim()?"pointer":"default",
                boxShadow:qrInput.trim()?"var(--shadow-accent)":"none"}}>
              Activate eSIM →
            </button>
          </>
        )}
      </div>
    </div>
  );

  // Main plans view
  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      {/* Header */}
      <div style={{background:"linear-gradient(160deg,#F0EAFF 0%,var(--bg-surface) 65%)",
        padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{fontSize:20,fontWeight:800,color:"var(--text-primary)",letterSpacing:"-0.4px"}}>
              eSIM Data Plans
            </h2>
            <p style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>Powered by Telnyx Wireless · 160+ countries</p>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"14px 16px 24px"}}>
        {/* How it works */}
        <div style={{background:"var(--bg-surface)",borderRadius:"var(--r-lg)",padding:"14px",
          marginBottom:16,border:"1px solid var(--border)"}}>
          <div style={{fontSize:11,fontWeight:800,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:10}}>
            HOW eSIM WORKS
          </div>
          <div style={{display:"flex",gap:8}}>
            {[
              {emoji:"🛒",step:"Buy a plan"},
              {emoji:"📲",step:"Download profile"},
              {emoji:"✈️",step:"Travel & use"},
            ].map((s,i)=>(
              <div key={i} style={{flex:1,textAlign:"center"}}>
                <div style={{fontSize:22,marginBottom:5}}>{s.emoji}</div>
                <div style={{fontSize:10.5,fontWeight:600,color:"var(--text-secondary)"}}>{s.step}</div>
                {i<2&&<div style={{position:"relative",width:"100%",height:0}}/>}
              </div>
            ))}
          </div>
        </div>

        {/* Activate existing */}
        <div className="press row-tap" style={{background:"var(--bg-surface)",border:"1px solid var(--border)",
          borderRadius:"var(--r-lg)",padding:"14px 16px",marginBottom:16,
          display:"flex",alignItems:"center",gap:12,cursor:"pointer"}}
          onClick={() => setMode("scan")}>
          <div style={{width:42,height:42,borderRadius:12,background:"var(--accent-dim)",
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>📲</div>
          <div style={{flex:1}}>
            <div style={{fontSize:13.5,fontWeight:700,color:"var(--text-primary)"}}>Activate existing eSIM</div>
            <div style={{fontSize:11,color:"var(--text-muted)",marginTop:2}}>Scan QR or enter activation code</div>
          </div>
          <Ic d="M9 18l6-6-6-6" size={14} color="var(--text-muted)" sw={2.2}/>
        </div>

        <div style={{fontSize:11,fontWeight:800,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:10}}>
          BUY A NEW eSIM PLAN
        </div>

        {/* Telnyx integration note */}
        <div style={{background:"var(--accent-dim)",borderRadius:"var(--r-md)",padding:"10px 12px",
          marginBottom:12,display:"flex",gap:8,alignItems:"center"}}>
          <span style={{fontSize:16}}>💡</span>
          <div style={{flex:1}}>
            <div style={{fontSize:12,fontWeight:700,color:"var(--accent-dark)"}}>Telnyx White-Label eSIM</div>
            <div style={{fontSize:11,color:"var(--text-secondary)",marginTop:1,lineHeight:1.4}}>
              Plans are provisioned via Telnyx Wireless API. No physical SIM required.
            </div>
          </div>
        </div>

        {ESIM_PLANS.map((plan,i)=>{
          const isSel = selected?.id === plan.id;
          return (
            <div key={plan.id} onClick={()=>setSelected(isSel?null:plan)} className="fade-up press"
              style={{
                animationDelay:`${i*0.06}s`,
                background:isSel?"var(--bg-card)":"var(--bg-surface)",
                border:`2px solid ${isSel?"var(--accent)":"var(--border)"}`,
                borderRadius:"var(--r-lg)",padding:"14px",marginBottom:10,
                cursor:"pointer",
                boxShadow:isSel?"var(--shadow-accent)":"var(--shadow-sm)",
                position:"relative",overflow:"hidden",
              }}>
              {plan.popular && !isSel && (
                <div style={{position:"absolute",top:0,right:0,background:"var(--accent)",
                  borderRadius:"0 var(--r-lg) 0 var(--r-md)",padding:"3px 10px"}}>
                  <span style={{fontSize:9,fontWeight:800,color:"var(--bg-base)",letterSpacing:1}}>POPULAR</span>
                </div>
              )}
              <div style={{display:"flex",alignItems:"flex-start",gap:12}}>
                <div style={{width:48,height:48,borderRadius:14,
                  background:isSel?"var(--accent-dim)":"var(--bg-raised)",
                  display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0}}>
                  {plan.emoji}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:800,color:"var(--text-primary)",marginBottom:3}}>
                    {plan.region}
                  </div>
                  <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:6}}>
                    <span style={{fontSize:10.5,background:"var(--bg-raised)",borderRadius:99,
                      padding:"2px 8px",color:"var(--text-secondary)",fontWeight:600}}>📦 {plan.data}</span>
                    <span style={{fontSize:10.5,background:"var(--bg-raised)",borderRadius:99,
                      padding:"2px 8px",color:"var(--text-secondary)",fontWeight:600}}>📅 {plan.days} days</span>
                    <span style={{fontSize:10.5,background:"var(--bg-raised)",borderRadius:99,
                      padding:"2px 8px",color:"var(--text-secondary)",fontWeight:600}}>{plan.countryFlags}</span>
                  </div>
                  <div style={{fontSize:10.5,color:"var(--text-muted)"}}>{plan.perDay} average</div>
                </div>
                <div style={{textAlign:"right",flexShrink:0}}>
                  <div style={{fontSize:18,fontWeight:800,
                    color:isSel?"var(--accent)":"var(--text-primary)",
                    fontFamily:"var(--font-mono)",letterSpacing:"-0.4px"}}>${plan.price}</div>
                  {isSel&&(
                    <div style={{width:18,height:18,borderRadius:"50%",background:"var(--accent)",
                      display:"flex",alignItems:"center",justifyContent:"center",marginLeft:"auto",marginTop:4}}>
                      <Ic d="M20 6L9 17l-5-5" size={10} color="var(--bg-base)" sw={3}/>
                    </div>
                  )}
                </div>
              </div>

              {isSel && (
                <div className="fade-up" style={{marginTop:12,paddingTop:12,borderTop:"1px solid var(--border)"}}>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {plan.features.map((f,fi)=>(
                      <div key={fi} style={{display:"flex",alignItems:"center",gap:5}}>
                        <Ic d="M20 6L9 17l-5-5" size={10} color="var(--green)" sw={2.5}/>
                        <span style={{fontSize:11,color:"var(--text-secondary)"}}>{f}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Pro gate note */}
        {!isPro && (
          <div style={{background:"var(--accent-dim)",borderRadius:"var(--r-md)",padding:"12px 14px",marginBottom:8}}>
            <div style={{fontSize:12.5,fontWeight:700,color:"var(--accent-dark)",marginBottom:4}}>
              📶 eSIM included in Pro & Global plans
            </div>
            <div style={{fontSize:11.5,color:"var(--text-secondary)",lineHeight:1.5}}>
              Upgrade to Pro ($9.99/mo) for access to eSIM data plans — perfect for travelers.
            </div>
          </div>
        )}
      </div>

      {/* Bottom CTA */}
      {selected && (
        <div className="slide-up" style={{background:"var(--bg-surface)",borderTop:"1px solid var(--border)",
          padding:"14px 16px 28px",flexShrink:0}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",
            background:"var(--bg-raised)",borderRadius:"var(--r-md)",padding:"10px 14px",marginBottom:12}}>
            <div>
              <div style={{fontSize:14,fontWeight:700,color:"var(--text-primary)"}}>{selected.region}</div>
              <div style={{fontSize:11,color:"var(--text-muted)"}}>{selected.data} · {selected.days} days</div>
            </div>
            <div style={{fontSize:20,fontWeight:800,color:"var(--accent)",fontFamily:"var(--font-mono)"}}>
              ${selected.price}
            </div>
          </div>
          {!isPro ? (
            <button className="press" onClick={() => navigate("paywall")} style={{width:"100%",height:52,
              background:"var(--accent)",border:"none",borderRadius:"var(--r-md)",
              color:"var(--bg-base)",fontSize:14,fontWeight:800,
              boxShadow:"var(--shadow-accent)",cursor:"pointer",
              display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
              🔓 Upgrade to Pro to buy eSIM →
            </button>
          ) : (
            <button className="press" onClick={handleBuyActivate} style={{width:"100%",height:52,
              background:"var(--accent)",border:"none",borderRadius:"var(--r-md)",
              color:"var(--bg-base)",fontSize:14,fontWeight:800,
              boxShadow:"var(--shadow-accent)",cursor:"pointer",
              display:"flex",alignItems:"center",justifyContent:"center",gap:10}}>
              Buy & Activate eSIM →
            </button>
          )}
        </div>
      )}
    </div>
  );
}
