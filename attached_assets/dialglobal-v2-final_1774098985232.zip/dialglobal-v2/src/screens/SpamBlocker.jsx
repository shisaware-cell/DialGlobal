import React, { useState } from "react";
import { Toggle, Ic } from "../components/UI";
import { useApp } from "../context/AppContext";

const BLOCK_CATEGORIES = [
  { id:"robocalls",  emoji:"🤖", label:"Robocalls",      sub:"Auto-dialer spam calls" },
  { id:"scam",       emoji:"🎣", label:"Scam Likely",    sub:"Known fraud numbers" },
  { id:"telemarket", emoji:"📢", label:"Telemarketing",  sub:"Sales & promo calls" },
  { id:"unknown",    emoji:"❓", label:"Unknown Numbers", sub:"No caller ID" },
];

export default function SpamBlocker() {
  const { goBack, numbers } = useApp();
  const [blocks, setBlocks] = useState({ robocalls:true, scam:true, telemarket:false, unknown:false });
  const [blocked] = useState(["+1 800 555 0100", "+1 888 123 4567", "+1 900 555 9999"]);

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:"var(--bg-base)", overflow:"hidden" }}>
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={goBack} style={{ background:"none", border:"none", display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)" }}>Spam Blocker</h2>
            <p style={{ fontSize:11, color:"var(--text-muted)", marginTop:1 }}>Block unwanted calls automatically</p>
          </div>
        </div>
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:"14px 16px" }}>
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)", letterSpacing:1.6, marginBottom:8 }}>BLOCK CATEGORIES</div>
        <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)", border:"1px solid var(--border)", overflow:"hidden", marginBottom:18, boxShadow:"var(--shadow-sm)" }}>
          {BLOCK_CATEGORIES.map((cat, i, arr) => (
            <div key={cat.id} style={{ display:"flex", alignItems:"center", gap:12,
              padding:"13px 16px", borderBottom:i<arr.length-1?"1px solid var(--border)":"none" }}>
              <div style={{ width:38, height:38, borderRadius:11, background:"var(--red-dim)",
                display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>
                {cat.emoji}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:13.5, fontWeight:600, color:"var(--text-primary)" }}>{cat.label}</div>
                <div style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:1 }}>{cat.sub}</div>
              </div>
              <Toggle value={blocks[cat.id]||false} onChange={v => setBlocks(b => ({ ...b, [cat.id]:v }))}/>
            </div>
          ))}
        </div>

        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)", letterSpacing:1.6, marginBottom:8 }}>RECENTLY BLOCKED ({blocked.length})</div>
        <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)", border:"1px solid var(--border)", overflow:"hidden", boxShadow:"var(--shadow-sm)" }}>
          {blocked.map((num, i) => (
            <div key={i} style={{ display:"flex", alignItems:"center", gap:12,
              padding:"13px 16px", borderBottom:i<blocked.length-1?"1px solid var(--border)":"none" }}>
              <div style={{ width:36, height:36, borderRadius:10, background:"var(--red-dim)",
                display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>🚫</div>
              <div style={{ flex:1, fontSize:13.5, fontWeight:600, fontFamily:"var(--font-mono)",
                color:"var(--text-primary)" }}>{num}</div>
              <span style={{ fontSize:10, fontWeight:800, color:"var(--red)",
                background:"var(--red-dim)", padding:"2px 8px", borderRadius:99 }}>Blocked</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
