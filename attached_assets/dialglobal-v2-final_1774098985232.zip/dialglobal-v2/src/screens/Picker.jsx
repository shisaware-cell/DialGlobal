// src/screens/Picker.jsx — Number picker with real Telnyx flow
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { COUNTRIES, PLANS, genNumber } from "../data/mockData";

export default function Picker() {
  const { goBack, navigate, addNumber, currentPlan } = useApp();
  const [search,   setSearch]   = useState("");
  const [selected, setSelected] = useState(null);
  const [numType,  setNumType]  = useState("permanent");
  const [loading,  setLoading]  = useState(false);
  const [preview,  setPreview]  = useState(null);

  const plan      = PLANS.find(p => p.id === currentPlan);
  const maxNums   = plan?.numberLimit || 1;
  const filtered  = COUNTRIES.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.code.toLowerCase().includes(search.toLowerCase())
  );

  const pickCountry = (c) => {
    setSelected(c);
    setPreview(genNumber(c.prefix));
  };

  const confirm = () => {
    setLoading(true);
    // TODO: POST /v2/available_phone_numbers?country_code=XX to Telnyx, then purchase
    setTimeout(() => {
      addNumber({
        id:        Date.now(),
        number:    preview,
        country:   selected.name,
        flag:      selected.flag,
        type:      numType,
        calls:     0,
        sms:       0,
        plan:      plan?.name,
        missedCalls:0,
        lastActivity:"just now",
        ...(numType === "temporary" ? { expiresIn:"30 days" } : {}),
      });
      setLoading(false);
      navigate("home");
    }, 1800);
  };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden" }}>
      {/* Header */}
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px",
        borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
          <button onClick={goBack} style={{ background:"none", border:"none",
            display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <h2 style={{ fontSize:20, fontWeight:800, color:"var(--text-primary)",
            letterSpacing:"-0.4px" }}>Get a Number</h2>
        </div>
        {/* Search */}
        <div style={{ position:"relative" }}>
          <div style={{ position:"absolute", left:12, top:"50%",
            transform:"translateY(-50%)", pointerEvents:"none" }}>
            <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" size={15} color="var(--text-muted)" sw={2}/>
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search country…"
            style={{ width:"100%", height:42, borderRadius:99,
              border:"1.5px solid var(--border)", background:"var(--bg-raised)",
              padding:"0 14px 0 36px", fontSize:13.5,
              color:"var(--text-primary)", outline:"none" }}/>
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"12px 16px 120px" }}>
        {/* Popular */}
        {!search && (
          <>
            <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
              letterSpacing:1.6, marginBottom:10 }}>POPULAR</div>
            <div style={{ display:"flex", gap:8, marginBottom:18, overflowX:"auto",
              paddingBottom:4 }}>
              {COUNTRIES.filter(c => c.popular).map((c, i) => (
                <button key={c.code} className="press"
                  onClick={() => pickCountry(c)}
                  style={{ flexShrink:0, display:"flex", flexDirection:"column",
                    alignItems:"center", gap:6, padding:"12px 14px",
                    background:selected?.code===c.code?"var(--accent-dim)":"var(--bg-surface)",
                    border:`1.5px solid ${selected?.code===c.code?"var(--accent)":"var(--border)"}`,
                    borderRadius:"var(--r-md)", cursor:"pointer",
                    boxShadow:selected?.code===c.code?"var(--shadow-accent)":"var(--shadow-sm)" }}>
                  <span style={{ fontSize:26 }}>{c.flag}</span>
                  <span style={{ fontSize:10.5, fontWeight:700,
                    color:selected?.code===c.code?"var(--accent)":"var(--text-secondary)" }}>{c.code}</span>
                  <span style={{ fontSize:10, color:"var(--text-muted)",
                    fontFamily:"var(--font-mono)" }}>${c.price}/mo</span>
                </button>
              ))}
            </div>
            <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
              letterSpacing:1.6, marginBottom:10 }}>ALL COUNTRIES</div>
          </>
        )}

        {filtered.map((c, i) => (
          <div key={c.code} className="row-tap fade-up"
            onClick={() => pickCountry(c)}
            style={{ display:"flex", alignItems:"center", gap:12,
              padding:"13px 14px", background:"var(--bg-surface)",
              borderRadius:"var(--r-md)", marginBottom:8, cursor:"pointer",
              border:`1.5px solid ${selected?.code===c.code?"var(--accent)":"var(--border)"}`,
              background:selected?.code===c.code?"var(--accent-dim)":"var(--bg-surface)",
              animationDelay:`${i*0.04}s`,
              boxShadow:selected?.code===c.code?"var(--shadow-accent)":"var(--shadow-sm)" }}>
            <div style={{ width:44, height:44, borderRadius:13,
              background:"var(--bg-raised)", display:"flex",
              alignItems:"center", justifyContent:"center", fontSize:24,
              flexShrink:0 }}>{c.flag}</div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:14, fontWeight:700,
                color:selected?.code===c.code?"var(--accent)":"var(--text-primary)" }}>{c.name}</div>
              <div style={{ display:"flex", gap:8, marginTop:3 }}>
                <span style={{ fontSize:11, color:"var(--text-muted)",
                  fontFamily:"var(--font-mono)" }}>{c.prefix}</span>
                {c.instant && (
                  <span style={{ fontSize:10, fontWeight:700, color:"var(--green)",
                    background:"var(--green-dim)", padding:"1px 7px", borderRadius:99 }}>
                    ⚡ Instant
                  </span>
                )}
              </div>
            </div>
            <div style={{ textAlign:"right", flexShrink:0 }}>
              <div style={{ fontSize:15, fontWeight:800, fontFamily:"var(--font-mono)",
                color:selected?.code===c.code?"var(--accent)":"var(--text-primary)" }}>
                ${c.price}
              </div>
              <div style={{ fontSize:10, color:"var(--text-muted)" }}>/month</div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom confirm */}
      {selected && (
        <div className="slide-up" style={{ position:"absolute", bottom:0, left:0, right:0,
          background:"var(--bg-surface)", borderTop:"1px solid var(--border)",
          padding:"16px 18px 28px", boxShadow:"0 -8px 32px rgba(0,0,0,0.08)" }}>
          {/* Number preview */}
          <div style={{ background:"var(--accent-dim)", borderRadius:"var(--r-md)",
            padding:"12px 14px", marginBottom:12,
            display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:20 }}>{selected.flag}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:14, fontWeight:800, fontFamily:"var(--font-mono)",
                color:"var(--text-primary)", letterSpacing:"-0.2px" }}>{preview}</div>
              <div style={{ fontSize:11, color:"var(--text-muted)", marginTop:2 }}>
                {selected.name} · ${selected.price}/mo
              </div>
            </div>
            <button onClick={() => setPreview(genNumber(selected.prefix))}
              style={{ background:"none", border:"none", fontSize:12,
                color:"var(--accent)", fontWeight:700, cursor:"pointer" }}>
              Refresh
            </button>
          </div>

          {/* Type toggle */}
          <div style={{ display:"flex", gap:8, marginBottom:12 }}>
            {[
              { id:"permanent", label:"Permanent",  sub:"Stays until you cancel" },
              { id:"temporary", label:"Temporary",  sub:"30-day rental" },
            ].map(t => (
              <div key={t.id} onClick={() => setNumType(t.id)}
                className="press" style={{ flex:1, padding:"10px 12px",
                  background:numType===t.id?"var(--accent-dim)":"var(--bg-raised)",
                  border:`1.5px solid ${numType===t.id?"var(--accent)":"var(--border)"}`,
                  borderRadius:"var(--r-md)", cursor:"pointer",
                  boxShadow:numType===t.id?"var(--shadow-accent)":"none" }}>
                <div style={{ fontSize:12.5, fontWeight:700,
                  color:numType===t.id?"var(--accent)":"var(--text-primary)" }}>{t.label}</div>
                <div style={{ fontSize:11, color:"var(--text-muted)", marginTop:2 }}>{t.sub}</div>
              </div>
            ))}
          </div>

          <button className="press" onClick={confirm} disabled={loading}
            style={{ width:"100%", height:52, background:"var(--accent)",
              border:"none", borderRadius:"var(--r-md)",
              color:"var(--bg-base)", fontSize:15, fontWeight:800,
              display:"flex", alignItems:"center", justifyContent:"center", gap:10,
              cursor:"pointer", boxShadow:"var(--shadow-accent)" }}>
            {loading
              ? <><Spinner color="var(--bg-base)"/>Provisioning via Telnyx…</>
              : `Get ${selected.name} Number →`}
          </button>
        </div>
      )}
    </div>
  );
}
