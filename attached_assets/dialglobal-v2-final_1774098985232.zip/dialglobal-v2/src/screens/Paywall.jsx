// src/screens/Paywall.jsx — Value-based tiered pricing with Telnyx reseller margins
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { PLANS } from "../data/mockData";

const PLAN_ICONS = {free:"🎯", starter:"⚡", pro:"🔥", global:"🌍"};

export default function Paywall() {
  const { goBack, upgradePlan, currentPlan } = useApp();
  const [billing, setBilling]   = useState("monthly");
  const [selected, setSelected] = useState(currentPlan === "free" ? "starter" : currentPlan);
  const [loading, setLoading]   = useState(false);
  const [step, setStep]         = useState("plans"); // "plans" | "success"

  const activePlan = PLANS.find(p => p.id === selected);
  const price = billing === "yearly" ? activePlan.yearlyPrice : activePlan.monthlyPrice;
  const annualSave = ((activePlan.monthlyPrice - activePlan.yearlyPrice) * 12).toFixed(2);

  const handleSubscribe = () => {
    if (selected === "free" || selected === currentPlan) return;
    setLoading(true);
    setTimeout(() => {
      upgradePlan(selected, billing);
      setLoading(false);
      setStep("success");
    }, 1800);
  };

  if (step === "success") return (
    <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
      justifyContent:"center",background:"var(--bg-base)",padding:"32px"}}>
      <div style={{fontSize:72,marginBottom:20,animation:"pop 0.5s ease"}}>🎉</div>
      <h2 style={{fontSize:26,fontWeight:800,color:"var(--text-primary)",textAlign:"center",
        letterSpacing:"-0.6px",marginBottom:10}}>You're on {activePlan.name}!</h2>
      <p style={{fontSize:13.5,color:"var(--text-secondary)",textAlign:"center",lineHeight:1.7,marginBottom:32}}>
        Your plan is now active. Enjoy {activePlan.numberLimit} numbers in {typeof activePlan.countries==="string"?activePlan.countries:"3"}+ countries.
      </p>
      <button className="press" onClick={goBack} style={{width:"100%",height:52,
        background:"var(--accent)",border:"none",borderRadius:"var(--r-md)",
        color:"var(--bg-base)",fontSize:15,fontWeight:800,cursor:"pointer",
        boxShadow:"var(--shadow-accent)"}}>
        Start Exploring →
      </button>
    </div>
  );

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      {/* Header */}
      <div style={{background:"linear-gradient(160deg,#FFF6E0 0%,var(--bg-surface) 65%)",
        padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div style={{fontSize:34}}>✨</div>
          <div style={{width:28}}/>
        </div>
        <div style={{textAlign:"center",marginBottom:16}}>
          <h2 style={{fontSize:22,fontWeight:800,color:"var(--text-primary)",letterSpacing:"-0.5px"}}>
            Choose your plan
          </h2>
          <p style={{fontSize:12.5,color:"var(--text-secondary)",marginTop:4,lineHeight:1.5}}>
            Powered by Telnyx · Global coverage · Instant setup
          </p>
        </div>

        {/* Billing toggle */}
        <div style={{display:"flex",background:"var(--bg-raised)",borderRadius:"var(--r-md)",padding:3}}>
          {["monthly","yearly"].map(b=>(
            <button key={b} onClick={()=>setBilling(b)} style={{
              flex:1,height:34,borderRadius:13,border:"none",
              background:billing===b?"var(--bg-surface)":"transparent",
              color:billing===b?"var(--text-primary)":"var(--text-muted)",
              fontSize:12.5,fontWeight:billing===b?700:400,
              transition:"all 0.2s",cursor:"pointer",
              display:"flex",alignItems:"center",justifyContent:"center",gap:7,
              boxShadow:billing===b?"var(--shadow-sm)":"none",
            }}>
              {b==="yearly"?"Annual":"Monthly"}
              {b==="yearly"&&<span style={{fontSize:9,fontWeight:800,background:"var(--green)",
                color:"#fff",padding:"2px 6px",borderRadius:99}}>-20%</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Plans */}
      <div style={{flex:1,overflowY:"auto",padding:"12px 14px 0"}}>
        {PLANS.map((plan,i)=>{
          const isSel = selected === plan.id;
          const isCurr = currentPlan === plan.id;
          const dp = billing==="yearly" ? plan.yearlyPrice : plan.monthlyPrice;
          return (
            <div key={plan.id} onClick={()=>setSelected(plan.id)} className="fade-up press"
              style={{
                animationDelay:`${i*0.07}s`,
                borderRadius:"var(--r-lg)", marginBottom:10,
                border:`2px solid ${isSel?"var(--accent)":"var(--border)"}`,
                background:isSel?"var(--bg-card)":"var(--bg-surface)",
                cursor:"pointer", overflow:"hidden",
                boxShadow:isSel?"var(--shadow-accent), var(--shadow-md)":"var(--shadow-sm)",
                transition:"all 0.2s cubic-bezier(0.22,1,0.36,1)",
              }}>
              {/* Tag bar */}
              {plan.tag && (
                <div style={{height:24,background:plan.tagColor,display:"flex",alignItems:"center",
                  justifyContent:"center",gap:6}}>
                  <span style={{fontSize:9.5,fontWeight:800,letterSpacing:1.8,color:"#fff"}}>{plan.tag}</span>
                </div>
              )}

              <div style={{padding:"14px 16px"}}>
                <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:8}}>
                  <div style={{display:"flex",alignItems:"center",gap:10}}>
                    <div style={{width:38,height:38,borderRadius:11,
                      background:isSel?"var(--accent-dim)":"var(--bg-raised)",
                      display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>
                      {PLAN_ICONS[plan.id]}
                    </div>
                    <div>
                      <div style={{display:"flex",alignItems:"center",gap:6}}>
                        <span style={{fontSize:16,fontWeight:800,color:"var(--text-primary)",letterSpacing:"-0.3px"}}>
                          {plan.name}
                        </span>
                        {isCurr&&<span style={{fontSize:9,fontWeight:800,color:"var(--green)",
                          background:"var(--green-dim)",padding:"2px 7px",borderRadius:99}}>CURRENT</span>}
                      </div>
                      <div style={{fontSize:11,color:"var(--text-secondary)",marginTop:1}}>
                        {plan.numberLimit} number{plan.numberLimit>1?"s":""} · {typeof plan.countries==="string"?plan.countries+" countries":"US/UK/CA"}
                      </div>
                    </div>
                  </div>
                  <div style={{textAlign:"right",flexShrink:0}}>
                    {dp === 0 ? (
                      <div style={{fontSize:20,fontWeight:800,color:isSel?"var(--accent)":"var(--text-primary)"}}>Free</div>
                    ) : (
                      <>
                        <div style={{fontSize:20,fontWeight:800,fontFamily:"var(--font-mono)",
                          color:isSel?"var(--accent)":"var(--text-primary)",letterSpacing:"-0.4px"}}>${dp}</div>
                        <div style={{fontSize:10,color:"var(--text-muted)"}}>/month</div>
                      </>
                    )}
                    {billing==="yearly"&&dp>0&&(
                      <div style={{fontSize:9,color:"var(--green)",fontWeight:700,marginTop:2}}>
                        ${(dp*12).toFixed(0)}/yr
                      </div>
                    )}
                  </div>
                </div>

                {/* Feature list — always visible */}
                <div style={{display:"flex",flexDirection:"column",gap:4}}>
                  {plan.features.slice(0,isSel?plan.features.length:3).map((f,fi)=>(
                    <div key={fi} style={{display:"flex",alignItems:"center",gap:7}}>
                      <div style={{width:14,height:14,borderRadius:"50%",background:"var(--green-dim)",
                        display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                        <Ic d="M20 6L9 17l-5-5" size={8} color="var(--green)" sw={3}/>
                      </div>
                      <span style={{fontSize:11.5,color:"var(--text-secondary)"}}>{f}</span>
                    </div>
                  ))}
                  {!isSel && plan.features.length > 3 && (
                    <div style={{fontSize:11,color:"var(--text-muted)",marginTop:2}}>
                      +{plan.features.length-3} more features →
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* Competitor compare */}
        <div style={{background:"var(--bg-surface)",borderRadius:"var(--r-lg)",
          padding:"14px 16px",marginBottom:14,border:"1px solid var(--border)"}}>
          <div style={{fontSize:10,fontWeight:800,color:"var(--text-muted)",letterSpacing:1.6,marginBottom:10}}>HOW WE COMPARE</div>
          {[
            {name:"Hushed",     price:"$4.99",note:"US/UK/CA only"},
            {name:"Burner",     price:"$9.99",note:"US & Canada"},
            {name:"Grasshopper",price:"$26+", note:"Business only"},
            {name:"DialGlobal ✦",price:`$${billing==="yearly"?PLANS[1].yearlyPrice:PLANS[1].monthlyPrice}`,note:"60+ countries",us:true},
          ].map((c,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",
              padding:"6px 0",borderBottom:i<3?"1px solid var(--border)":"none"}}>
              <span style={{fontSize:12.5,fontWeight:c.us?800:400,color:c.us?"var(--text-primary)":"var(--text-secondary)"}}>{c.name}</span>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:11,color:"var(--text-muted)"}}>{c.note}</span>
                <span style={{fontSize:12.5,fontWeight:700,fontFamily:"var(--font-mono)",
                  color:c.us?"var(--accent)":"var(--text-secondary)"}}>{c.price}/mo</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{background:"var(--bg-surface)",borderTop:"1px solid var(--border)",
        padding:"12px 16px 24px",flexShrink:0}}>
        {billing==="yearly"&&parseFloat(annualSave)>0&&selected!=="free"&&(
          <div style={{textAlign:"center",fontSize:11.5,color:"var(--green)",fontWeight:700,
            marginBottom:10,background:"var(--green-dim)",borderRadius:99,padding:"5px 0"}}>
            🎉 You save ${annualSave} per year
          </div>
        )}
        <button className="press" onClick={handleSubscribe}
          disabled={loading || currentPlan===selected || selected==="free"}
          style={{
            width:"100%",height:52,borderRadius:"var(--r-md)",border:"none",
            background:(currentPlan===selected||selected==="free")?"var(--bg-raised)":"var(--accent)",
            color:(currentPlan===selected||selected==="free")?"var(--text-muted)":"var(--bg-base)",
            fontSize:15,fontWeight:800,cursor:"pointer",
            display:"flex",alignItems:"center",justifyContent:"center",gap:10,
            boxShadow:(currentPlan===selected||selected==="free")?"none":"var(--shadow-accent)",
          }}>
          {loading ? <><Spinner color="var(--bg-base)"/>Processing…</> :
           currentPlan===selected ? "Current plan" :
           selected==="free" ? "Free forever" :
           `Start ${activePlan.name} — $${price}/mo →`}
        </button>
        <div style={{textAlign:"center",marginTop:8,fontSize:11,color:"var(--text-muted)"}}>
          7-day free trial · Cancel anytime · Powered by Stripe
        </div>
      </div>
    </div>
  );
}
