// src/screens/Inbox.jsx — Playful messaging UI
import React, { useState, useRef } from "react";
import { Ic } from "../components/UI";
import { MOCK_MESSAGES, MOCK_CALLS } from "../data/mockData";
import { useApp } from "../context/AppContext";

const CTYPES = {
  missed:    { bg:"var(--red-dim)",    c:"var(--red)",           l:"Missed"    },
  incoming:  { bg:"var(--green-dim)",  c:"var(--green)",         l:"Incoming"  },
  outgoing:  { bg:"var(--blue-dim)",   c:"var(--blue)",          l:"Outgoing"  },
  voicemail: { bg:"var(--purple-dim)", c:"var(--purple)",        l:"Voicemail" },
  sms:       { bg:"var(--accent-dim)", c:"var(--accent)",        l:"SMS"       },
};

function Conversation({ convo, onBack }) {
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState([
    { id:1, from:"them", text:"Hey, are you free for a call tomorrow?",    time:"2:14 PM" },
    { id:2, from:"them", text:"I wanted to discuss the project timeline",  time:"2:15 PM" },
    { id:3, from:"me",   text:"Sure! I'm free after 3pm 👍",              time:"2:18 PM" },
  ]);
  const endRef = useRef(null);

  const send = () => {
    if (!input.trim()) return;
    setMsgs(p => [...p, { id:Date.now(), from:"me", text:input, time:"Now" }]);
    setInput("");
    setTimeout(() => endRef.current?.scrollIntoView({ behavior:"smooth" }), 40);
  };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
      {/* Convo header */}
      <div style={{ background:"var(--bg-surface)", padding:"12px 16px",
        borderBottom:"1px solid var(--border)",
        display:"flex", alignItems:"center", gap:11, flexShrink:0 }}>
        <button onClick={onBack} style={{ background:"none", border:"none",
          display:"flex", padding:4, cursor:"pointer" }}>
          <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
        </button>
        <div style={{ width:40, height:40, borderRadius:13,
          background:"var(--accent-dim)", display:"flex",
          alignItems:"center", justifyContent:"center", fontSize:20 }}>{convo.flag}</div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:15, fontWeight:700, color:"var(--text-primary)" }}>{convo.name}</div>
          <div style={{ fontSize:11, color:"var(--text-muted)",
            fontFamily:"var(--font-mono)" }}>{convo.number}</div>
        </div>
        <button style={{ width:38, height:38, borderRadius:11,
          background:"var(--green-dim)", border:"none",
          display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
          <Ic d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"
            size={15} color="var(--green)" sw={2.2}/>
        </button>
      </div>

      {/* Messages */}
      <div style={{ flex:1, overflowY:"auto", padding:"14px", background:"var(--bg-base)",
        display:"flex", flexDirection:"column", gap:8 }}>
        <div style={{ textAlign:"center", fontSize:11, color:"var(--text-muted)",
          marginBottom:4, fontWeight:600 }}>Today</div>
        {msgs.map(m => (
          <div key={m.id} className="fade-up"
            style={{ display:"flex", justifyContent:m.from==="me"?"flex-end":"flex-start" }}>
            <div style={{
              maxWidth:"78%", padding:"10px 14px",
              borderRadius:m.from==="me"?"18px 18px 4px 18px":"18px 18px 18px 4px",
              background:m.from==="me"?"var(--accent)":"var(--bg-surface)",
              color:m.from==="me"?"var(--bg-base)":"var(--text-primary)",
              fontSize:14, lineHeight:1.55,
              border:m.from==="me"?"none":"1px solid var(--border)",
              boxShadow:m.from==="me"?"var(--shadow-accent)":"var(--shadow-sm)",
            }}>
              {m.text}
              <div style={{ fontSize:9.5, marginTop:4, textAlign:"right",
                color:m.from==="me"?"rgba(0,0,0,0.3)":"var(--text-muted)" }}>{m.time}</div>
            </div>
          </div>
        ))}
        <div ref={endRef}/>
      </div>

      {/* Input */}
      <div style={{ background:"var(--bg-surface)", borderTop:"1px solid var(--border)",
        padding:"10px 12px", display:"flex", gap:9, alignItems:"center", flexShrink:0 }}>
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key==="Enter" && send()}
          placeholder="Message…"
          style={{ flex:1, height:44, borderRadius:99,
            border:"1.5px solid var(--border)", background:"var(--bg-input)",
            padding:"0 18px", fontSize:14, color:"var(--text-primary)", outline:"none" }}/>
        <button className="press" onClick={send} style={{
          width:44, height:44, borderRadius:"50%",
          background:"var(--accent)", border:"none",
          display:"flex", alignItems:"center", justifyContent:"center",
          flexShrink:0, boxShadow:"var(--shadow-accent)",
          cursor:"pointer" }}>
          <Ic d="M22 2L11 13M22 2L15 22l-4-9-9-4 19-7z" size={16} color="var(--bg-base)" sw={2.3}/>
        </button>
      </div>
    </div>
  );
}

export default function Inbox({ defaultTab="messages" }) {
  const { navigate } = useApp();
  const [tab, setTab]         = useState(defaultTab);
  const [convo, setConvo]     = useState(null);
  const [search, setSearch]   = useState("");

  if (convo) return <Conversation convo={convo} onBack={() => setConvo(null)}/>;

  const filtered = MOCK_MESSAGES.filter(m =>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.number.includes(search)
  );

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
      {/* Header */}
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 0",
        borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", justifyContent:"space-between",
          alignItems:"center", marginBottom:12 }}>
          <h2 style={{ fontSize:22, fontWeight:800, color:"var(--text-primary)",
            letterSpacing:"-0.5px" }}>Inbox</h2>
          <button onClick={() => navigate("contacts")} style={{
            width:36, height:36, borderRadius:11,
            background:"var(--bg-raised)", border:"1px solid var(--border)",
            display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
            <Ic d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM19 8v6M22 11h-6" size={15} color="var(--text-secondary)" sw={2}/>
          </button>
        </div>

        {/* Search */}
        <div style={{ position:"relative", marginBottom:10 }}>
          <div style={{ position:"absolute", left:12, top:"50%",
            transform:"translateY(-50%)", pointerEvents:"none" }}>
            <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" size={15} color="var(--text-muted)" sw={2}/>
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search messages…"
            style={{ width:"100%", height:38, borderRadius:99,
              border:"1.5px solid var(--border)", background:"var(--bg-raised)",
              padding:"0 14px 0 36px", fontSize:13,
              color:"var(--text-primary)", outline:"none" }}/>
        </div>

        {/* Tabs */}
        <div style={{ display:"flex", gap:0 }}>
          {[{ id:"messages", l:"Messages" }, { id:"voicemail", l:"Voicemail" }].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              flex:1, height:36, background:"none", border:"none",
              borderBottom:`2.5px solid ${tab===t.id?"var(--accent)":"transparent"}`,
              color:tab===t.id?"var(--accent)":"var(--text-muted)",
              fontSize:13, fontWeight:tab===t.id?700:500,
              cursor:"pointer", transition:"all 0.2s" }}>{t.l}</button>
          ))}
        </div>
      </div>

      {/* List */}
      <div style={{ flex:1, overflowY:"auto", background:"var(--bg-base)" }}>
        {tab === "messages" ? (
          filtered.length === 0 ? (
            <div style={{ textAlign:"center", padding:"50px 20px" }}>
              <div style={{ fontSize:40, marginBottom:12 }}>💬</div>
              <div style={{ fontSize:14, fontWeight:700, color:"var(--text-muted)" }}>No messages</div>
            </div>
          ) : filtered.map((m, i) => (
            <div key={m.id} className="row-tap fade-up"
              onClick={() => setConvo(m)}
              style={{ display:"flex", alignItems:"center", padding:"13px 16px",
                gap:12, background:"var(--bg-surface)",
                borderBottom:"1px solid var(--border)",
                cursor:"pointer", animationDelay:`${i*0.05}s` }}>
              <div style={{ width:48, height:48, borderRadius:15,
                background:CTYPES[m.type]?.bg||"var(--accent-dim)",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:22, flexShrink:0, position:"relative" }}>
                {m.flag}
                {m.unread > 0 && (
                  <div style={{ position:"absolute", top:-2, right:-2,
                    minWidth:18, height:18, borderRadius:99,
                    background:"var(--red)", border:"2px solid var(--bg-surface)",
                    display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <span style={{ fontSize:9, fontWeight:800, color:"#fff" }}>{m.unread}</span>
                  </div>
                )}
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:"flex", justifyContent:"space-between",
                  alignItems:"center", marginBottom:3 }}>
                  <span style={{ fontSize:14, fontWeight:m.unread>0?800:600,
                    color:"var(--text-primary)" }}>{m.name}</span>
                  <span style={{ fontSize:11, color:"var(--text-muted)",
                    flexShrink:0 }}>{m.time}</span>
                </div>
                <div style={{ fontSize:12.5, color:m.unread>0?"var(--text-secondary)":"var(--text-muted)",
                  fontWeight:m.unread>0?600:400, overflow:"hidden",
                  textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{m.preview}</div>
              </div>
            </div>
          ))
        ) : (
          <div>
            {MOCK_CALLS.filter(c => c.type === "voicemail").map((v, i) => (
              <div key={v.id} className="row-tap fade-up"
                style={{ display:"flex", alignItems:"center", padding:"14px 16px",
                  gap:12, background:"var(--bg-surface)",
                  borderBottom:"1px solid var(--border)",
                  cursor:"pointer", animationDelay:`${i*0.06}s` }}>
                <div style={{ width:48, height:48, borderRadius:15,
                  background:"var(--purple-dim)",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontSize:22, flexShrink:0 }}>{v.flag}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14, fontWeight:700, color:"var(--text-primary)",
                    marginBottom:3 }}>{v.name}</div>
                  <div style={{ fontSize:12, color:"var(--text-muted)",
                    fontFamily:"var(--font-mono)" }}>Voicemail · {v.duration}</div>
                </div>
                <div style={{ display:"flex", flexDirection:"column",
                  alignItems:"flex-end", gap:6 }}>
                  <span style={{ fontSize:11, color:"var(--text-muted)" }}>{v.time}</span>
                  <button style={{ width:32, height:32, borderRadius:"50%",
                    background:"var(--purple-dim)", border:"none",
                    display:"flex", alignItems:"center", justifyContent:"center",
                    cursor:"pointer" }}>
                    <Ic d="M5 3l14 9-14 9V3z" size={12} color="var(--purple)" sw={2.5} fill="var(--purple)"/>
                  </button>
                </div>
              </div>
            ))}
            {MOCK_CALLS.filter(c => c.type==="voicemail").length === 0 && (
              <div style={{ textAlign:"center", padding:"50px 20px" }}>
                <div style={{ fontSize:40, marginBottom:12 }}>📭</div>
                <div style={{ fontSize:14, fontWeight:700, color:"var(--text-muted)" }}>No voicemails</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
