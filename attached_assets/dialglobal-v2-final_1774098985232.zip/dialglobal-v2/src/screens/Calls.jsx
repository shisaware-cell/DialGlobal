// src/screens/Calls.jsx — Enhanced with call recording playback & forwarding UI
import React, { useState } from "react";
import { Ic } from "../components/UI";
import { MOCK_CALLS } from "../data/mockData";
import { useApp } from "../context/AppContext";

const TYPES = {
  missed:    { bg:"var(--red-dim)",    c:"var(--red)",           l:"Missed",    icon:"M23 23L1 1" },
  incoming:  { bg:"var(--green-dim)",  c:"var(--green)",         l:"Incoming",  icon:"M22 16.92v3a2 2 0 01-2.18 2" },
  outgoing:  { bg:"var(--blue-dim)",   c:"var(--blue)",          l:"Outgoing",  icon:"M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4" },
  voicemail: { bg:"var(--purple-dim)", c:"var(--purple)",        l:"Voicemail", icon:"M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4" },
};

function CallRow({ cl, onLongPress }) {
  const { recordings } = useApp();
  const cv = TYPES[cl.type] || TYPES.outgoing;
  const [showActions, setShowActions] = useState(false);
  const [playing, setPlaying] = useState(false);

  return (
    <div className="fade-up" style={{ background:"var(--bg-surface)", marginBottom:1 }}>
      <div className="row-tap" onClick={() => setShowActions(o => !o)}
        style={{ display:"flex", alignItems:"center", padding:"13px 18px",
          gap:12, borderBottom:"1px solid var(--border)", cursor:"pointer" }}>
        {/* Avatar */}
        <div style={{ width:46, height:46, borderRadius:14, background:cv.bg,
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:18, flexShrink:0, fontWeight:700, color:cv.c,
          boxShadow:`inset 0 1px 3px rgba(0,0,0,0.05)` }}>
          {cl.flag}
        </div>

        <div style={{ flex:1 }}>
          <div style={{ fontSize:14, fontWeight:700,
            color:cl.type==="missed"?"var(--red)":"var(--text-primary)",
            marginBottom:3, letterSpacing:"-0.2px" }}>{cl.name}</div>
          <div style={{ display:"flex", alignItems:"center", gap:6 }}>
            <span style={{ fontSize:11, color:"var(--text-muted)",
              fontFamily:"var(--font-mono)" }}>{cl.number}</span>
            {cl.duration && <>
              <span style={{ width:3, height:3, borderRadius:"50%",
                background:"var(--border-strong)", display:"inline-block" }}/>
              <span style={{ fontSize:11, color:"var(--text-muted)",
                fontFamily:"var(--font-mono)" }}>{cl.duration}</span>
            </>}
          </div>
        </div>

        <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:5 }}>
          <span style={{ fontSize:11, color:"var(--text-muted)" }}>{cl.time}</span>
          <div style={{ display:"flex", alignItems:"center", gap:5 }}>
            <span style={{ fontSize:9.5, fontWeight:700, padding:"2px 8px",
              borderRadius:99, background:cv.bg, color:cv.c }}>{cv.l}</span>
            {cl.type === "voicemail" && (
              <div style={{ width:16, height:16, borderRadius:"50%",
                background:"var(--purple-dim)", display:"flex",
                alignItems:"center", justifyContent:"center" }}>
                <Ic d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4" size={9} color="var(--purple)" sw={2.5}/>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Expanded actions */}
      {showActions && (
        <div className="fade-up" style={{ background:"var(--bg-raised)",
          borderBottom:"1px solid var(--border)", padding:"10px 18px" }}>
          {cl.type === "voicemail" ? (
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <button onClick={() => setPlaying(p => !p)} className="press" style={{
                display:"flex", alignItems:"center", gap:8, height:38,
                padding:"0 16px", background:"var(--purple-dim)",
                border:"1px solid rgba(124,58,237,0.2)", borderRadius:99,
                color:"var(--purple)", fontSize:12.5, fontWeight:700, cursor:"pointer" }}>
                <Ic d={playing?"M10 9h4v6h-4zM6 19V5l15 7z":"M5 3l14 9-14 9V3z"} size={13} color="var(--purple)" sw={2.5}/>
                {playing ? "Pause" : "Play Voicemail"}
              </button>
              {playing && (
                <div style={{ flex:1, height:4, borderRadius:2, background:"var(--bg-hover)",
                  overflow:"hidden" }}>
                  <div style={{ width:"35%", height:"100%", background:"var(--purple)",
                    borderRadius:2, animation:"shine 1.2s linear infinite",
                    background:"linear-gradient(90deg,var(--purple-dim),var(--purple),var(--purple-dim))",
                    backgroundSize:"200% 100%" }}/>
                </div>
              )}
              <span style={{ fontSize:11, color:"var(--text-muted)",
                fontFamily:"var(--font-mono)" }}>{cl.duration}</span>
            </div>
          ) : (
            <div style={{ display:"flex", gap:8 }}>
              {[
                { icon:"M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z",
                  label:"Call Back", accent:true },
                { icon:"M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z",
                  label:"Message" },
                { icon:"M17 1l4 4-4 4M3 11V9a4 4 0 014-4h14",
                  label:"Forward" },
              ].map((a, i) => (
                <button key={i} className="press" style={{
                  flex:1, height:38, background:a.accent?"var(--accent)":"var(--bg-surface)",
                  border:a.accent?"none":"1px solid var(--border)",
                  borderRadius:"var(--r-sm)", display:"flex", alignItems:"center",
                  justifyContent:"center", gap:5,
                  color:a.accent?"var(--bg-base)":"var(--text-secondary)",
                  fontSize:11, fontWeight:700, cursor:"pointer",
                  boxShadow:a.accent?"var(--shadow-accent)":"none" }}>
                  <Ic d={a.icon} size={13} color={a.accent?"var(--bg-base)":"var(--text-secondary)"} sw={2.2}/>
                  {a.label}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function Calls() {
  const { simulateIncomingCall } = useApp();
  const [filter, setFilter] = useState("all");
  const list = filter === "all" ? MOCK_CALLS : MOCK_CALLS.filter(c => c.type === filter);
  const missedCount = MOCK_CALLS.filter(c => c.type === "missed").length;

  const filters = [
    { id:"all",      l:"All" },
    { id:"missed",   l:"Missed",   badge:missedCount },
    { id:"incoming", l:"Incoming" },
    { id:"outgoing", l:"Outgoing" },
    { id:"voicemail",l:"Voicemail"},
  ];

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
      {/* Header */}
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 0",
        borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", justifyContent:"space-between",
          alignItems:"center", marginBottom:12 }}>
          <h2 style={{ fontSize:22, fontWeight:800, color:"var(--text-primary)",
            letterSpacing:"-0.5px" }}>Calls</h2>
          <button onClick={simulateIncomingCall} className="press" style={{
            display:"flex", alignItems:"center", gap:6, height:34,
            padding:"0 12px", background:"var(--green-dim)",
            border:"1px solid rgba(24,168,90,0.2)", borderRadius:99,
            color:"var(--green)", fontSize:11.5, fontWeight:700, cursor:"pointer" }}>
            <div style={{ width:7, height:7, borderRadius:"50%", background:"var(--green)",
              animation:"pulse 1.5s ease infinite" }}/>
            Simulate Call
          </button>
        </div>
        <div style={{ display:"flex", gap:6, paddingBottom:12, overflowX:"auto" }}>
          {filters.map(f => (
            <button key={f.id} onClick={() => setFilter(f.id)} style={{
              flexShrink:0, height:30, padding:"0 13px", borderRadius:99,
              border:`1.5px solid ${filter===f.id?"var(--accent)":"var(--border)"}`,
              background:filter===f.id?"var(--accent-dim)":"transparent",
              color:filter===f.id?"var(--accent)":"var(--text-muted)",
              fontSize:12, fontWeight:filter===f.id?700:500,
              transition:"all 0.15s", cursor:"pointer",
              display:"flex", alignItems:"center", gap:5 }}>
              {f.l}
              {f.badge > 0 && (
                <span style={{ width:16, height:16, borderRadius:"50%",
                  background:"var(--red)", color:"#fff",
                  fontSize:9, fontWeight:800,
                  display:"flex", alignItems:"center", justifyContent:"center" }}>
                  {f.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", background:"var(--bg-base)" }}>
        {/* Call recording notice */}
        <div style={{ margin:"12px 16px 4px", padding:"10px 14px",
          background:"var(--accent-dim)", borderRadius:"var(--r-md)",
          display:"flex", alignItems:"center", gap:10 }}>
          <Ic d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4M12 11V3" size={16} color="var(--accent)" sw={2}/>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:12, fontWeight:700, color:"var(--accent-dark)" }}>
              Call Recording Available
            </div>
            <div style={{ fontSize:11, color:"var(--text-secondary)", marginTop:1 }}>
              Enable per-number in your number settings below
            </div>
          </div>
        </div>

        {list.length === 0 && (
          <div style={{ textAlign:"center", padding:"50px 20px" }}>
            <div style={{ fontSize:40, marginBottom:12 }}>📵</div>
            <div style={{ fontSize:14, fontWeight:700, color:"var(--text-muted)" }}>No calls found</div>
          </div>
        )}
        {list.map((cl, i) => <CallRow key={cl.id} cl={cl}/>)}
      </div>
    </div>
  );
}
