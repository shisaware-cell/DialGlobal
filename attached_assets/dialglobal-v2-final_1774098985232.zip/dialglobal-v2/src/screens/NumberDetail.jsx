// src/screens/NumberDetail.jsx — Full feature panel per number
import React, { useState } from "react";
import { Ic, Toggle, DeleteSheet } from "../components/UI";
import { useApp } from "../context/AppContext";
import { MOCK_CALLS } from "../data/mockData";

export default function NumberDetail() {
  const { goBack, navigate, selectedNumber, removeNumber,
          recordings, toggleRecording,
          forwarding, toggleForwarding,
          forwardingNums, setForwardingNum,
          spamEnabled, toggleSpam,
          dndNumbers, toggleDnd } = useApp();
  const num = selectedNumber;

  const [voicemail,    setVoicemail]    = useState(true);
  const [fwdNum,       setFwdNum]       = useState(forwardingNums[num?.id] || "");
  const [showDelete,   setShowDelete]   = useState(false);
  const [recordNotice, setRecordNotice] = useState(false);

  if (!num) { navigate("home"); return null; }

  const callColors = { missed:"var(--red)", incoming:"var(--green)", outgoing:"var(--blue)", voicemail:"var(--purple)" };
  const callBgs    = { missed:"var(--red-dim)", incoming:"var(--green-dim)", outgoing:"var(--blue-dim)", voicemail:"var(--purple-dim)" };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden", position:"relative" }}>

      {/* Header */}
      <div style={{ background:"linear-gradient(160deg,var(--bg-surface) 60%,var(--bg-raised) 100%)",
        padding:"10px 18px 18px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16 }}>
          <button onClick={goBack} style={{ background:"none", border:"none",
            display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <h2 style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)",
            letterSpacing:"-0.3px" }}>Number Details</h2>
        </div>

        {/* Number hero */}
        <div style={{ display:"flex", alignItems:"center", gap:14 }}>
          <div style={{ width:56, height:56, borderRadius:18,
            background:"var(--bg-raised)", display:"flex", alignItems:"center",
            justifyContent:"center", fontSize:28, flexShrink:0,
            boxShadow:"var(--shadow-md)" }}>{num.flag}</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:17, fontWeight:800, color:"var(--text-primary)",
              letterSpacing:"-0.4px", fontFamily:"var(--font-mono)" }}>{num.number}</div>
            <div style={{ fontSize:12.5, color:"var(--text-secondary)", marginTop:2 }}>{num.country}</div>
          </div>
          <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:5 }}>
            <span style={{ fontSize:10, fontWeight:800, padding:"3px 10px", borderRadius:99,
              color:num.type==="permanent"?"var(--accent)":"var(--green)",
              background:num.type==="permanent"?"var(--accent-dim)":"var(--green-dim)" }}>
              {num.type==="permanent" ? "Permanent" : `⏱ ${num.expiresIn}`}
            </span>
            <div style={{ display:"flex", alignItems:"center", gap:5 }}>
              <div style={{ width:7, height:7, borderRadius:"50%", background:"var(--green)",
                animation:"pulse 2s ease infinite" }}/>
              <span style={{ fontSize:11, color:"var(--green)", fontWeight:700 }}>Active</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display:"flex", gap:8, marginTop:14 }}>
          {[
            { label:"Calls",    value:num.calls,         color:"var(--accent)" },
            { label:"Messages", value:num.sms,           color:"var(--green)"  },
            { label:"Last seen",value:num.lastActivity,  color:"var(--blue)"   },
          ].map((s, i) => (
            <div key={i} style={{ flex:1, background:"var(--bg-raised)",
              borderRadius:"var(--r-md)", padding:"10px 8px", textAlign:"center" }}>
              <div style={{ fontSize:18, fontWeight:800, color:s.color,
                letterSpacing:"-0.4px", fontFamily:"var(--font-mono)" }}>{s.value}</div>
              <div style={{ fontSize:9.5, color:"var(--text-muted)", marginTop:1,
                fontWeight:600 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"14px 16px 28px" }}>
        {/* Quick actions */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10, marginBottom:18 }}>
          {[
            { emoji:"📞", label:"Call",    accent:true  },
            { emoji:"💬", label:"Message", onClick:() => navigate("inbox") },
            { emoji:"📤", label:"Share"   },
          ].map((a, i) => (
            <button key={i} className="press" onClick={a.onClick} style={{
              height:66, background:a.accent?"var(--accent)":"var(--bg-surface)",
              border:a.accent?"none":"1px solid var(--border)",
              borderRadius:"var(--r-lg)", display:"flex", flexDirection:"column",
              alignItems:"center", justifyContent:"center", gap:6,
              cursor:"pointer", boxShadow:a.accent?"var(--shadow-accent)":"var(--shadow-sm)" }}>
              <span style={{ fontSize:22 }}>{a.emoji}</span>
              <span style={{ fontSize:11, fontWeight:700,
                color:a.accent?"var(--bg-base)":"var(--text-secondary)" }}>{a.label}</span>
            </button>
          ))}
        </div>

        {/* Features */}
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
          letterSpacing:1.6, marginBottom:8 }}>NUMBER FEATURES</div>
        <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
          border:"1px solid var(--border)", overflow:"hidden",
          marginBottom:18, boxShadow:"var(--shadow-sm)" }}>
          {[
            {
              emoji:"📼", label:"Call Recording",
              sub:"Auto-save all calls to this number",
              value:recordings[num.id]||false,
              toggle:() => { toggleRecording(num.id); setRecordNotice(true); },
            },
            {
              emoji:"↪️", label:"Call Forwarding",
              sub:forwarding[num.id] ? `→ ${forwardingNums[num.id]||"Set number below"}` : "Route calls to another number",
              value:forwarding[num.id]||false,
              toggle:() => toggleForwarding(num.id),
            },
            {
              emoji:"📬", label:"Voicemail",
              sub:"Record & transcribe missed calls",
              value:voicemail,
              toggle:() => setVoicemail(v => !v),
            },
            {
              emoji:"🚫", label:"Spam Blocker",
              sub:"Auto-block robocalls & spam",
              value:spamEnabled[num.id]||false,
              toggle:() => toggleSpam(num.id),
            },
            {
              emoji:"🔕", label:"Do Not Disturb",
              sub:"Silence incoming calls & texts",
              value:dndNumbers[num.id]||false,
              toggle:() => toggleDnd(num.id),
              last:true,
            },
          ].map((row, i, arr) => (
            <div key={i}>
              <div style={{ display:"flex", alignItems:"center", gap:12,
                padding:"13px 16px",
                borderBottom:row.last?"none":"1px solid var(--border)" }}>
                <div style={{ width:36, height:36, borderRadius:10,
                  background:"var(--bg-raised)", display:"flex",
                  alignItems:"center", justifyContent:"center",
                  fontSize:18, flexShrink:0 }}>{row.emoji}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13.5, fontWeight:600,
                    color:"var(--text-primary)" }}>{row.label}</div>
                  <div style={{ fontSize:11.5, color:"var(--text-muted)",
                    marginTop:1 }}>{row.sub}</div>
                </div>
                <Toggle value={row.value} onChange={row.toggle}/>
              </div>
              {/* Call forwarding number input */}
              {row.label==="Call Forwarding" && (forwarding[num.id]||false) && (
                <div style={{ padding:"0 16px 12px", background:"var(--bg-raised)",
                  borderBottom:"1px solid var(--border)" }}>
                  <input value={fwdNum}
                    onChange={e => { setFwdNum(e.target.value); setForwardingNum(num.id, e.target.value); }}
                    placeholder="+1 (555) 000-0000  —  forward calls to this number"
                    style={{ width:"100%", height:44, borderRadius:"var(--r-sm)",
                      border:"1.5px solid var(--border)", background:"var(--bg-input)",
                      padding:"0 14px", fontSize:12.5, color:"var(--text-primary)",
                      outline:"none", fontFamily:"var(--font-mono)" }}/>
                </div>
              )}
            </div>
          ))}
        </div>

        {recordNotice && recordings[num.id] && (
          <div className="fade-up" style={{ background:"var(--accent-dim)",
            borderRadius:"var(--r-md)", padding:"10px 14px",
            marginBottom:14, display:"flex", gap:8, alignItems:"flex-start" }}>
            <span style={{ fontSize:16 }}>⚠️</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12, fontWeight:700, color:"var(--accent-dark)" }}>Legal notice</div>
              <div style={{ fontSize:11.5, color:"var(--text-secondary)", marginTop:2, lineHeight:1.5 }}>
                Recording laws vary by jurisdiction. You may be required to notify the other party.
                Please check local laws before enabling.
              </div>
            </div>
          </div>
        )}

        {/* Auto-reply shortcut */}
        <div className="press row-tap" onClick={() => navigate("autoreply")}
          style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
            padding:"14px 16px", marginBottom:18, cursor:"pointer",
            border:"1px solid var(--border)", display:"flex",
            alignItems:"center", gap:12, boxShadow:"var(--shadow-sm)" }}>
          <div style={{ width:40, height:40, borderRadius:12,
            background:"var(--green-dim)", display:"flex",
            alignItems:"center", justifyContent:"center", fontSize:20 }}>💬</div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13.5, fontWeight:700, color:"var(--text-primary)" }}>Auto-Reply</div>
            <div style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:1 }}>
              Set custom away messages for this number
            </div>
          </div>
          <Ic d="M9 18l6-6-6-6" size={14} color="var(--text-muted)" sw={2.2}/>
        </div>

        {/* Recent calls */}
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
          letterSpacing:1.6, marginBottom:8 }}>RECENT CALLS</div>
        <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
          border:"1px solid var(--border)", overflow:"hidden",
          marginBottom:18, boxShadow:"var(--shadow-sm)" }}>
          {MOCK_CALLS.slice(0, 3).map((cl, i) => (
            <div key={cl.id} style={{ display:"flex", alignItems:"center",
              gap:10, padding:"12px 14px",
              borderBottom:i < 2 ? "1px solid var(--border)" : "none" }}>
              <div style={{ width:36, height:36, borderRadius:10,
                background:callBgs[cl.type]||callBgs.outgoing,
                display:"flex", alignItems:"center", justifyContent:"center" }}>
                <Ic d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"
                  size={14} color={callColors[cl.type]||callColors.outgoing} sw={2}/>
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:13, fontWeight:600,
                  color:cl.type==="missed"?"var(--red)":"var(--text-primary)" }}>{cl.name}</div>
                <div style={{ fontSize:10.5, color:"var(--text-muted)",
                  fontFamily:"var(--font-mono)" }}>{cl.number}</div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:11, color:"var(--text-muted)" }}>{cl.time}</div>
                {cl.duration && (
                  <div style={{ fontSize:10.5, color:"var(--text-secondary)",
                    fontFamily:"var(--font-mono)", marginTop:2 }}>{cl.duration}</div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Danger */}
        <div style={{ background:"var(--red-dim)", border:"1px solid rgba(224,53,53,0.15)",
          borderRadius:"var(--r-lg)", padding:"14px 16px",
          display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div>
            <div style={{ fontSize:13.5, fontWeight:700, color:"var(--red)" }}>Release Number</div>
            <div style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:2 }}>
              Permanently remove this number
            </div>
          </div>
          <button className="press" onClick={() => setShowDelete(true)}
            style={{ height:36, padding:"0 16px", background:"var(--red)",
              border:"none", borderRadius:"var(--r-sm)",
              color:"white", fontSize:12.5, fontWeight:700, cursor:"pointer" }}>
            Release
          </button>
        </div>
      </div>

      {showDelete && (
        <DeleteSheet
          title="Release this number?"
          body={`${num.number} will be permanently deleted and returned to the pool.`}
          confirmLabel="Yes, release"
          onClose={() => setShowDelete(false)}
          onConfirm={() => { removeNumber(num.id); setShowDelete(false); navigate("home"); }}
        />
      )}
    </div>
  );
}
