import React, { useState } from "react";
import { Ic } from "../components/UI";
import { useApp } from "../context/AppContext";

const MOCK_CONTACTS = [
  { id:1, name:"Marcus Webb",   phone:"+1 917 555 0134", flag:"🇺🇸", initial:"M" },
  { id:2, name:"Priya Sharma",  phone:"+44 7900 112233", flag:"🇬🇧", initial:"P" },
  { id:3, name:"David Chen",    phone:"+61 4 1234 5678", flag:"🇦🇺", initial:"D" },
  { id:4, name:"Sarah Miller",  phone:"+49 30 1234567",  flag:"🇩🇪", initial:"S" },
];

export default function Contacts() {
  const { goBack } = useApp();
  const [search, setSearch] = useState("");
  const filtered = MOCK_CONTACTS.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:"var(--bg-base)", overflow:"hidden" }}>
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:12 }}>
          <button onClick={goBack} style={{ background:"none", border:"none", display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <h2 style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)" }}>Contacts</h2>
        </div>
        <div style={{ position:"relative" }}>
          <div style={{ position:"absolute", left:12, top:"50%", transform:"translateY(-50%)", pointerEvents:"none" }}>
            <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" size={15} color="var(--text-muted)" sw={2}/>
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search contacts…"
            style={{ width:"100%", height:40, borderRadius:99, border:"1.5px solid var(--border)",
              background:"var(--bg-raised)", padding:"0 14px 0 36px", fontSize:13,
              color:"var(--text-primary)", outline:"none" }}/>
        </div>
      </div>
      <div style={{ flex:1, overflowY:"auto", background:"var(--bg-base)" }}>
        {filtered.map((c, i) => (
          <div key={c.id} className="row-tap fade-up" style={{ display:"flex", alignItems:"center",
            gap:12, padding:"13px 16px", background:"var(--bg-surface)",
            borderBottom:"1px solid var(--border)", cursor:"pointer", animationDelay:`${i*0.05}s` }}>
            <div style={{ width:46, height:46, borderRadius:14,
              background:"var(--accent-dim)", display:"flex", alignItems:"center",
              justifyContent:"center", fontSize:18, fontWeight:800,
              color:"var(--accent)", flexShrink:0 }}>{c.initial}</div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:14, fontWeight:700, color:"var(--text-primary)" }}>{c.name}</div>
              <div style={{ fontSize:11.5, color:"var(--text-muted)", fontFamily:"var(--font-mono)", marginTop:2 }}>
                {c.flag} {c.phone}
              </div>
            </div>
            <div style={{ display:"flex", gap:8 }}>
              <button style={{ width:34, height:34, borderRadius:10, background:"var(--green-dim)",
                border:"none", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
                <Ic d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" size={14} color="var(--green)" sw={2}/>
              </button>
              <button style={{ width:34, height:34, borderRadius:10, background:"var(--accent-dim)",
                border:"none", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
                <Ic d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" size={14} color="var(--accent)" sw={2}/>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
