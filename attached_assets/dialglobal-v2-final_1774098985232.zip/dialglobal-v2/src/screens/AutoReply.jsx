import React, { useState } from "react";
import { Ic, Toggle } from "../components/UI";
import { useApp } from "../context/AppContext";

const TEMPLATES = [
  "I'm currently unavailable. I'll get back to you shortly.",
  "Hi! I'm driving right now. Will reply when I'm free.",
  "Out of office today. Back tomorrow!",
  "In a meeting — will respond in a few hours.",
];

export default function AutoReply() {
  const { goBack, numbers, autoReplies, setAutoReply } = useApp();
  const [selectedNum, setSelectedNum] = useState(numbers[0]?.id);
  const [enabled, setEnabled] = useState(false);
  const [msg, setMsg] = useState("");

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:"var(--bg-base)", overflow:"hidden" }}>
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={goBack} style={{ background:"none", border:"none", display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)" }}>Auto-Reply</h2>
            <p style={{ fontSize:11, color:"var(--text-muted)", marginTop:1 }}>Send automatic responses when unavailable</p>
          </div>
        </div>
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:"14px 16px" }}>
        {/* Number selector */}
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)", letterSpacing:1.6, marginBottom:8 }}>SELECT NUMBER</div>
        <div style={{ display:"flex", gap:8, marginBottom:16 }}>
          {numbers.map(n => (
            <button key={n.id} onClick={() => setSelectedNum(n.id)} className="press" style={{
              padding:"8px 14px", background:selectedNum===n.id?"var(--accent-dim)":"var(--bg-surface)",
              border:`1.5px solid ${selectedNum===n.id?"var(--accent)":"var(--border)"}`,
              borderRadius:99, cursor:"pointer", display:"flex", alignItems:"center", gap:6,
              fontSize:12, fontWeight:700, color:selectedNum===n.id?"var(--accent)":"var(--text-secondary)" }}>
              {n.flag} {n.number.slice(0, 8)}…
            </button>
          ))}
        </div>

        {/* Toggle */}
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between",
          background:"var(--bg-surface)", borderRadius:"var(--r-md)", padding:"14px 16px", marginBottom:14,
          border:"1px solid var(--border)", boxShadow:"var(--shadow-sm)" }}>
          <div>
            <div style={{ fontSize:14, fontWeight:700, color:"var(--text-primary)" }}>Enable Auto-Reply</div>
            <div style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:2 }}>Respond automatically to incoming SMS</div>
          </div>
          <Toggle value={enabled} onChange={setEnabled}/>
        </div>

        {/* Message */}
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)", letterSpacing:1.6, marginBottom:8 }}>REPLY MESSAGE</div>
        <textarea value={msg} onChange={e => setMsg(e.target.value)}
          placeholder="Type your auto-reply message…"
          style={{ width:"100%", height:100, borderRadius:"var(--r-md)",
            border:"1.5px solid var(--border)", background:"var(--bg-surface)",
            padding:"14px", fontSize:13.5, color:"var(--text-primary)",
            outline:"none", resize:"none", lineHeight:1.6, marginBottom:14,
            boxShadow:"var(--shadow-sm)" }}/>

        {/* Templates */}
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)", letterSpacing:1.6, marginBottom:8 }}>QUICK TEMPLATES</div>
        <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:16 }}>
          {TEMPLATES.map((t, i) => (
            <div key={i} className="press row-tap" onClick={() => setMsg(t)}
              style={{ padding:"12px 14px", background:"var(--bg-surface)",
                borderRadius:"var(--r-md)", border:"1px solid var(--border)",
                cursor:"pointer", boxShadow:"var(--shadow-sm)" }}>
              <div style={{ fontSize:13, color:"var(--text-secondary)", lineHeight:1.5 }}>{t}</div>
            </div>
          ))}
        </div>

        <button className="press" onClick={() => { setAutoReply(selectedNum, msg); goBack(); }}
          disabled={!msg.trim()} style={{ width:"100%", height:50,
            background:msg.trim()?"var(--accent)":"var(--bg-raised)", border:"none",
            borderRadius:"var(--r-md)", color:msg.trim()?"var(--bg-base)":"var(--text-muted)",
            fontSize:14, fontWeight:800, cursor:msg.trim()?"pointer":"default",
            boxShadow:msg.trim()?"var(--shadow-accent)":"none" }}>
          Save Auto-Reply
        </button>
      </div>
    </div>
  );
}
