// src/screens/Auth.jsx — Clean, playful auth screen
import React, { useState } from "react";
import { Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";

export default function Auth() {
  const { navigate } = useApp();
  const [mode, setMode]       = useState("login"); // "login" | "signup"
  const [email, setEmail]     = useState("");
  const [pass, setPass]       = useState("");
  const [loading, setLoading] = useState(false);

  const submit = () => {
    if (!email || !pass) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); navigate("home"); }, 1400);
  };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", padding:"32px 24px 36px", overflow:"hidden" }}>
      {/* Logo */}
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:32 }}>
        <div style={{ width:40, height:40, borderRadius:13,
          background:"var(--accent)", display:"flex",
          alignItems:"center", justifyContent:"center",
          boxShadow:"var(--shadow-accent)" }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
            stroke="var(--bg-base)" strokeWidth="2.2" strokeLinecap="round">
            <circle cx="12" cy="12" r="10"/>
            <line x1="2" y1="12" x2="22" y2="12"/>
            <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
          </svg>
        </div>
        <span style={{ fontSize:20, fontWeight:800, color:"var(--text-primary)",
          letterSpacing:"-0.5px" }}>DialGlobal</span>
      </div>

      {/* Title */}
      <div key={mode} className="fade-up" style={{ marginBottom:28 }}>
        <h2 style={{ fontSize:28, fontWeight:800, color:"var(--text-primary)",
          letterSpacing:"-0.6px", marginBottom:6 }}>
          {mode === "login" ? "Welcome back 👋" : "Create account ✨"}
        </h2>
        <p style={{ fontSize:14, color:"var(--text-secondary)", lineHeight:1.6 }}>
          {mode === "login"
            ? "Sign in to your DialGlobal account"
            : "Start with a free number in 60 seconds"}
        </p>
      </div>

      {/* Fields */}
      <div style={{ display:"flex", flexDirection:"column", gap:12, marginBottom:20 }}>
        <div>
          <label style={{ fontSize:12, fontWeight:700, color:"var(--text-muted)",
            letterSpacing:0.5, display:"block", marginBottom:6 }}>EMAIL</label>
          <input value={email} onChange={e => setEmail(e.target.value)}
            type="email" placeholder="you@example.com"
            style={{ width:"100%", height:50, borderRadius:"var(--r-md)",
              border:`1.5px solid ${email?"var(--accent)":"var(--border)"}`,
              background:"var(--bg-surface)", padding:"0 16px",
              fontSize:14.5, color:"var(--text-primary)",
              outline:"none", transition:"border-color 0.2s",
              boxShadow:email?"0 0 0 3px var(--accent-dim)":"none" }}/>
        </div>
        <div>
          <label style={{ fontSize:12, fontWeight:700, color:"var(--text-muted)",
            letterSpacing:0.5, display:"block", marginBottom:6 }}>PASSWORD</label>
          <input value={pass} onChange={e => setPass(e.target.value)}
            type="password" placeholder="••••••••"
            style={{ width:"100%", height:50, borderRadius:"var(--r-md)",
              border:`1.5px solid ${pass?"var(--accent)":"var(--border)"}`,
              background:"var(--bg-surface)", padding:"0 16px",
              fontSize:14.5, color:"var(--text-primary)",
              outline:"none", transition:"border-color 0.2s",
              boxShadow:pass?"0 0 0 3px var(--accent-dim)":"none" }}/>
        </div>
      </div>

      {mode === "login" && (
        <button style={{ alignSelf:"flex-end", background:"none", border:"none",
          fontSize:12.5, color:"var(--accent)", fontWeight:700,
          marginBottom:20, cursor:"pointer" }}>
          Forgot password?
        </button>
      )}

      <button className="press" onClick={submit} disabled={loading || !email || !pass}
        style={{ width:"100%", height:52, background:"var(--accent)",
          border:"none", borderRadius:"var(--r-md)",
          color:"var(--bg-base)", fontSize:15, fontWeight:800,
          display:"flex", alignItems:"center", justifyContent:"center", gap:10,
          cursor:"pointer", boxShadow:"var(--shadow-accent)",
          opacity:(!email||!pass)?0.6:1,
          transition:"opacity 0.2s", marginBottom:18 }}>
        {loading
          ? <><Spinner color="var(--bg-base)"/>Signing in…</>
          : mode === "login" ? "Sign In →" : "Create Account →"}
      </button>

      {/* OAuth divider */}
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16 }}>
        <div style={{ flex:1, height:1, background:"var(--border)" }}/>
        <span style={{ fontSize:12, color:"var(--text-muted)", fontWeight:500 }}>or continue with</span>
        <div style={{ flex:1, height:1, background:"var(--border)" }}/>
      </div>

      <div style={{ display:"flex", gap:10, marginBottom:"auto" }}>
        {[{ label:"Google", emoji:"🔵" }, { label:"Apple", emoji:"🍎" }].map(p => (
          <button key={p.label} className="press" onClick={() => navigate("home")} style={{
            flex:1, height:46, background:"var(--bg-surface)",
            border:"1.5px solid var(--border)", borderRadius:"var(--r-md)",
            display:"flex", alignItems:"center", justifyContent:"center", gap:8,
            fontSize:13.5, fontWeight:700, color:"var(--text-primary)",
            cursor:"pointer", boxShadow:"var(--shadow-sm)" }}>
            <span style={{ fontSize:18 }}>{p.emoji}</span> {p.label}
          </button>
        ))}
      </div>

      {/* Switch mode */}
      <div style={{ textAlign:"center", marginTop:24 }}>
        <span style={{ fontSize:13.5, color:"var(--text-muted)" }}>
          {mode === "login" ? "Don't have an account? " : "Already have an account? "}
        </span>
        <button onClick={() => setMode(mode === "login" ? "signup" : "login")}
          style={{ background:"none", border:"none", fontSize:13.5,
            color:"var(--accent)", fontWeight:800, cursor:"pointer" }}>
          {mode === "login" ? "Sign up free" : "Sign in"}
        </button>
      </div>
    </div>
  );
}
