import React, { useState } from "react";
import { Ic, Pill } from "../components/UI";
import { useApp } from "../context/AppContext";
import { PLANS } from "../data/mockData";

export default function Profile() {
  const { goBack, navigate, currentPlan, billing, credits } = useApp();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("Vusi Hal");
  const [email, setEmail] = useState("vusi@dialglobal.io");
  const plan = PLANS.find(p => p.id === currentPlan);
  const price = billing === "yearly" ? plan?.yearlyPrice : plan?.monthlyPrice;

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:"var(--bg-base)", overflow:"hidden" }}>
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 20px", borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
          <button onClick={goBack} style={{ background:"none", border:"none", display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <h2 style={{ fontSize:17, fontWeight:800, color:"var(--text-primary)" }}>Profile</h2>
          <button onClick={() => setEditing(e => !e)} style={{ background:"none", border:"none",
            fontSize:13, color:"var(--accent)", fontWeight:700, cursor:"pointer" }}>
            {editing ? "Save" : "Edit"}
          </button>
        </div>
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:10 }}>
          <div style={{ width:80, height:80, borderRadius:24,
            background:"linear-gradient(135deg,var(--accent),var(--accent-dark))",
            display:"flex", alignItems:"center", justifyContent:"center",
            fontSize:32, fontWeight:800, color:"var(--bg-base)",
            boxShadow:"var(--shadow-accent)" }}>V</div>
          {editing ? (
            <>
              <input value={name} onChange={e => setName(e.target.value)} style={{
                textAlign:"center", fontSize:20, fontWeight:800, color:"var(--text-primary)",
                background:"transparent", border:"none", borderBottom:"2px solid var(--accent)",
                outline:"none", width:"100%", letterSpacing:"-0.4px" }}/>
              <input value={email} onChange={e => setEmail(e.target.value)} style={{
                textAlign:"center", fontSize:13, color:"var(--text-muted)",
                background:"transparent", border:"none", borderBottom:"1.5px solid var(--border)",
                outline:"none", width:"100%", fontFamily:"var(--font-mono)" }}/>
            </>
          ) : (
            <>
              <div style={{ fontSize:22, fontWeight:800, color:"var(--text-primary)", letterSpacing:"-0.4px" }}>{name}</div>
              <div style={{ fontSize:13, color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>{email}</div>
            </>
          )}
          <div style={{ display:"flex", gap:8, marginTop:4 }}>
            <Pill label={`${plan?.name || "Free"} Plan`}/>
            {credits > 0 && <Pill label={`⭐ ${credits} credits`} color="var(--blue)" bg="var(--blue-dim)"/>}
          </div>
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"16px" }}>
        {[
          { emoji:"💳", label:"Subscription", val:price > 0 ? `$${price}/mo · ${plan?.name}` : "Free", onClick:() => navigate("paywall") },
          { emoji:"🌍", label:"Numbers active", val:"2 numbers" },
          { emoji:"📞", label:"Total calls made", val:"27 calls" },
          { emoji:"💬", label:"Messages sent", val:"55 messages" },
          { emoji:"📡", label:"eSIM status", val:"None active", onClick:() => navigate("esim") },
        ].map((row, i, arr) => (
          <div key={i} className="row-tap" onClick={row.onClick}
            style={{ display:"flex", alignItems:"center", gap:12,
              padding:"14px 16px", background:"var(--bg-surface)",
              borderBottom:i<arr.length-1?"1px solid var(--border)":"none",
              cursor:row.onClick?"pointer":"default",
              borderRadius:i===0?"var(--r-lg) var(--r-lg) 0 0":i===arr.length-1?"0 0 var(--r-lg) var(--r-lg)":"0",
              marginBottom:0 }}>
            <span style={{ fontSize:20 }}>{row.emoji}</span>
            <span style={{ flex:1, fontSize:13.5, fontWeight:600, color:"var(--text-primary)" }}>{row.label}</span>
            <span style={{ fontSize:13, color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>{row.val}</span>
            {row.onClick && <Ic d="M9 18l6-6-6-6" size={14} color="var(--text-muted)" sw={2}/>}
          </div>
        ))}
      </div>
    </div>
  );
}
