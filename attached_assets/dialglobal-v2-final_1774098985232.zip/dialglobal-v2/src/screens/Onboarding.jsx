// src/screens/Onboarding.jsx — Playful, animated onboarding
import React, { useState } from "react";
import { useApp } from "../context/AppContext";

const SLIDES = [
  {
    bg:"ob-grad-1",
    emoji:"🌍",
    title:"One app.\nEvery country.",
    sub:"Get virtual phone numbers in 100+ countries instantly. Call, text, and stay connected globally.",
    accent:"#E8A020",
  },
  {
    bg:"ob-grad-2",
    emoji:"📱",
    title:"Calls & texts\nfrom any number.",
    sub:"Receive calls directly in the app. Real push notifications for every call and message.",
    accent:"#18A85A",
  },
  {
    bg:"ob-grad-3",
    emoji:"📡",
    title:"Travel with\nan eSIM.",
    sub:"Buy regional eSIM data plans and stay online abroad — no roaming fees, ever.",
    accent:"#7C3AED",
  },
];

export default function Onboarding() {
  const { navigate } = useApp();
  const [slide, setSlide] = useState(0);
  const s = SLIDES[slide];
  const isLast = slide === SLIDES.length - 1;

  return (
    <div className={s.bg} style={{ flex:1, display:"flex", flexDirection:"column",
      padding:"40px 28px 36px", overflow:"hidden" }}>
      {/* Skip */}
      <div style={{ display:"flex", justifyContent:"flex-end" }}>
        <button onClick={() => navigate("auth")} style={{
          background:"none", border:"none", fontSize:13.5,
          color:"var(--text-muted)", fontWeight:600, cursor:"pointer",
          padding:"4px 8px" }}>
          Skip
        </button>
      </div>

      {/* Illustration area */}
      <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center" }}>
        <div key={slide} className="scale-in" style={{
          width:180, height:180, borderRadius:50,
          background:"var(--bg-surface)",
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:90,
          boxShadow:`0 20px 60px ${s.accent}33, 0 4px 16px rgba(0,0,0,0.06)`,
          border:`3px solid ${s.accent}22`,
        }}>
          {s.emoji}
        </div>
      </div>

      {/* Text */}
      <div key={`text-${slide}`} className="fade-up" style={{ marginBottom:32 }}>
        <h1 style={{ fontSize:30, fontWeight:800, color:"var(--text-primary)",
          letterSpacing:"-0.8px", lineHeight:1.2, marginBottom:12,
          whiteSpace:"pre-line" }}>{s.title}</h1>
        <p style={{ fontSize:14.5, color:"var(--text-secondary)",
          lineHeight:1.7 }}>{s.sub}</p>
      </div>

      {/* Dots + CTA */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div style={{ display:"flex", gap:6 }}>
          {SLIDES.map((_, i) => (
            <div key={i} style={{
              width:i === slide ? 22 : 7, height:7, borderRadius:99,
              background:i === slide ? "var(--accent)" : "var(--border-strong)",
              transition:"all 0.3s cubic-bezier(0.34,1.56,0.64,1)",
            }}/>
          ))}
        </div>
        <button className="press" onClick={() => isLast ? navigate("auth") : setSlide(s => s + 1)}
          style={{
            height:50, padding:"0 28px", background:"var(--accent)",
            border:"none", borderRadius:"var(--r-md)",
            color:"var(--bg-base)", fontSize:15, fontWeight:800,
            cursor:"pointer", boxShadow:"var(--shadow-accent)",
            display:"flex", alignItems:"center", gap:8,
          }}>
          {isLast ? "Get Started →" : "Next"}
          {!isLast && (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
              stroke="var(--bg-base)" strokeWidth="2.8" strokeLinecap="round">
              <path d="M9 18l6-6-6-6"/>
            </svg>
          )}
        </button>
      </div>
    </div>
  );
}
