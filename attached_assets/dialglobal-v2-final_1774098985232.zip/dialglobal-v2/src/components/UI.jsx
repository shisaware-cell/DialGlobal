// src/components/UI.jsx — Upgraded playful mobile UI components
import React, { useState } from "react";

// SVG icon wrapper
export function Ic({ d, size=20, color="currentColor", sw=2, style={}, fill="none" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}
      stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round"
      style={{flexShrink:0,...style}}>
      <path d={d}/>
    </svg>
  );
}

// Spinner
export function Spinner({ size=18, color="var(--accent)" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={2.5} strokeLinecap="round"
      style={{animation:"spin 0.8s linear infinite",flexShrink:0}}>
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
    </svg>
  );
}

// Toggle with haptic-feel animation
export function Toggle({ value, onChange }) {
  return (
    <div onClick={() => onChange(!value)} style={{
      width:46, height:26, borderRadius:13,
      background:value?"var(--accent)":"var(--bg-raised)",
      border:`1.5px solid ${value?"var(--accent)":"var(--border-strong)"}`,
      cursor:"pointer", position:"relative", flexShrink:0,
      transition:"background 0.22s cubic-bezier(0.34,1.56,0.64,1), border-color 0.22s",
      boxShadow:value?"0 2px 8px var(--accent-glow)":"none",
    }}>
      <div style={{
        position:"absolute", top:2, left:value?22:2,
        width:18, height:18, borderRadius:"50%",
        background:"#fff",
        boxShadow:"0 1px 4px rgba(0,0,0,0.18)",
        transition:"left 0.22s cubic-bezier(0.34,1.56,0.64,1)",
      }}/>
    </div>
  );
}

// Pill badge
export function Pill({ label, color="var(--accent)", bg="var(--accent-dim)" }) {
  return (
    <span style={{display:"inline-flex",alignItems:"center",gap:4,fontSize:10.5,fontWeight:700,
      color, background:bg, padding:"3px 9px", borderRadius:99}}>
      {label}
    </span>
  );
}

// Dynamic Island
export function DynamicIsland() {
  return (
    <div style={{display:"flex",justifyContent:"center",paddingTop:10,paddingBottom:4,flexShrink:0}}>
      <div style={{width:110,height:30,borderRadius:20,background:"#0D0D0D",
        boxShadow:"0 2px 12px rgba(0,0,0,0.4)"}}/>
    </div>
  );
}

// Status bar
export function StatusBar() {
  const now = new Date();
  const h = now.getHours().toString().padStart(2,"0");
  const m = now.getMinutes().toString().padStart(2,"0");
  return (
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",
      padding:"2px 24px 4px",flexShrink:0}}>
      <span style={{fontSize:12.5,fontWeight:700,color:"var(--text-primary)",fontFamily:"var(--font-mono)"}}>
        {h}:{m}
      </span>
      <div style={{display:"flex",alignItems:"center",gap:5}}>
        <svg width="16" height="12" viewBox="0 0 16 12" fill="var(--text-primary)">
          <rect x="0" y="8" width="3" height="4" rx="1"/>
          <rect x="4.5" y="5" width="3" height="7" rx="1"/>
          <rect x="9" y="2" width="3" height="10" rx="1"/>
          <rect x="13.5" y="0" width="2.5" height="12" rx="1" opacity="0.3"/>
        </svg>
        <svg width="15" height="12" viewBox="0 0 15 12" fill="var(--text-primary)">
          <path d="M7.5 2.5C9.8 2.5 11.9 3.5 13.3 5.1L14.5 3.8C12.7 1.9 10.2 0.8 7.5 0.8C4.8 0.8 2.3 1.9 0.5 3.8L1.7 5.1C3.1 3.5 5.2 2.5 7.5 2.5Z" opacity="0.4"/>
          <path d="M7.5 5C9.0 5 10.4 5.6 11.4 6.6L12.6 5.3C11.2 3.9 9.5 3.2 7.5 3.2C5.5 3.2 3.8 3.9 2.4 5.3L3.6 6.6C4.6 5.6 6.0 5 7.5 5Z" opacity="0.7"/>
          <circle cx="7.5" cy="10" r="1.5"/>
        </svg>
        <div style={{display:"flex",alignItems:"center",gap:1.5}}>
          <div style={{width:22,height:11,borderRadius:3,border:"1.5px solid var(--text-primary)",padding:1.5,display:"flex",alignItems:"center"}}>
            <div style={{width:"70%",height:"100%",borderRadius:1.5,background:"var(--text-primary)"}}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// Delete/confirm bottom sheet
export function DeleteSheet({ title, body, confirmLabel, onClose, onConfirm, danger=true }) {
  return (
    <div className="sheet-overlay" onClick={onClose}
      style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.45)",zIndex:100,display:"flex",alignItems:"flex-end"}}>
      <div className="bottom-sheet" onClick={e=>e.stopPropagation()}
        style={{width:"100%",background:"var(--bg-surface)",borderRadius:"24px 24px 0 0",padding:"20px 20px 32px"}}>
        <div style={{width:36,height:4,borderRadius:2,background:"var(--border-strong)",margin:"0 auto 18px"}}/>
        <h3 style={{fontSize:17,fontWeight:800,color:"var(--text-primary)",marginBottom:8}}>{title}</h3>
        <p style={{fontSize:13,color:"var(--text-secondary)",lineHeight:1.6,marginBottom:22}}>{body}</p>
        <div style={{display:"flex",gap:10}}>
          <button onClick={onClose} className="press" style={{flex:1,height:48,borderRadius:"var(--r-md)",
            background:"var(--bg-raised)",border:"1px solid var(--border)",
            fontSize:14,fontWeight:600,color:"var(--text-secondary)",cursor:"pointer"}}>
            Cancel
          </button>
          <button onClick={onConfirm} className="press" style={{flex:1.2,height:48,borderRadius:"var(--r-md)",
            background:danger?"var(--red)":"var(--accent)",border:"none",
            fontSize:14,fontWeight:700,color:"#fff",cursor:"pointer",
            boxShadow:danger?"0 4px 14px rgba(224,53,53,0.3)":"var(--shadow-accent)"}}>
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// Active call overlay (incoming call UI)
export function IncomingCallOverlay({ caller, number, onAccept, onDecline }) {
  return (
    <div style={{position:"absolute",inset:0,background:"linear-gradient(170deg,#1A1A2E 0%,#16213E 100%)",
      zIndex:200,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"space-between",
      padding:"60px 32px 52px"}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:13,fontWeight:600,color:"rgba(255,255,255,0.5)",letterSpacing:2,marginBottom:20}}>
          INCOMING CALL
        </div>
        <div style={{width:88,height:88,borderRadius:"50%",background:"linear-gradient(135deg,var(--accent),var(--accent-dark))",
          display:"flex",alignItems:"center",justifyContent:"center",fontSize:34,fontWeight:800,
          color:"#fff",margin:"0 auto 16px",boxShadow:"0 8px 32px rgba(232,160,32,0.4)",
          animation:"heartbeat 1.6s ease infinite"}}>
          {caller[0]}
        </div>
        <div style={{fontSize:22,fontWeight:800,color:"#fff",marginBottom:6}}>{caller}</div>
        <div style={{fontSize:13,color:"rgba(255,255,255,0.5)",fontFamily:"var(--font-mono)"}}>{number}</div>
      </div>
      <div style={{display:"flex",gap:40,alignItems:"center"}}>
        <button onClick={onDecline} style={{width:68,height:68,borderRadius:"50%",background:"var(--red)",
          border:"none",display:"flex",alignItems:"center",justifyContent:"center",
          boxShadow:"0 6px 24px rgba(224,53,53,0.4)",cursor:"pointer"}}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
            <path d="M23.36 5.04A17 17 0 0 0 6 2.4L1.96 6.44A2 2 0 0 0 2 9.24l4 .57a2 2 0 0 0 1.9-.84l1.7-2.36a12.93 12.93 0 0 1 7.2 7.2l-2.36 1.7a2 2 0 0 0-.84 1.9l.57 4a2 2 0 0 0 2.8.04l4.04-4.04A17 17 0 0 0 23.36 5.04z"/>
          </svg>
        </button>
        <button onClick={onAccept} style={{width:68,height:68,borderRadius:"50%",background:"var(--green)",
          border:"none",display:"flex",alignItems:"center",justifyContent:"center",
          boxShadow:"0 6px 24px rgba(24,168,90,0.4)",cursor:"pointer"}}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
            <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
          </svg>
        </button>
      </div>
    </div>
  );
}

// Notification toast
export function Toast({ message, type="info", onDismiss }) {
  const colors = {info:"var(--blue)",success:"var(--green)",warning:"var(--accent)",error:"var(--red)"};
  return (
    <div className="slide-up" onClick={onDismiss} style={{
      position:"absolute",top:12,left:12,right:12,zIndex:150,
      background:"var(--text-primary)",borderRadius:"var(--r-md)",
      padding:"12px 14px",display:"flex",alignItems:"center",gap:10,cursor:"pointer",
      boxShadow:"0 8px 28px rgba(0,0,0,0.25)"}}>
      <div style={{width:8,height:8,borderRadius:"50%",background:colors[type],flexShrink:0,
        animation:"heartbeat 1.6s ease infinite"}}/>
      <span style={{fontSize:13,fontWeight:600,color:"#fff",flex:1}}>{message}</span>
      <span style={{fontSize:11,color:"rgba(255,255,255,0.4)"}}>tap to dismiss</span>
    </div>
  );
}
