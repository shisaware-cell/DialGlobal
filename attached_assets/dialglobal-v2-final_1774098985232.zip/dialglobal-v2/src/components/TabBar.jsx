// src/components/TabBar.jsx — Playful mobile tab bar
import React from "react";
import { useApp } from "../context/AppContext";

function TabIcon({ id, active }) {
  const icons = {
    home:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active?2.2:1.8} strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="8" height="11" rx="2"/><rect x="14" y="3" width="8" height="7" rx="2"/><rect x="14" y="14" width="8" height="7" rx="2"/><rect x="2" y="18" width="8" height="3" rx="1.5"/></svg>,
    inbox:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active?2.2:1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>,
    calls:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active?2.2:1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>,
    settings: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active?2.2:1.8} strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>,
  };
  return <div style={{width:22,height:22,color:active?"var(--accent)":"var(--text-muted)"}}>{icons[id]}</div>;
}

export default function TabBar() {
  const { screen, navigate } = useApp();
  const isHome = screen === "home";
  const tabs = [
    {id:"home",     label:"Numbers"},
    {id:"inbox",    label:"Inbox"},
    {id:"_fab",     label:""},
    {id:"calls",    label:"Calls"},
    {id:"settings", label:"More"},
  ];

  return (
    <div style={{
      height:80, background:"var(--bg-surface)",
      borderTop:"1px solid var(--border)",
      display:"flex", alignItems:"center",
      justifyContent:"space-around",
      padding:"0 4px 14px", flexShrink:0,
      position:"relative",
    }}>
      {/* Floating Action Button */}
      <div style={{position:"absolute",top:-26,left:"50%",transform:"translateX(-50%)",zIndex:10}}>
        <div style={{position:"relative",width:54,height:54}}>
          {isHome && <><div className="fab-ring"/><div className="fab-ring2"/></>}
          <button className="fab-btn press" onClick={() => navigate("picker")} style={{
            width:54, height:54, borderRadius:"50%",
            background:"var(--accent)",
            border:"3px solid var(--bg-base)",
            display:"flex", alignItems:"center", justifyContent:"center",
            boxShadow:"var(--shadow-accent)",
            cursor:"pointer", position:"relative", zIndex:1,
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
              stroke="var(--bg-base)" strokeWidth="2.8" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19"/>
              <line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </button>
        </div>
      </div>

      {tabs.map(t => {
        if (t.id === "_fab") return <div key="_fab" style={{flex:1}}/>;
        const on = screen === t.id;
        return (
          <button key={t.id} onClick={() => navigate(t.id)} style={{
            flex:1, background:"none", border:"none", cursor:"pointer",
            display:"flex", flexDirection:"column", alignItems:"center", gap:3, padding:"4px 6px",
            position:"relative",
          }}>
            <TabIcon id={t.id} active={on}/>
            <span style={{
              fontSize:9.5, color:on?"var(--accent)":"var(--text-muted)",
              fontWeight:on?700:400, transition:"color 0.15s",
            }}>{t.label}</span>
            {on && <div style={{position:"absolute",bottom:-14,width:18,height:3,
              borderRadius:2,background:"var(--accent)"}}/>}
          </button>
        );
      })}
    </div>
  );
}
