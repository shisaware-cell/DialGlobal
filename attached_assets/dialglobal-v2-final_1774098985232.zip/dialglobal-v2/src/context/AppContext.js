// src/context/AppContext.js
import React, { createContext, useContext, useState } from "react";
import { MOCK_NUMBERS } from "../data/mockData";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [screen,          setScreen]         = useState("onboarding");
  const [prevScreen,      setPrevScreen]     = useState(null);
  const [currentPlan,     setCurrentPlan]    = useState("free");
  const [billing,         setBilling]        = useState("monthly");
  const [credits,         setCredits]        = useState(0);
  const [numbers,         setNumbers]        = useState(MOCK_NUMBERS);
  const [selectedNumber,  setSelectedNumber] = useState(null);
  const [ghostMode,       setGhostMode]      = useState(false);
  const [contacts,        setContacts]       = useState([]);
  const [dndNumbers,      setDndNumbers]     = useState({});
  const [spamEnabled,     setSpamEnabled]    = useState({});
  const [autoReplies,     setAutoReplies]    = useState({});
  const [recordings,      setRecordings]     = useState({});
  const [forwarding,      setForwarding]     = useState({});
  const [forwardingNums,  setForwardingNums] = useState({});
  const [notifications,   setNotifications]  = useState(true);
  const [toast,           setToast]          = useState(null);
  const [incomingCall,    setIncomingCall]   = useState(null);
  const [activeEsim,      setActiveEsim]     = useState(null);

  function navigate(to) { setPrevScreen(screen); setScreen(to); }
  function goBack()      { setScreen(prevScreen || "home"); setPrevScreen(null); }
  function upgradePlan(planId, billingCycle="monthly") { setCurrentPlan(planId); setBilling(billingCycle); }
  function addCredits(amount) { setCredits(c => c + amount); }
  function addNumber(num)   { setNumbers(prev => [...prev, num]); }
  function removeNumber(id) { setNumbers(prev => prev.filter(n => n.id !== id)); }
  function toggleDnd(id)         { setDndNumbers(p => ({ ...p, [id]: !p[id] })); }
  function toggleSpam(id)        { setSpamEnabled(p => ({ ...p, [id]: !p[id] })); }
  function toggleRecording(id)   { setRecordings(p => ({ ...p, [id]: !p[id] })); }
  function toggleForwarding(id)  { setForwarding(p => ({ ...p, [id]: !p[id] })); }
  function setForwardingNum(id, num) { setForwardingNums(p => ({ ...p, [id]: num })); }
  function setAutoReply(id, msg) { setAutoReplies(p => ({ ...p, [id]: msg })); }
  function importContacts(list)  {
    setContacts(prev => {
      const existing = new Set(prev.map(c => c.phone));
      return [...prev, ...list.filter(c => !existing.has(c.phone))];
    });
  }
  function showToast(message, type="info") {
    setToast({message,type});
    setTimeout(() => setToast(null), 3500);
  }
  function simulateIncomingCall() {
    setIncomingCall({caller:"Marcus Webb", number:"+1 917 555 0134"});
  }
  function dismissIncomingCall() { setIncomingCall(null); }
  function activateEsim(plan) { setActiveEsim(plan); }

  return (
    <AppContext.Provider value={{
      screen, navigate, goBack,
      currentPlan, billing, upgradePlan,
      credits, addCredits,
      numbers, addNumber, removeNumber,
      selectedNumber, setSelectedNumber,
      ghostMode, setGhostMode,
      contacts, importContacts,
      dndNumbers, toggleDnd,
      spamEnabled, toggleSpam,
      autoReplies, setAutoReply,
      recordings, toggleRecording,
      forwarding, toggleForwarding,
      forwardingNums, setForwardingNum,
      notifications, setNotifications,
      toast, showToast,
      incomingCall, simulateIncomingCall, dismissIncomingCall,
      activeEsim, activateEsim,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() { return useContext(AppContext); }
