// src/screens/Settings.jsx — Streamlined; features moved to inline cards
import React, { useState } from "react";
import { Ic, Toggle, Pill, DeleteSheet } from "../components/UI";
import { useApp } from "../context/AppContext";
import { PLANS, CREDIT_PACKS } from "../data/mockData";

function SectionRow({ iconD, iconEmoji, label, sublabel, right, danger, onClick, last, badge, color }) {
  const bg = danger ? "var(--red-dim)" : color ? `rgba(0,0,0,0.04)` : "var(--accent-dim)";
  const ic = danger ? "var(--red)" : color || "var(--accent)";
  return (
    <div onClick={onClick} className={onClick ? "row-tap" : ""}
      style={{ display:"flex", alignItems:"center", gap:12, padding:"13px 16px",
        borderBottom:last?"none":"1px solid var(--border)",
        cursor:onClick?"pointer":"default", transition:"background 0.12s" }}>
      <div style={{ width:36, height:36, borderRadius:10,
        background:bg, display:"flex", alignItems:"center", justifyContent:"center",
        flexShrink:0, fontSize:iconEmoji?18:0 }}>
        {iconEmoji || <Ic d={iconD} size={16} color={ic} sw={2}/>}
      </div>
      <div style={{ flex:1 }}>
        <div style={{ fontSize:13.5, fontWeight:600,
          color:danger?"var(--red)":"var(--text-primary)",
          display:"flex", alignItems:"center", gap:7 }}>
          {label}
          {badge && <span style={{ fontSize:9, fontWeight:800, background:"var(--red)",
            color:"white", padding:"1px 6px", borderRadius:99 }}>{badge}</span>}
        </div>
        {sublabel && <div style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:1 }}>{sublabel}</div>}
      </div>
      {right}
      {onClick && !right && <Ic d="M9 18l6-6-6-6" size={14} color="var(--text-muted)" sw={2}/>}
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={{ marginBottom:20 }}>
      <div style={{ fontSize:10.5, fontWeight:800, color:"var(--text-muted)",
        letterSpacing:1.6, marginBottom:8, paddingLeft:2 }}>{title}</div>
      <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
        border:"1px solid var(--border)", overflow:"hidden",
        boxShadow:"var(--shadow-sm)" }}>{children}</div>
    </div>
  );
}

export default function Settings() {
  const { navigate, currentPlan, billing, credits, ghostMode, setGhostMode,
          notifications, setNotifications } = useApp();
  const [biometric,   setBiometric]   = useState(false);
  const [showSignOut, setShowSignOut] = useState(false);
  const [darkMode,    setDarkMode]    = useState(false);

  const plan  = PLANS.find(p => p.id === currentPlan) || PLANS[0];
  const price = billing === "yearly" ? plan?.yearlyPrice : plan?.monthlyPrice;

  return (
    <div style={{ flex:1, overflowY:"auto", background:"var(--bg-base)" }}>
      {/* Profile card */}
      <div className="row-tap" onClick={() => navigate("profile")}
        style={{ background:"var(--bg-surface)", borderBottom:"1px solid var(--border)",
          padding:"16px 18px 18px", display:"flex", alignItems:"center",
          gap:14, marginBottom:20, cursor:"pointer" }}>
        <div style={{ width:58, height:58, borderRadius:18,
          background:"linear-gradient(135deg,var(--accent),var(--accent-dark))",
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:22, fontWeight:800, color:"var(--bg-base)",
          boxShadow:"var(--shadow-accent)" }}>V</div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)",
            letterSpacing:"-0.4px" }}>Vusi Hal</div>
          <div style={{ fontSize:12, color:"var(--text-muted)", marginTop:2,
            fontFamily:"var(--font-mono)" }}>vusi@dialglobal.io</div>
          <div style={{ marginTop:6, display:"flex", alignItems:"center", gap:8 }}>
            <Pill label={`${plan?.name || "Free"} Plan`}/>
            {credits > 0 && (
              <span style={{ fontSize:10, fontWeight:700, color:"var(--accent)" }}>
                ⭐ {credits.toLocaleString()} credits
              </span>
            )}
          </div>
        </div>
        <Ic d="M9 18l6-6-6-6" size={16} color="var(--text-muted)" sw={2}/>
      </div>

      <div style={{ padding:"0 16px" }}>
        {/* Preferences */}
        <Section title="PREFERENCES">
          <SectionRow
            iconEmoji="🔔"
            label="Push Notifications"
            sublabel="Incoming calls, messages & missed alerts"
            right={<Toggle value={notifications} onChange={setNotifications}/>}/>
          <SectionRow
            iconEmoji="🔒"
            label="Biometric Lock"
            sublabel="Face ID / Fingerprint unlock"
            right={<Toggle value={biometric} onChange={setBiometric}/>}/>
          <SectionRow
            iconEmoji="👻"
            label="Ghost Mode"
            sublabel="Silence all numbers, hide activity"
            right={<Toggle value={ghostMode} onChange={setGhostMode}/>}/>
          <SectionRow
            iconEmoji="🌙"
            label="Dark Mode"
            sublabel="Coming soon"
            right={<Toggle value={darkMode} onChange={setDarkMode}/>}
            last/>
        </Section>

        {/* Account */}
        <Section title="ACCOUNT">
          <SectionRow
            iconEmoji="💳"
            label="Plan & Billing"
            sublabel={currentPlan==="trial" ? "3-day trial active" : `${plan?.name} · \$${price}/mo`}
            onClick={() => navigate("paywall")} color="var(--purple)"/>
          <SectionRow
            iconEmoji="⭐"
            label="Credits"
            sublabel={`${credits.toLocaleString()} credits available`}
            onClick={() => navigate("credits")} color="var(--accent)"/>
          <SectionRow
            iconEmoji="👤"
            label="Personal Info"
            sublabel="Name, email, password"
            onClick={() => navigate("profile")} color="var(--blue)"
            last/>
        </Section>

        {/* Notification detail */}
        <Section title="CALL & MESSAGE SETTINGS">
          <SectionRow
            iconD="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"
            label="Notification Permissions"
            sublabel="Manage OS-level notification access"
            onClick={() => {}} color="var(--green)"/>
          <SectionRow
            iconD="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"
            label="VoIP Background Calls"
            sublabel="Receive calls when app is closed"
            badge="Required"
            onClick={() => {}} color="var(--accent)"/>
          <SectionRow
            iconD="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4M12 11V3"
            label="Ringtone & Sounds"
            sublabel="Customize call & message alerts"
            onClick={() => {}} color="var(--purple)"
            last/>
        </Section>

        {/* Support */}
        <Section title="SUPPORT">
          <SectionRow
            iconEmoji="❓"
            label="Help & FAQ"
            sublabel="Common questions answered"
            onClick={() => {}}/>
          <SectionRow
            iconEmoji="✉️"
            label="Contact Support"
            sublabel="support@dialglobal.io"
            onClick={() => {}} last/>
        </Section>

        {/* Danger */}
        <Section title="ACCOUNT ACTIONS">
          <SectionRow
            iconD="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
            label="Sign Out" danger onClick={() => setShowSignOut(true)} last/>
        </Section>

        <div style={{ textAlign:"center", padding:"4px 0 28px",
          color:"var(--text-muted)", fontSize:11.5 }}>
          DialGlobal v2.1.0 · Powered by Telnyx
        </div>
      </div>

      {showSignOut && (
        <DeleteSheet
          title="Sign out?"
          body="You'll be logged out of your account on this device."
          confirmLabel="Sign Out"
          onClose={() => setShowSignOut(false)}
          onConfirm={() => { setShowSignOut(false); navigate("auth"); }}
        />
      )}
    </div>
  );
}
