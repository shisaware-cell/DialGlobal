// src/screens/Credits.jsx — Credit wallet with overage explanation
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { CREDIT_PACKS } from "../data/mockData";

export default function Credits() {
  const { goBack, credits, addCredits, currentPlan } = useApp();
  const [loading, setLoading] = useState(null);
  const [justBought, setJustBought] = useState(null);

  const buy = (pack) => {
    setLoading(pack.id);
    // TODO: initiate App Store IAP for credit pack — consumable product
    setTimeout(() => {
      const total = pack.credits + (pack.bonus ? parseFloat(pack.bonus.replace("+$","")) : 0);
      addCredits(total);
      setLoading(null);
      setJustBought(pack);
      setTimeout(() => setJustBought(null), 3000);
    }, 1600);
  };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden" }}>

      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px",
        borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={goBack} style={{ background:"none", border:"none",
            display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)" }}>
              Credit Wallet
            </h2>
            <p style={{ fontSize:11, color:"var(--text-muted)", marginTop:1 }}>
              Used when your plan minutes or SMS run out
            </p>
          </div>
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"14px 16px" }}>

        {/* Balance card */}
        <div style={{
          background:"linear-gradient(135deg,var(--accent) 0%,var(--accent-dark) 100%)",
          borderRadius:"var(--r-xl)", padding:"20px", marginBottom:18,
          boxShadow:"var(--shadow-accent)", position:"relative", overflow:"hidden",
        }}>
          <div style={{ position:"absolute", top:-20, right:-20, width:80, height:80,
            borderRadius:"50%", background:"rgba(255,255,255,0.12)" }}/>
          <div style={{ fontSize:11, fontWeight:700, color:"rgba(255,255,255,0.7)",
            letterSpacing:1.8, marginBottom:6 }}>CREDIT BALANCE</div>
          <div style={{ fontSize:44, fontWeight:800, color:"#fff",
            letterSpacing:"-1px", lineHeight:1 }}>
            ${credits.toFixed(2)}
          </div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.65)",
            marginTop:6 }}>
            ≈ {Math.floor(credits / 0.02)} min calls remaining
          </div>
        </div>

        {justBought && (
          <div className="fade-up" style={{ background:"var(--green-dim)",
            border:"1px solid rgba(24,168,90,0.25)", borderRadius:"var(--r-md)",
            padding:"10px 14px", marginBottom:14, display:"flex",
            alignItems:"center", gap:10 }}>
            <span style={{ fontSize:18 }}>✅</span>
            <div>
              <div style={{ fontSize:12.5, fontWeight:700, color:"var(--green)" }}>
                {justBought.label} pack added!
              </div>
              <div style={{ fontSize:11, color:"var(--text-secondary)", marginTop:1 }}>
                ${(justBought.credits + (justBought.bonus ? parseFloat(justBought.bonus.replace("+$","")) : 0)).toFixed(2)} added to your wallet
              </div>
            </div>
          </div>
        )}

        {/* How credits work */}
        <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
          padding:"13px 15px", marginBottom:16, border:"1px solid var(--border)" }}>
          <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
            letterSpacing:1.4, marginBottom:10 }}>WHAT CREDITS ARE USED FOR</div>
          {[
            { label:"Outbound calls (overage)", rate:"$0.02 / min",
              note:"After your plan's included minutes run out" },
            { label:"Inbound calls (overage)",  rate:"$0.015 / min",
              note:"Receiving calls beyond plan limit" },
            { label:"SMS (overage)",            rate:"$0.02 / SMS",
              note:"After plan's SMS allowance is used" },
            { label:"Call recording (overage)", rate:"$0.005 / min",
              note:"Per minute of recorded call beyond plan" },
            { label:"Extra numbers",            rate:"$1.50 / mo",
              note:"Add numbers beyond your plan limit" },
            { label:"eSIM data plans",          rate:"varies",
              note:"Buy eSIM plans directly from wallet" },
          ].map((r, i, arr) => (
            <div key={i} style={{ display:"flex", alignItems:"flex-start",
              justifyContent:"space-between", gap:12,
              padding:"8px 0",
              borderBottom:i < arr.length-1 ? "1px solid var(--border)" : "none" }}>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12.5, fontWeight:600,
                  color:"var(--text-primary)" }}>{r.label}</div>
                <div style={{ fontSize:11, color:"var(--text-muted)",
                  marginTop:1 }}>{r.note}</div>
              </div>
              <div style={{ fontSize:12, fontWeight:700,
                fontFamily:"var(--font-mono)", color:"var(--accent)",
                flexShrink:0 }}>{r.rate}</div>
            </div>
          ))}
        </div>

        {/* Packs */}
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
          letterSpacing:1.4, marginBottom:10 }}>TOP UP YOUR WALLET</div>

        {CREDIT_PACKS.map((pack, i) => (
          <div key={pack.id} className="fade-up" style={{
            background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
            padding:"14px 16px", marginBottom:10,
            border:`1.5px solid ${pack.popular ? "var(--accent)" : "var(--border)"}`,
            background:pack.popular ? "var(--bg-card)" : "var(--bg-surface)",
            boxShadow:pack.popular ? "var(--shadow-accent)" : "var(--shadow-sm)",
            animationDelay:`${i*0.07}s`,
            display:"flex", alignItems:"center", gap:12,
          }}>
            {pack.popular && (
              <div style={{ position:"absolute", top:0, right:0 }}/>
            )}
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", alignItems:"center",
                gap:8, marginBottom:4 }}>
                <span style={{ fontSize:15, fontWeight:800,
                  color:"var(--text-primary)" }}>
                  {pack.label}
                </span>
                {pack.bonus && (
                  <span style={{ fontSize:10, fontWeight:800, color:"var(--green)",
                    background:"var(--green-dim)", padding:"2px 8px",
                    borderRadius:99 }}>{pack.bonus} bonus</span>
                )}
                {pack.popular && (
                  <span style={{ fontSize:10, fontWeight:800, color:"var(--accent)",
                    background:"var(--accent-dim)", padding:"2px 8px",
                    borderRadius:99 }}>BEST VALUE</span>
                )}
              </div>
              <div style={{ fontSize:11.5, color:"var(--text-muted)" }}>
                {pack.equiv}
              </div>
              <div style={{ fontSize:11, color:"var(--text-secondary)",
                marginTop:2 }}>
                ${pack.credits.toFixed(2)} in wallet after store fee
              </div>
            </div>

            <button onClick={() => buy(pack)} disabled={loading === pack.id}
              className="press" style={{
                height:42, padding:"0 18px",
                background:pack.popular ? "var(--accent)" : "var(--bg-raised)",
                border:pack.popular ? "none" : "1px solid var(--border-strong)",
                borderRadius:"var(--r-md)",
                color:pack.popular ? "var(--bg-base)" : "var(--text-primary)",
                fontSize:14, fontWeight:800, cursor:"pointer",
                display:"flex", alignItems:"center", gap:8, flexShrink:0,
                boxShadow:pack.popular ? "var(--shadow-accent)" : "none",
              }}>
              {loading === pack.id
                ? <Spinner size={16} color={pack.popular?"var(--bg-base)":"var(--accent)"}/>
                : `$${pack.price}`}
            </button>
          </div>
        ))}

        <div style={{ textAlign:"center", padding:"4px 0 12px",
          fontSize:11.5, color:"var(--text-muted)", lineHeight:1.6 }}>
          Purchases processed via App Store / Google Play.{"\n"}
          Credits never expire while your subscription is active.
        </div>
      </div>
    </div>
  );
}
