import { useState, useEffect, useRef } from "react";

// ─── DESIGN TOKENS ───────────────────────────────────────────────
const T = {
  bg: "#F9F8F6",
  surface: "#FFFFFF",
  surfaceAlt: "#F3F2F0",
  border: "#E8E6E1",
  borderStrong: "#D4D1CB",
  text: "#1A1916",
  textMid: "#6B6860",
  textLight: "#A09D97",
  accent: "#2A5EF5",
  accentLight: "#EEF2FF",
  accentDark: "#1A3EB8",
  success: "#16A34A",
  successLight: "#F0FDF4",
  warning: "#D97706",
  warningLight: "#FFFBEB",
  danger: "#DC2626",
  dangerLight: "#FEF2F2",
  gold: "#B45309",
  goldLight: "#FEF3C7",
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Geist:wght@300;400;500;600;700&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  ::-webkit-scrollbar { display: none; }
  scrollbar-width: none;

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(16px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes fadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
  }
  @keyframes scaleIn {
    from { opacity: 0; transform: scale(0.88); }
    to   { opacity: 1; transform: scale(1); }
  }
  @keyframes float {
    0%, 100% { transform: translateY(0px); }
    50%       { transform: translateY(-6px); }
  }
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50%       { opacity: 0.4; }
  }
  @keyframes shimmer {
    0%   { background-position: -200% 0; }
    100% { background-position:  200% 0; }
  }
  @keyframes slideUp {
    from { opacity: 0; transform: translateY(24px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes pop {
    0%   { transform: scale(0.5); opacity: 0; }
    60%  { transform: scale(1.08); }
    100% { transform: scale(1);   opacity: 1; }
  }
  @keyframes badgePop {
    0%   { transform: scale(0); }
    60%  { transform: scale(1.2); }
    100% { transform: scale(1); }
  }
  @keyframes ripple {
    0%   { transform: scale(1);   opacity: 0.4; }
    100% { transform: scale(2.5); opacity: 0; }
  }

  .press:active { transform: scale(0.96) !important; }
  .hover-lift:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.12) !important; }
  .tab-btn:hover svg, .tab-btn:hover span { opacity: 1 !important; }
  .msg-row:hover { background: ${T.surfaceAlt} !important; }
  .call-row:hover { background: ${T.surfaceAlt} !important; }
  .country-row:hover { background: ${T.surfaceAlt} !important; }
  .action-btn:hover { filter: brightness(0.94); }
`;

// ─── DATA ────────────────────────────────────────────────────────
const COUNTRIES = [
  { code:"US", name:"United States",  flag:"🇺🇸", prefix:"+1",  price:1.0, instant:true,  popular:true },
  { code:"GB", name:"United Kingdom", flag:"🇬🇧", prefix:"+44", price:1.0, instant:true,  popular:true },
  { code:"CA", name:"Canada",         flag:"🇨🇦", prefix:"+1",  price:1.0, instant:true,  popular:true },
  { code:"AU", name:"Australia",      flag:"🇦🇺", prefix:"+61", price:1.5, instant:true,  popular:true },
  { code:"DE", name:"Germany",        flag:"🇩🇪", prefix:"+49", price:2.0, instant:true,  popular:false },
  { code:"FR", name:"France",         flag:"🇫🇷", prefix:"+33", price:2.0, instant:true,  popular:false },
  { code:"NL", name:"Netherlands",    flag:"🇳🇱", prefix:"+31", price:1.5, instant:true,  popular:false },
  { code:"MY", name:"Malaysia",       flag:"🇲🇾", prefix:"+60", price:1.0, instant:false, popular:false },
  { code:"TH", name:"Thailand",       flag:"🇹🇭", prefix:"+66", price:1.0, instant:false, popular:false },
  { code:"SG", name:"Singapore",      flag:"🇸🇬", prefix:"+65", price:2.5, instant:true,  popular:false },
  { code:"NZ", name:"New Zealand",    flag:"🇳🇿", prefix:"+64", price:2.0, instant:true,  popular:false },
  { code:"SE", name:"Sweden",         flag:"🇸🇪", prefix:"+46", price:1.5, instant:true,  popular:false },
  { code:"JP", name:"Japan",          flag:"🇯🇵", prefix:"+81", price:3.0, instant:false, popular:false },
  { code:"ZA", name:"South Africa",   flag:"🇿🇦", prefix:"+27", price:2.0, instant:false, popular:false },
];

const NUMBERS = [
  { id:1, number:"+1 (415) 823-4921", country:"United States",  flag:"🇺🇸", type:"permanent", calls:12, sms:47, plan:"Pro",     missedCalls:2, lastActivity:"2m ago", color:T.accent  },
  { id:2, number:"+44 7700 123 456",  country:"United Kingdom", flag:"🇬🇧", type:"temporary", calls:3,  sms:8,  plan:"Starter", missedCalls:0, lastActivity:"1h ago", color:T.success, expiresIn:"5 days" },
];

const MESSAGES = [
  { id:1, name:"Marcus Webb",   number:"+1 917 555 0134",    preview:"Hey, are you free for a call tomorrow?",         time:"2m",  unread:2, flag:"🇺🇸", type:"sms"      },
  { id:2, name:"Priya Sharma",  number:"+44 7900 112233",    preview:"The contract has been sent to your email",        time:"14m", unread:0, flag:"🇬🇧", type:"sms"      },
  { id:3, name:"Unknown",       number:"+1 650 555 7823",    preview:"Missed call",                                     time:"1h",  unread:1, flag:"🇺🇸", type:"missed"   },
  { id:4, name:"David Chen",    number:"+61 4 1234 5678",    preview:"Thanks for getting back to me!",                 time:"3h",  unread:0, flag:"🇦🇺", type:"sms"      },
  { id:5, name:"Sarah Miller",  number:"+49 30 1234567",     preview:"Voicemail: 0:42",                                time:"1d",  unread:0, flag:"🇩🇪", type:"voicemail" },
];

const CALLS = [
  { id:1, name:"Marcus Webb",  number:"+1 917 555 0134",  flag:"🇺🇸", type:"incoming",  duration:"4:32",  time:"2m ago"  },
  { id:2, name:"Priya Sharma", number:"+44 7900 112233",  flag:"🇬🇧", type:"outgoing",  duration:"12:05", time:"1h ago"  },
  { id:3, name:"Unknown",      number:"+1 650 555 7823",  flag:"🇺🇸", type:"missed",    duration:"",      time:"2h ago"  },
  { id:4, name:"David Chen",   number:"+61 4 1234 5678",  flag:"🇦🇺", type:"outgoing",  duration:"1:44",  time:"Yesterday"},
  { id:5, name:"Sarah Miller", number:"+49 30 1234567",   flag:"🇩🇪", type:"voicemail", duration:"0:42",  time:"Yesterday"},
];

function genNumber(prefix) {
  const a = Math.floor(Math.random()*900+100);
  const b = Math.floor(Math.random()*900+100);
  const c = Math.floor(Math.random()*9000+1000);
  if (prefix==="+1")  return `${prefix} (${a}) ${b}-${c}`;
  if (prefix==="+44") return `${prefix} 7${a} ${b} ${c}`;
  return `${prefix} ${a} ${b} ${c}`;
}

// ─── ICONS ───────────────────────────────────────────────────────
const Icon = ({ d, size=20, color="currentColor", strokeWidth=1.8, fill="none" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <path d={d}/>
  </svg>
);

const SignalIcon = ({ color }) => (
  <svg width="16" height="12" viewBox="0 0 17 12" fill={color}>
    <rect x="0" y="4" width="3" height="8" rx="1" opacity=".3"/>
    <rect x="4.5" y="2.5" width="3" height="9.5" rx="1" opacity=".55"/>
    <rect x="9" y="0.5" width="3" height="11.5" rx="1" opacity=".8"/>
    <rect x="13.5" y="0.5" width="3" height="11.5" rx="1"/>
  </svg>
);

const WifiIcon = ({ color }) => (
  <svg width="15" height="12" viewBox="0 0 16 12" fill={color}>
    <path d="M8 2.4C10.8 2.4 13.3 3.6 15 5.6L16 4.4C14 2.1 11.2.8 8 .8S2 2.1 0 4.4l1 1.2C2.7 3.6 5.2 2.4 8 2.4z" opacity=".35"/>
    <path d="M8 5.2c1.9 0 3.6.8 4.8 2.1l1-1.2C12.3 4.3 10.3 3.6 8 3.6S3.7 4.3 2.2 6.1l1 1.2C4.4 6 6.1 5.2 8 5.2z" opacity=".65"/>
    <path d="M8 8c1 0 1.9.4 2.5 1.1L11.6 8C10.6 6.8 9.4 6.4 8 6.4S5.4 6.8 4.4 8l1.1 1.1C6.1 8.4 7 8 8 8z"/>
    <circle cx="8" cy="11" r="1"/>
  </svg>
);

const BatteryIcon = ({ color }) => (
  <div style={{width:23,height:11,border:`1.5px solid ${color}`,borderRadius:3,display:"flex",alignItems:"center",padding:"1.5px 1.5px",position:"relative"}}>
    <div style={{width:"72%",height:"100%",background:color,borderRadius:1.5}}/>
    <div style={{position:"absolute",right:-4,top:"50%",transform:"translateY(-50%)",width:3,height:6,background:color,borderRadius:"0 1px 1px 0",opacity:0.5}}/>
  </div>
);

// ─── STATUS BAR ──────────────────────────────────────────────────
function StatusBar({ dark = false }) {
  const col = dark ? "rgba(255,255,255,0.9)" : T.text;
  return (
    <div style={{ height:44, display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 26px", flexShrink:0, zIndex:10 }}>
      <span style={{ fontSize:15, fontWeight:600, color:col, letterSpacing:"-0.3px" }}>9:41</span>
      <div style={{ display:"flex", gap:6, alignItems:"center" }}>
        <SignalIcon color={col}/>
        <WifiIcon color={col}/>
        <BatteryIcon color={col}/>
      </div>
    </div>
  );
}

// ─── TAB BAR ─────────────────────────────────────────────────────
function TabBar({ active, setScreen }) {
  const tabs = [
    { id:"home",     label:"Numbers",  icon:"M9 12h6M9 16h4M13 4H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V9z M13 4v5h5" },
    { id:"inbox",    label:"Messages", icon:"M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" },
    { id:"_fab",     label:"",         icon:"" },
    { id:"calls",    label:"Calls",    icon:"M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.4 1.14 2 2 0 012.18 1h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45c.907.34 1.85.573 2.81.7A2 2 0 0122 16.92z" },
    { id:"settings", label:"Settings", icon:"M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" },
  ];

  return (
    <div style={{ height:82, background:T.surface, borderTop:`1px solid ${T.border}`, display:"flex", alignItems:"center", justifyContent:"space-around", padding:"0 4px 14px", flexShrink:0, position:"relative" }}>
      {/* Floating action button */}
      <div style={{ position:"absolute", top:-24, left:"50%", transform:"translateX(-50%)", zIndex:10 }}>
        <button className="press" onClick={() => setScreen("picker")} style={{
          width:52, height:52, borderRadius:26,
          background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`,
          border:"3.5px solid #F9F8F6",
          cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center",
          boxShadow:`0 6px 20px ${T.accent}50, 0 2px 6px rgba(0,0,0,0.15)`,
          transition:"transform 0.12s ease",
        }}>
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.6" strokeLinecap="round">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </button>
      </div>

      {tabs.map((t, i) => {
        if (t.id === "_fab") return <div key="_fab" style={{ flex:1 }}/>;
        const isActive = active === t.id;
        return (
          <button key={t.id} className="tab-btn" onClick={() => setScreen(t.id)} style={{
            flex:1, background:"none", border:"none", cursor:"pointer",
            display:"flex", flexDirection:"column", alignItems:"center", gap:3, padding:"4px 6px",
            transition:"all 0.15s",
          }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none"
              stroke={isActive ? T.accent : T.textLight}
              strokeWidth={isActive ? 2 : 1.6}
              strokeLinecap="round" strokeLinejoin="round"
              style={{ opacity: isActive ? 1 : 0.6, transition:"all 0.15s" }}>
              <path d={t.icon}/>
            </svg>
            <span style={{ fontSize:10, color: isActive ? T.accent : T.textLight, fontWeight: isActive ? 600 : 400, opacity: isActive ? 1 : 0.6, transition:"all 0.15s" }}>
              {t.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

// ─── ONBOARDING ──────────────────────────────────────────────────
function Onboarding({ onDone }) {
  const [step, setStep] = useState(0);

  const slides = [
    {
      accent: "#EEF2FF",
      accentStrong: T.accent,
      visual: (
        <div style={{ position:"relative", width:260, height:240, margin:"0 auto" }}>
          {/* Globe */}
          <div style={{ width:164, height:164, borderRadius:"50%", background:`linear-gradient(135deg, ${T.accent} 0%, ${T.accentDark} 100%)`, position:"absolute", top:38, left:48, boxShadow:`0 20px 50px ${T.accent}40` }}>
            <div style={{ position:"absolute", inset:0, borderRadius:"50%", background:"radial-gradient(circle at 35% 30%, rgba(255,255,255,0.22) 0%, transparent 55%)" }}/>
            {[28,48,68].map((y,i)=><div key={i} style={{position:"absolute",left:"10%",right:"10%",top:`${y}%`,height:1,background:"rgba(255,255,255,0.15)"}}/>)}
            {[32,52,72].map((x,i)=><div key={i} style={{position:"absolute",top:"10%",bottom:"10%",left:`${x}%`,width:1,background:"rgba(255,255,255,0.15)"}}/>)}
          </div>
          {[
            { flag:"🇺🇸", style:{top:8,left:0},  delay:"0s",   dur:"2.2s" },
            { flag:"🇬🇧", style:{top:0,right:10}, delay:"0.4s", dur:"2.5s" },
            { flag:"🇯🇵", style:{bottom:36,left:8},  delay:"0.8s", dur:"2.3s" },
            { flag:"🇦🇺", style:{bottom:10,right:20}, delay:"0.2s", dur:"2.7s" },
          ].map((f,i)=>(
            <div key={i} style={{ position:"absolute", ...f.style, background:"white", borderRadius:18, padding:"5px 10px", fontSize:18, boxShadow:"0 4px 16px rgba(0,0,0,0.1)", animation:`float ${f.dur} ease-in-out infinite`, animationDelay:f.delay }}>
              {f.flag}
            </div>
          ))}
        </div>
      ),
      tag: "100+ COUNTRIES",
      title: "Your number,\nanywhere.",
      sub: "Get real local phone numbers from over 100 countries. Receive calls and texts like a local — from anywhere.",
    },
    {
      accent: "#F0FDF4",
      accentStrong: T.success,
      visual: (
        <div style={{ position:"relative", width:260, height:240, margin:"0 auto", display:"flex", alignItems:"center", justifyContent:"center" }}>
          <div style={{ width:160, height:210, background:"white", borderRadius:24, boxShadow:"0 16px 48px rgba(0,0,0,0.1)", overflow:"hidden", border:`1px solid ${T.border}` }}>
            <div style={{ height:32, background:`linear-gradient(90deg, ${T.accent}, ${T.accentDark})`, display:"flex", alignItems:"center", justifyContent:"center" }}>
              <span style={{ color:"white", fontSize:9, fontWeight:700, letterSpacing:2 }}>DIALGLOBAL</span>
            </div>
            {[{n:"🇺🇸 +1 415 823-4921",a:true},{n:"🇬🇧 +44 7700 123 456",a:false},{n:"🇦🇺 +61 4 1234 5678",a:false}].map((item,i)=>(
              <div key={i} style={{ margin:"6px 10px", padding:"9px", background:item.a?T.accentLight:T.surfaceAlt, borderRadius:9, fontSize:8.5, fontWeight:600, color:item.a?T.accent:T.text, borderLeft:`2.5px solid ${item.a?T.accent:"transparent"}` }}>{item.n}</div>
            ))}
            <div style={{ margin:"10px 10px 0", padding:"7px 10px", background:T.successLight, borderRadius:9, display:"flex", alignItems:"center", gap:5 }}>
              <div style={{ width:6, height:6, borderRadius:3, background:T.success, animation:"pulse 1.5s ease infinite" }}/>
              <span style={{ fontSize:8.5, fontWeight:700, color:T.success }}>3 active numbers</span>
            </div>
          </div>
          <div style={{ position:"absolute", top:16, right:8, background:`linear-gradient(135deg, ${T.accent}, ${T.accentDark})`, borderRadius:12, padding:"7px 12px", boxShadow:`0 6px 20px ${T.accent}40` }}>
            <div style={{ color:"white", fontSize:9, fontWeight:700 }}>📞 Incoming call</div>
            <div style={{ color:"rgba(255,255,255,0.7)", fontSize:8, marginTop:2 }}>+1 415 823-4921</div>
          </div>
        </div>
      ),
      tag: "ALL IN ONE PLACE",
      title: "Multiple numbers,\none clean app.",
      sub: "Manage all your virtual numbers, calls, and messages in a single beautiful dashboard. No more juggling apps.",
    },
    {
      accent: "#FEFCE8",
      accentStrong: T.warning,
      visual: (
        <div style={{ position:"relative", width:260, height:240, margin:"0 auto", display:"flex", alignItems:"center", justifyContent:"center" }}>
          <div style={{ width:150, height:150, borderRadius:"50%", background:"white", display:"flex", alignItems:"center", justifyContent:"center", boxShadow:"0 16px 48px rgba(0,0,0,0.08)" }}>
            <svg width="58" height="58" viewBox="0 0 24 24" fill="none" stroke={T.warning} strokeWidth="1.4" strokeLinecap="round">
              <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/>
            </svg>
          </div>
          {[
            { txt:"🔒 Encrypted", color:T.accent,   style:{top:22,left:8}   },
            { txt:"✓ Verified",   color:T.success,  style:{top:56,right:4}  },
            { txt:"🚫 No spam",   color:T.warning,  style:{bottom:42,left:16} },
            { txt:"👁 Private",   color:"#7C3AED",  style:{bottom:12,right:14} },
          ].map((b,i)=>(
            <div key={i} style={{ position:"absolute", ...b.style, background:"white", borderRadius:16, padding:"5px 10px", fontSize:9.5, fontWeight:700, color:b.color, boxShadow:"0 3px 12px rgba(0,0,0,0.08)", whiteSpace:"nowrap" }}>{b.txt}</div>
          ))}
        </div>
      ),
      tag: "PRIVACY FIRST",
      title: "Private, secure,\nfully yours.",
      sub: "Your real number stays completely hidden. Every call is encrypted. Your identity stays verified — on your terms.",
    },
  ];

  const sl = slides[step];

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:sl.accent, overflow:"hidden", transition:"background 0.5s ease" }}>
      <StatusBar />
      <div style={{ display:"flex", justifyContent:"flex-end", padding:"0 22px 4px" }}>
        {step < slides.length - 1 && (
          <button onClick={onDone} style={{ background:"none", border:"none", fontSize:13, color:T.textMid, cursor:"pointer", fontWeight:500, padding:"4px 0" }}>Skip</button>
        )}
      </div>

      <div key={`v${step}`} style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", padding:"0 20px", animation:"fadeUp 0.45s ease both" }}>
        {sl.visual}
      </div>

      <div style={{ background:"white", borderRadius:"28px 28px 0 0", padding:"28px 26px 36px", boxShadow:"0 -8px 32px rgba(0,0,0,0.06)" }}>
        <div key={`c${step}`} style={{ animation:"fadeUp 0.45s ease 0.08s both" }}>
          <div style={{ display:"inline-flex", alignItems:"center", gap:5, background:sl.accent, color:sl.accentStrong, fontSize:9.5, fontWeight:700, letterSpacing:1.6, padding:"4px 11px", borderRadius:20, marginBottom:14 }}>
            {sl.tag}
          </div>
          <h1 style={{ fontFamily:"'Instrument Serif', Georgia, serif", fontSize:30, fontWeight:400, color:T.text, lineHeight:1.22, marginBottom:10, whiteSpace:"pre-line" }}>{sl.title}</h1>
          <p style={{ fontSize:13.5, color:T.textMid, lineHeight:1.7, marginBottom:28 }}>{sl.sub}</p>
        </div>

        <div style={{ display:"flex", gap:5, marginBottom:22, alignItems:"center" }}>
          {slides.map((_,i)=>(
            <div key={i} style={{ height:3, borderRadius:2, background:i===step?T.accent:T.border, width:i===step?26:7, transition:"all 0.35s ease" }}/>
          ))}
        </div>

        <button className="press" onClick={() => step < slides.length-1 ? setStep(s=>s+1) : onDone()} style={{
          width:"100%", height:54,
          background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`,
          border:"none", borderRadius:16, color:"white", fontSize:15, fontWeight:600,
          cursor:"pointer", letterSpacing:"-0.2px",
          boxShadow:`0 8px 24px ${T.accent}44`,
          transition:"transform 0.12s ease",
        }}>
          {step === slides.length-1 ? "Get Started — It's Free →" : "Continue →"}
        </button>
        {step===0 && (
          <button onClick={onDone} style={{ width:"100%", height:42, background:"none", border:"none", color:T.textLight, fontSize:13, cursor:"pointer", marginTop:4 }}>
            I already have an account · Log in
          </button>
        )}
      </div>
    </div>
  );
}

// ─── DASHBOARD ───────────────────────────────────────────────────
function Dashboard({ setScreen }) {
  const [numbers, setNumbers] = useState(NUMBERS);

  const totalMissed = numbers.reduce((a,n)=>a+n.missedCalls, 0);

  return (
    <div style={{ flex:1, overflowY:"auto", scrollbarWidth:"none", background:T.bg }}>
      {/* Header */}
      <div style={{ background:"white", padding:"4px 22px 20px", borderBottom:`1px solid ${T.border}` }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
          <div>
            <p style={{ fontSize:10.5, color:T.textLight, fontWeight:600, letterSpacing:1.2, margin:0 }}>GOOD MORNING</p>
            <h2 style={{ fontFamily:"'Instrument Serif', serif", fontSize:26, fontWeight:400, color:T.text, margin:"3px 0 0", letterSpacing:"-0.3px" }}>Vusi Hal 👋</h2>
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center" }}>
            <button style={{ width:40, height:40, borderRadius:12, background:T.surfaceAlt, border:`1px solid ${T.border}`, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke={T.textMid} strokeWidth="1.8" strokeLinecap="round">
                <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>
              </svg>
              {totalMissed > 0 && (
                <div style={{ position:"absolute", top:7, right:7, width:8, height:8, borderRadius:4, background:T.danger, border:"1.5px solid white", animation:"badgePop 0.4s ease" }}/>
              )}
            </button>
            <div style={{ width:40, height:40, borderRadius:12, background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, fontWeight:700, color:"white", boxShadow:`0 4px 12px ${T.accent}40` }}>V</div>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{ display:"flex", gap:8 }}>
          {[
            { label:"Numbers",  value:numbers.length, icon:"M9 12h6M9 16h4M13 4H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V9z M13 4v5h5", color:T.accent },
            { label:"Messages", value:55,             icon:"M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z", color:T.success },
            { label:"Calls",    value:15,             icon:"M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z", color:T.warning },
          ].map((s,i)=>(
            <div key={i} style={{ flex:1, background:T.surfaceAlt, borderRadius:13, padding:"12px 10px", border:`1px solid ${T.border}`, animation:`fadeUp 0.4s ease ${i*0.07}s both` }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={s.color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom:6 }}>
                <path d={s.icon}/>
              </svg>
              <div style={{ fontSize:22, fontWeight:700, color:T.text, letterSpacing:"-0.5px" }}>{s.value}</div>
              <div style={{ fontSize:10, color:T.textLight, fontWeight:500, marginTop:1 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding:"20px 18px 0" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
          <h3 style={{ fontSize:15, fontWeight:600, color:T.text, letterSpacing:"-0.2px" }}>Your Numbers</h3>
          <button onClick={()=>setScreen("picker")} style={{ fontSize:12.5, color:T.accent, fontWeight:600, background:"none", border:"none", cursor:"pointer", display:"flex", alignItems:"center", gap:3 }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={T.accent} strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add new
          </button>
        </div>

        {numbers.map((num,i) => (
          <NumberCard key={num.id} num={num} i={i} setScreen={setScreen}/>
        ))}

        {/* CTA */}
        <div onClick={()=>setScreen("picker")} className="press" style={{
          background:`linear-gradient(145deg, ${T.accent} 0%, ${T.accentDark} 100%)`,
          borderRadius:20, padding:"20px", marginBottom:28,
          cursor:"pointer", animation:`fadeUp 0.4s ease 0.3s both`,
          boxShadow:`0 8px 24px ${T.accent}30`,
          transition:"transform 0.12s ease",
        }}>
          <div style={{ fontSize:22, marginBottom:8 }}>🌍</div>
          <div style={{ color:"white", fontSize:14, fontWeight:600, marginBottom:4, letterSpacing:"-0.2px" }}>Add another country</div>
          <div style={{ color:"rgba(255,255,255,0.62)", fontSize:12, lineHeight:1.6 }}>Real local numbers in 100+ countries. From just $1/month.</div>
          <div style={{ marginTop:12, color:"white", fontSize:12, fontWeight:600, display:"flex", alignItems:"center", gap:4 }}>
            Browse all countries
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function NumberCard({ num, i, setScreen }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div style={{
      background:"white", borderRadius:20, marginBottom:12, overflow:"hidden",
      border:`1px solid ${T.border}`,
      animation:`fadeUp 0.4s ease ${0.08+i*0.1}s both`,
      boxShadow:"0 1px 8px rgba(0,0,0,0.04)",
    }}>
      {/* Color accent stripe */}
      <div style={{ height:3, background:num.color }}/>
      <div style={{ padding:"15px 16px" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:44, height:44, borderRadius:14, background:T.surfaceAlt, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22 }}>{num.flag}</div>
            <div>
              <div style={{ fontSize:15, fontWeight:600, color:T.text, letterSpacing:"-0.4px" }}>{num.number}</div>
              <div style={{ fontSize:11, color:T.textLight, marginTop:1 }}>{num.country}</div>
            </div>
          </div>
          <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:4 }}>
            <span style={{ background:num.type==="permanent"?T.accentLight:T.successLight, color:num.type==="permanent"?T.accent:T.success, fontSize:9.5, fontWeight:700, padding:"3px 9px", borderRadius:20, letterSpacing:0.3 }}>
              {num.type==="permanent" ? "Permanent" : `⏱ ${num.expiresIn}`}
            </span>
            <span style={{ background:T.surfaceAlt, color:T.textMid, fontSize:9.5, fontWeight:600, padding:"3px 9px", borderRadius:20 }}>{num.plan}</span>
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display:"flex", gap:7, marginBottom:13 }}>
          {[
            { icon:"M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z", v:num.calls,       l:"calls",    c:T.accent },
            { icon:"M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z", v:num.sms,         l:"messages", c:T.success },
            { icon:"M12 2v10M12 22v-4M4.93 4.93l7.07 7.07M19.07 4.93l-7.07 7.07M2 12h10M22 12h-4M4.93 19.07l7.07-7.07M19.07 19.07l-7.07-7.07", v:num.lastActivity, l:"last active", c:T.warning },
          ].map((s,i)=>(
            <div key={i} style={{ flex:1, background:T.surfaceAlt, borderRadius:10, padding:"9px 7px", textAlign:"center" }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={s.c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom:4 }}>
                <path d={s.icon}/>
              </svg>
              <div style={{ fontSize:12.5, fontWeight:700, color:T.text, letterSpacing:"-0.2px" }}>{s.v}</div>
              <div style={{ fontSize:9, color:T.textLight, marginTop:1 }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div style={{ display:"flex", gap:7 }}>
          <button className="action-btn press" style={{ flex:1, height:38, background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`, border:"none", borderRadius:11, color:"white", fontSize:12, fontWeight:600, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:5, boxShadow:`0 3px 10px ${T.accent}33`, transition:"transform 0.1s" }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>
            Call
          </button>
          <button className="action-btn press" onClick={()=>setScreen("inbox")} style={{ flex:1, height:38, background:T.surfaceAlt, border:`1px solid ${T.border}`, borderRadius:11, color:T.text, fontSize:12, fontWeight:600, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:5, transition:"transform 0.1s" }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={T.textMid} strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
            Message
          </button>
          <button className="action-btn press" onClick={()=>setExpanded(!expanded)} style={{ width:38, height:38, background:T.surfaceAlt, border:`1px solid ${T.border}`, borderRadius:11, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", transition:"all 0.1s" }}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={T.textMid} strokeWidth="2" strokeLinecap="round" style={{ transform: expanded ? "rotate(90deg)":"rotate(0deg)", transition:"transform 0.2s" }}>
              <circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>
            </svg>
          </button>
        </div>

        {/* Expanded options */}
        {expanded && (
          <div style={{ marginTop:10, padding:"10px", background:T.surfaceAlt, borderRadius:12, animation:"fadeUp 0.2s ease", display:"flex", gap:7 }}>
            {[
              { label:"Share", icon:"M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8M16 6l-4-4-4 4M12 2v13" },
              { label:"Settings", icon:"M12 15a3 3 0 100-6 3 3 0 000 6z" },
              { label:"Delete", icon:"M3 6h18M8 6V4h8v2M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6", danger:true },
            ].map((opt,i)=>(
              <button key={i} style={{ flex:1, height:34, background:opt.danger?T.dangerLight:"white", border:`1px solid ${opt.danger?T.danger:T.border}`, borderRadius:9, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:4, fontSize:11, fontWeight:600, color:opt.danger?T.danger:T.textMid }}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d={opt.icon}/></svg>
                {opt.label}
              </button>
            ))}
          </div>
        )}

        {num.missedCalls > 0 && (
          <div style={{ marginTop:10, background:T.dangerLight, borderRadius:10, padding:"8px 12px", display:"flex", alignItems:"center", gap:8 }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={T.danger} strokeWidth="2.5" strokeLinecap="round">
              <polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>
            </svg>
            <span style={{ fontSize:12, color:T.danger, fontWeight:700 }}>{num.missedCalls} missed call{num.missedCalls>1?"s":""}</span>
            <span style={{ fontSize:11, color:T.textLight, marginLeft:"auto", fontWeight:500 }}>View →</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── NUMBER PICKER ───────────────────────────────────────────────
function Picker({ setScreen }) {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [type, setType] = useState("permanent");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [genNum, setGenNum] = useState("");
  const [filter, setFilter] = useState("all");

  const list = COUNTRIES.filter(c => {
    const q = search.toLowerCase();
    const mq = c.name.toLowerCase().includes(q) || c.prefix.includes(q) || c.code.toLowerCase().includes(q);
    const mf = filter==="all" || (filter==="popular"&&c.popular) || (filter==="instant"&&c.instant);
    return mq && mf;
  });

  const provision = () => {
    if (!selected) return;
    setLoading(true);
    setTimeout(()=>{ setGenNum(genNumber(selected.prefix)); setLoading(false); setDone(true); }, 2400);
  };

  if (done) return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", background:"white", padding:"0 32px", animation:"fadeIn 0.3s ease" }}>
      <div style={{ width:76, height:76, borderRadius:38, background:T.successLight, display:"flex", alignItems:"center", justifyContent:"center", marginBottom:22, animation:"pop 0.5s ease" }}>
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke={T.success} strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
      </div>
      <h2 style={{ fontFamily:"'Instrument Serif', serif", fontSize:26, fontWeight:400, color:T.text, textAlign:"center", marginBottom:8 }}>Number Activated! 🎉</h2>
      <p style={{ fontSize:13, color:T.textMid, textAlign:"center", marginBottom:28, lineHeight:1.7 }}>Your new {selected.name} number is live and ready to use.</p>
      <div style={{ background:T.surfaceAlt, borderRadius:18, padding:"18px 24px", marginBottom:28, border:`1px solid ${T.border}`, textAlign:"center", width:"100%" }}>
        <div style={{ fontSize:32, marginBottom:8 }}>{selected.flag}</div>
        <div style={{ fontSize:22, fontWeight:700, color:T.text, letterSpacing:"-0.5px" }}>{genNum}</div>
        <div style={{ fontSize:11, color:T.textLight, marginTop:4, marginBottom:10 }}>{selected.name} · {type}</div>
        <div style={{ background:T.successLight, borderRadius:10, padding:"5px 12px", display:"inline-flex", alignItems:"center", gap:6 }}>
          <div style={{ width:6, height:6, borderRadius:3, background:T.success, animation:"pulse 1.5s ease infinite" }}/>
          <span style={{ fontSize:11, fontWeight:700, color:T.success }}>Active</span>
        </div>
      </div>
      <button className="press" onClick={()=>{setDone(false);setSelected(null);setSearch("");}} style={{ width:"100%", height:52, background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`, border:"none", borderRadius:16, color:"white", fontSize:15, fontWeight:600, cursor:"pointer", boxShadow:`0 8px 24px ${T.accent}40`, transition:"transform 0.12s" }}>Done</button>
    </div>
  );

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
      {/* Header */}
      <div style={{ background:"white", padding:"6px 20px 0", borderBottom:`1px solid ${T.border}`, flexShrink:0 }}>
        <h2 style={{ fontFamily:"'Instrument Serif', serif", fontSize:22, fontWeight:400, color:T.text, margin:"0 0 2px", letterSpacing:"-0.2px" }}>Get a Number</h2>
        <p style={{ fontSize:12, color:T.textLight, margin:"0 0 14px" }}>Pick a country — number generated instantly</p>
        <div style={{ position:"relative", marginBottom:11 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={T.textLight} strokeWidth="2" strokeLinecap="round" style={{ position:"absolute", left:13, top:"50%", transform:"translateY(-50%)" }}>
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search country or code…"
            style={{ width:"100%", height:42, borderRadius:12, border:`1.5px solid ${T.border}`, background:T.surfaceAlt, paddingLeft:37, paddingRight:14, fontSize:13.5, color:T.text, outline:"none", fontFamily:"inherit" }}/>
        </div>
        <div style={{ display:"flex", gap:7, paddingBottom:14, overflowX:"auto", scrollbarWidth:"none" }}>
          {[{id:"all",l:"All"},{id:"popular",l:"⭐ Popular"},{id:"instant",l:"⚡ Instant"}].map(f=>(
            <button key={f.id} onClick={()=>setFilter(f.id)} style={{ flexShrink:0, height:28, padding:"0 13px", borderRadius:20, border:`1.5px solid ${filter===f.id?T.accent:T.border}`, background:filter===f.id?T.accentLight:T.surface, color:filter===f.id?T.accent:T.textMid, fontSize:11.5, fontWeight:600, cursor:"pointer", transition:"all 0.15s" }}>
              {f.l}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      <div style={{ flex:1, overflowY:"auto", scrollbarWidth:"none", padding:"10px 14px" }}>
        {list.length === 0 && <div style={{ textAlign:"center", padding:"40px 0", color:T.textLight, fontSize:13 }}>No countries found</div>}
        {list.map((c,i)=>(
          <div key={c.code} className="country-row" onClick={()=>setSelected(c)} style={{
            display:"flex", alignItems:"center", padding:"11px 13px", borderRadius:14, marginBottom:6,
            background:selected?.code===c.code?T.accentLight:T.surface,
            border:`1.5px solid ${selected?.code===c.code?T.accent:T.border}`,
            cursor:"pointer", transition:"all 0.15s ease",
            animation:`fadeUp 0.3s ease ${i*0.02}s both`,
          }}>
            <span style={{ fontSize:22, marginRight:11 }}>{c.flag}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13.5, fontWeight:600, color:T.text }}>{c.name}</div>
              <div style={{ fontSize:11, color:T.textLight, marginTop:1 }}>{c.prefix}</div>
            </div>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:4 }}>
              <div style={{ fontSize:13.5, fontWeight:700, color:T.text }}>${c.price}<span style={{ fontSize:10, fontWeight:400, color:T.textLight }}>/mo</span></div>
              <div style={{ fontSize:9, fontWeight:700, padding:"2px 7px", borderRadius:10, background:c.instant?T.successLight:T.surfaceAlt, color:c.instant?T.success:T.textLight }}>{c.instant?"⚡ Instant":"📋 Docs req."}</div>
            </div>
            {selected?.code===c.code && (
              <div style={{ width:18, height:18, borderRadius:9, background:T.accent, display:"flex", alignItems:"center", justifyContent:"center", marginLeft:10, animation:"pop 0.2s ease" }}>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Bottom action */}
      {selected && (
        <div style={{ background:"white", borderTop:`1px solid ${T.border}`, padding:"14px 18px 20px", boxShadow:"0 -8px 30px rgba(0,0,0,0.06)", flexShrink:0, animation:"slideUp 0.3s ease" }}>
          <div style={{ display:"flex", gap:7, marginBottom:12 }}>
            {["permanent","temporary"].map(t=>(
              <button key={t} onClick={()=>setType(t)} style={{ flex:1, height:37, borderRadius:10, border:`1.5px solid ${type===t?T.accent:T.border}`, background:type===t?T.accentLight:T.surface, color:type===t?T.accent:T.textMid, fontSize:12, fontWeight:600, cursor:"pointer", transition:"all 0.15s" }}>
                {t==="permanent" ? "🔒 Permanent" : "⏱ 7-Day Temp"}
              </button>
            ))}
          </div>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:12, padding:"10px 12px", background:T.surfaceAlt, borderRadius:12 }}>
            <div style={{ display:"flex", alignItems:"center", gap:9 }}>
              <span style={{ fontSize:20 }}>{selected.flag}</span>
              <div>
                <div style={{ fontSize:12.5, fontWeight:600, color:T.text }}>{selected.name}</div>
                <div style={{ fontSize:10.5, color:T.textLight }}>{selected.prefix} · {type}</div>
              </div>
            </div>
            <div style={{ fontSize:19, fontWeight:700, color:T.text }}>${type==="temporary"?"0.99":selected.price}<span style={{ fontSize:10, fontWeight:400, color:T.textLight }}>/mo</span></div>
          </div>
          <button onClick={provision} disabled={loading} className={loading?"":"press"} style={{
            width:"100%", height:52,
            background:loading?T.accentLight:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`,
            border:"none", borderRadius:15, color:loading?T.accent:"white", fontSize:14, fontWeight:600,
            cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:10,
            transition:"transform 0.12s", boxShadow:loading?"none":`0 8px 24px ${T.accent}40`,
          }}>
            {loading ? (
              <><div style={{ width:17, height:17, border:`2px solid ${T.accentLight}`, borderTopColor:T.accent, borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/> Generating your number…</>
            ) : `Get ${selected.name} Number →`}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── INBOX ───────────────────────────────────────────────────────
function Inbox() {
  const [tab, setTab] = useState("messages");
  const [convo, setConvo] = useState(null);
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState([
    { id:1, from:"them", text:"Hey, are you free for a call tomorrow?",           time:"2:14 PM" },
    { id:2, from:"them", text:"I wanted to discuss the project timeline in detail", time:"2:15 PM" },
    { id:3, from:"me",   text:"Sure! I'm free after 3pm 👍",                       time:"2:18 PM" },
  ]);
  const endRef = useRef(null);

  const send = () => {
    if (!input.trim()) return;
    setMsgs(p=>[...p,{id:p.length+1,from:"me",text:input,time:"Now"}]);
    setInput("");
    setTimeout(()=>endRef.current?.scrollIntoView({behavior:"smooth"}), 50);
  };

  if (convo) return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", background:T.bg, overflow:"hidden" }}>
      {/* Chat header */}
      <div style={{ background:"white", padding:"12px 16px", borderBottom:`1px solid ${T.border}`, display:"flex", alignItems:"center", gap:11, flexShrink:0 }}>
        <button onClick={()=>setConvo(null)} style={{ background:"none", border:"none", cursor:"pointer", padding:4, display:"flex" }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={T.text} strokeWidth="2.2" strokeLinecap="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div style={{ width:38, height:38, borderRadius:12, background:T.accentLight, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>{convo.flag}</div>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:14.5, fontWeight:600, color:T.text }}>{convo.name}</div>
          <div style={{ fontSize:10.5, color:T.textLight }}>{convo.number}</div>
        </div>
        <button style={{ width:36, height:36, borderRadius:11, background:T.successLight, border:"none", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={T.success} strokeWidth="2.2" strokeLinecap="round">
            <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
          </svg>
        </button>
      </div>

      {/* Messages */}
      <div style={{ flex:1, overflowY:"auto", padding:"14px 14px", display:"flex", flexDirection:"column", gap:8, scrollbarWidth:"none" }}>
        <div style={{ textAlign:"center", fontSize:10.5, color:T.textLight, margin:"0 0 6px", fontWeight:500 }}>Today</div>
        {msgs.map(m=>(
          <div key={m.id} style={{ display:"flex", justifyContent:m.from==="me"?"flex-end":"flex-start", animation:"fadeUp 0.2s ease" }}>
            <div style={{
              maxWidth:"76%", padding:"10px 13px",
              borderRadius:m.from==="me"?"18px 18px 4px 18px":"18px 18px 18px 4px",
              background:m.from==="me"?`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`:"white",
              color:m.from==="me"?"white":T.text,
              fontSize:13.5, lineHeight:1.55,
              boxShadow:m.from==="me"?`0 2px 10px ${T.accent}30`:`0 1px 4px rgba(0,0,0,0.06)`,
              border:m.from==="me"?"none":`1px solid ${T.border}`,
            }}>
              {m.text}
              <div style={{ fontSize:9.5, color:m.from==="me"?"rgba(255,255,255,0.5)":T.textLight, marginTop:4, textAlign:"right" }}>{m.time}</div>
            </div>
          </div>
        ))}
        <div ref={endRef}/>
      </div>

      {/* Input */}
      <div style={{ background:"white", borderTop:`1px solid ${T.border}`, padding:"10px 13px", display:"flex", gap:9, alignItems:"center", flexShrink:0 }}>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Message…"
          style={{ flex:1, height:42, borderRadius:21, border:`1.5px solid ${T.border}`, background:T.surfaceAlt, padding:"0 16px", fontSize:13.5, outline:"none", fontFamily:"inherit", color:T.text }}/>
        <button onClick={send} className="press" style={{ width:42, height:42, borderRadius:21, background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`, border:"none", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, boxShadow:`0 3px 12px ${T.accent}44`, transition:"transform 0.12s" }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
            <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
          </svg>
        </button>
      </div>
    </div>
  );

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
      <div style={{ background:"white", padding:"10px 20px 0", borderBottom:`1px solid ${T.border}`, flexShrink:0 }}>
        <h2 style={{ fontFamily:"'Instrument Serif', serif", fontSize:22, fontWeight:400, color:T.text, margin:"0 0 14px", letterSpacing:"-0.2px" }}>Inbox</h2>
        <div style={{ display:"flex", gap:0 }}>
          {[{id:"messages",l:"Messages"},{id:"calls",l:"Call Log"}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{ flex:1, height:37, background:"none", border:"none", borderBottom:`2px solid ${tab===t.id?T.accent:"transparent"}`, color:tab===t.id?T.accent:T.textLight, fontSize:13.5, fontWeight:tab===t.id?600:400, cursor:"pointer", transition:"all 0.15s" }}>
              {t.l}
            </button>
          ))}
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", scrollbarWidth:"none" }}>
        {tab==="messages" ? MESSAGES.map(m=>(
          <div key={m.id} className="msg-row" onClick={()=>setConvo(m)} style={{ display:"flex", alignItems:"center", padding:"13px 18px", gap:11, borderBottom:`1px solid ${T.border}`, background:"white", cursor:"pointer", transition:"background 0.12s" }}>
            <div style={{ width:46, height:46, borderRadius:15, background:m.unread>0?T.accentLight:T.surfaceAlt, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0, position:"relative" }}>
              {m.flag}
              {m.type==="missed" && (
                <div style={{ position:"absolute", bottom:0, right:0, width:15, height:15, borderRadius:8, background:T.danger, border:"2px solid white", display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <svg width="7" height="7" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5" strokeLinecap="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/></svg>
                </div>
              )}
              {m.type==="voicemail" && (
                <div style={{ position:"absolute", bottom:0, right:0, width:15, height:15, borderRadius:8, background:T.warning, border:"2px solid white", display:"flex", alignItems:"center", justifyContent:"center", fontSize:8 }}>🎤</div>
              )}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:3 }}>
                <span style={{ fontSize:13.5, fontWeight:m.unread>0?700:500, color:T.text }}>{m.name}</span>
                <span style={{ fontSize:10.5, color:T.textLight, flexShrink:0 }}>{m.time}</span>
              </div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontSize:12.5, color:m.type==="missed"?T.danger:T.textMid, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", maxWidth:200, fontWeight:m.type==="missed"?600:400 }}>
                  {m.type==="missed" ? "Missed call" : m.type==="voicemail" ? `Voicemail · ${m.preview.split(": ")[1]}` : m.preview}
                </span>
                {m.unread > 0 && (
                  <div style={{ width:18, height:18, borderRadius:9, background:T.accent, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, color:"white", fontWeight:700, flexShrink:0, marginLeft:6, animation:"badgePop 0.3s ease" }}>{m.unread}</div>
                )}
              </div>
            </div>
          </div>
        )) : CALLS.map(cl=>(
          <div key={cl.id} className="call-row" style={{ display:"flex", alignItems:"center", padding:"13px 18px", gap:11, borderBottom:`1px solid ${T.border}`, background:"white", transition:"background 0.12s", cursor:"pointer" }}>
            <div style={{ width:46, height:46, borderRadius:15, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, background:cl.type==="missed"?T.dangerLight:cl.type==="incoming"?T.successLight:T.accentLight }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke={cl.type==="missed"?T.danger:cl.type==="incoming"?T.success:T.accent} strokeWidth="2" strokeLinecap="round">
                {cl.type==="outgoing" ? (
                  <><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/><polyline points="16 2 22 2 22 8"/><line x1="16" y1="8" x2="22" y2="2"/></>
                ) : cl.type==="missed" ? (
                  <><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/><line x1="23" y1="1" x2="17" y2="7"/><line x1="17" y1="1" x2="23" y2="7"/></>
                ) : cl.type==="voicemail" ? (
                  <><line x1="2" y1="12" x2="22" y2="12"/><circle cx="6" cy="12" r="4"/><circle cx="18" cy="12" r="4"/></>
                ) : (
                  <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
                )}
              </svg>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13.5, fontWeight:600, color:cl.type==="missed"?T.danger:T.text, marginBottom:3 }}>{cl.name}</div>
              <div style={{ fontSize:11.5, color:T.textLight, display:"flex", alignItems:"center", gap:5 }}>
                <span>{cl.flag} {cl.number}</span>
                {cl.duration && <><span>·</span><span>{cl.duration}</span></>}
              </div>
            </div>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:5 }}>
              <span style={{ fontSize:11, color:T.textLight }}>{cl.time}</span>
              <div style={{ fontSize:9, fontWeight:700, padding:"2px 8px", borderRadius:10, background:cl.type==="missed"?T.dangerLight:cl.type==="voicemail"?T.surfaceAlt:cl.type==="incoming"?T.successLight:T.accentLight, color:cl.type==="missed"?T.danger:cl.type==="voicemail"?T.textMid:cl.type==="incoming"?T.success:T.accent }}>
                {cl.type==="missed"?"Missed":cl.type==="voicemail"?"Voicemail":cl.type==="incoming"?"Incoming":"Outgoing"}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── SETTINGS ───────────────────────────────────────────────────
function Settings() {
  const [notifications, setNotifications] = useState(true);
  const [biometric, setBiometric] = useState(false);
  const [callForwarding, setCallForwarding] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  const Toggle = ({ value, onChange }) => (
    <div onClick={()=>onChange(!value)} style={{ width:46, height:26, borderRadius:13, background:value?T.accent:T.border, cursor:"pointer", transition:"background 0.2s", position:"relative", flexShrink:0 }}>
      <div style={{ position:"absolute", top:3, left:value?23:3, width:20, height:20, borderRadius:10, background:"white", boxShadow:"0 1px 4px rgba(0,0,0,0.18)", transition:"left 0.2s" }}/>
    </div>
  );

  const Section = ({ title, children }) => (
    <div style={{ marginBottom:20 }}>
      <div style={{ fontSize:10.5, fontWeight:700, color:T.textLight, letterSpacing:1.2, marginBottom:8, paddingLeft:4 }}>{title}</div>
      <div style={{ background:"white", borderRadius:18, border:`1px solid ${T.border}`, overflow:"hidden" }}>{children}</div>
    </div>
  );

  const Row = ({ icon, label, sublabel, right, danger, onClick, last }) => (
    <div onClick={onClick} style={{ display:"flex", alignItems:"center", gap:12, padding:"14px 16px", borderBottom:last?"none":`1px solid ${T.border}`, cursor:onClick?"pointer":"default", background:"white", transition:"background 0.12s" }}
      onMouseEnter={e=>onClick&&(e.currentTarget.style.background=T.surfaceAlt)}
      onMouseLeave={e=>e.currentTarget.style.background="white"}>
      <div style={{ width:34, height:34, borderRadius:10, background:danger?T.dangerLight:T.accentLight, display:"flex", alignItems:"center", justifyContent:"center" }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={danger?T.danger:T.accent} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d={icon}/>
        </svg>
      </div>
      <div style={{ flex:1 }}>
        <div style={{ fontSize:13.5, fontWeight:500, color:danger?T.danger:T.text }}>{label}</div>
        {sublabel && <div style={{ fontSize:11, color:T.textLight, marginTop:1 }}>{sublabel}</div>}
      </div>
      {right}
      {onClick && !right && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={T.textLight} strokeWidth="2" strokeLinecap="round"><polyline points="9 18 15 12 9 6"/></svg>}
    </div>
  );

  return (
    <div style={{ flex:1, overflowY:"auto", scrollbarWidth:"none", background:T.bg }}>
      {/* Profile */}
      <div style={{ background:"white", padding:"16px 20px 20px", borderBottom:`1px solid ${T.border}`, display:"flex", alignItems:"center", gap:14, marginBottom:20 }}>
        <div style={{ width:56, height:56, borderRadius:18, background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, fontWeight:700, color:"white", boxShadow:`0 4px 14px ${T.accent}40` }}>V</div>
        <div style={{ flex:1 }}>
          <div style={{ fontFamily:"'Instrument Serif', serif", fontSize:19, fontWeight:400, color:T.text }}>Vusi Hal</div>
          <div style={{ fontSize:12, color:T.textLight, marginTop:2 }}>vusi@dialglobal.io</div>
          <div style={{ display:"inline-flex", alignItems:"center", gap:4, background:T.goldLight, color:T.gold, fontSize:9.5, fontWeight:700, padding:"2px 8px", borderRadius:10, marginTop:5 }}>⭐ Pro Plan</div>
        </div>
        <button style={{ fontSize:12, color:T.accent, fontWeight:600, background:T.accentLight, border:"none", cursor:"pointer", padding:"6px 13px", borderRadius:10 }}>Edit</button>
      </div>

      <div style={{ padding:"0 16px" }}>
        <Section title="PREFERENCES">
          <Row icon="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9 M13.73 21a2 2 0 01-3.46 0" label="Notifications" sublabel="Calls, messages & missed alerts" right={<Toggle value={notifications} onChange={setNotifications}/>}/>
          <Row icon="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" label="Biometric Lock" sublabel="Face ID / Fingerprint" right={<Toggle value={biometric} onChange={setBiometric}/>}/>
          <Row icon="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" label="Call Forwarding" sublabel="Forward to personal number" right={<Toggle value={callForwarding} onChange={setCallForwarding}/>} last/>
        </Section>

        <Section title="ACCOUNT">
          <Row icon="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2 M12 11a4 4 0 100-8 4 4 0 000 8z" label="Personal Info" sublabel="Name, email, password" onClick={()=>{}}/>
          <Row icon="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" label="Billing & Plan" sublabel="Pro · $9.99/mo" onClick={()=>{}}/>
          <Row icon="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" label="Usage & Stats" sublabel="Calls, SMS this month" onClick={()=>{}} last/>
        </Section>

        <Section title="SUPPORT">
          <Row icon="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" label="Help & FAQ" onClick={()=>{}}/>
          <Row icon="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" label="Contact Support" sublabel="support@dialglobal.io" onClick={()=>{}} last/>
        </Section>

        <Section title="DANGER ZONE">
          <Row icon="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" label="Sign Out" danger onClick={()=>{}} last/>
        </Section>

        <div style={{ textAlign:"center", padding:"0 0 28px", color:T.textLight, fontSize:11 }}>
          DialGlobal v2.4.1 · Made with ♥ for global citizens
        </div>
      </div>
    </div>
  );
}

// ─── ROOT ────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("onboarding");

  const renderScreen = () => {
    if (screen==="onboarding") return <Onboarding onDone={()=>setScreen("home")}/>;
    if (screen==="home")       return <Dashboard setScreen={setScreen}/>;
    if (screen==="picker")     return <Picker setScreen={setScreen}/>;
    if (screen==="inbox" || screen==="calls") return <Inbox/>;
    if (screen==="settings")   return <Settings/>;
    return <Dashboard setScreen={setScreen}/>;
  };

  const navScreens = ["onboarding","home","picker","inbox","settings"];

  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(145deg, #0E0E12 0%, #131318 50%, #191922 100%)", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"28px 16px", fontFamily:"'Geist', system-ui, sans-serif" }}>
      <style>{css}</style>

      {/* Wordmark */}
      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:14 }}>
        <div style={{ width:28, height:28, borderRadius:8, background:`linear-gradient(145deg, ${T.accent}, ${T.accentDark})`, display:"flex", alignItems:"center", justifyContent:"center" }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round">
            <circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/>
            <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
          </svg>
        </div>
        <span style={{ color:"white", fontSize:17, fontWeight:600, letterSpacing:"-0.4px" }}>DialGlobal</span>
      </div>

      {/* Screen nav */}
      <div style={{ display:"flex", gap:6, marginBottom:16, flexWrap:"wrap", justifyContent:"center" }}>
        {[{id:"onboarding",l:"Onboarding"},{id:"home",l:"Dashboard"},{id:"picker",l:"Get Number"},{id:"inbox",l:"Inbox"},{id:"settings",l:"Settings"}].map((p,i)=>(
          <button key={p.id} onClick={()=>setScreen(p.id)} style={{ padding:"5px 13px", borderRadius:20, border:`1px solid ${screen===p.id?T.accent:"rgba(255,255,255,0.1)"}`, background:screen===p.id?T.accent:"rgba(255,255,255,0.04)", color:screen===p.id?"white":"rgba(255,255,255,0.4)", fontSize:11.5, fontWeight:screen===p.id?600:400, cursor:"pointer", transition:"all 0.15s" }}>
            {p.l}
          </button>
        ))}
      </div>

      {/* Phone shell */}
      <div style={{
        width:390, height:844,
        background:T.bg, borderRadius:52,
        boxShadow:"0 50px 100px rgba(0,0,0,0.6), 0 0 0 10px #1A1A22, 0 0 0 12px #252530, inset 0 0 0 1px rgba(255,255,255,0.04)",
        overflow:"hidden", display:"flex", flexDirection:"column", position:"relative",
      }}>
        {/* Dynamic island */}
        <div style={{ position:"absolute", top:14, left:"50%", transform:"translateX(-50%)", width:120, height:34, background:"#0E0E12", borderRadius:24, zIndex:30, display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
          <div style={{ width:12, height:12, borderRadius:6, background:"#1A1A22", border:"2.5px solid #2A2A35" }}/>
          <div style={{ width:8, height:8, borderRadius:4, background:"#2A2A35" }}/>
        </div>

        {/* Status bar padding for notch */}
        {screen !== "onboarding" && <StatusBar/>}

        <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
          {renderScreen()}
        </div>

        {screen !== "onboarding" && <TabBar active={screen} setScreen={setScreen}/>}
      </div>

      <p style={{ color:"rgba(255,255,255,0.15)", fontSize:10.5, marginTop:16, textAlign:"center", letterSpacing:0.3 }}>
        DialGlobal · UI Prototype for Vusi Hal · 2025
      </p>
    </div>
  );
}
