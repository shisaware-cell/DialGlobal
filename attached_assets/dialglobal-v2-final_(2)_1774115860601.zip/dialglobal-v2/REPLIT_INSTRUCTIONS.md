# DialGlobal v2.2 — Replit Update Instructions

## Quick Start
```bash
npm install
npm start
```
Copy `.env.example` → `.env` and add your keys.

---

## What Changed in v2.2 — Full Signup & Trial Flow

### New Screens Added
| Screen | File | Purpose |
|--------|------|---------|
| NumberAssignment | `src/screens/NumberAssignment.jsx` | User picks trial country, sees their number, activates trial |
| ExpiredPaywall | `src/screens/ExpiredPaywall.jsx` | Hard paywall when trial ends — immediate billing, no second trial |

### Screens Modified
| Screen | What Changed |
|--------|-------------|
| Onboarding | Now ends with "Choose a Plan" → navigates to Paywall (not Auth) |
| Paywall | Plan selection saves to context, "Continue" → Auth (not IAP) |
| Auth | Signup-first flow, leads to NumberAssignment after account creation |
| Dashboard | Trial banner now shows usage bars (mins used / SMS used) with dates |
| App.jsx | New routes: `numassign`, `expired` |
| AppContext | Added: `pendingPlan`, `selectPlan`, `trialExpired`, `expireTrial`, `trialMinsUsed`, `trialSmsUsed` |

---

## The New User Journey (in order)

```
Onboarding (3 slides)
    ↓ "Choose a Plan"
Paywall (pick Traveller / Professional / Business + billing cycle)
    ↓ "Continue →"
Auth (create account / sign in)
    ↓ account created → navigate("numassign")
NumberAssignment
    Step 1: Pick country (popular chips + full searchable list)
    Step 2: Confirm — sees number + trial benefits + plan that activates day 4
    Step 3: "Start My Free Trial →" → App Store IAP sheet (card entry)
    Step 4: Activating screen with progress steps
    ↓ success → navigate("home")
Dashboard (in-trial state)
    - Purple trial banner with usage bars
    - "Trial ends [date]" positive framing
    ↓ day 4: store charges card, isInTrial flips false
Home (full plan features unlocked)
```

**If trial expires without payment:**
```
User opens app → navigate("expired")
ExpiredPaywall — no back button, immediate billing
    - Shows their original trial plan highlighted as "YOUR TRIAL PLAN"
    - Monthly/Yearly toggle
    - "Subscribe — $X.XX/month →"
    ↓ payment → navigate("home") with full features
```

---

## Key Design Decisions

### Number Assignment Screen
- User picks country BEFORE entering card
- Emotional ownership of number before payment ask
- "Refresh" button generates different numbers in same country
- Number is shown large and prominent (ownership moment)
- Trial benefits clearly listed with amber header band
- Day 4 plan features shown in a separate card (what they're unlocking)
- Positive framing: "activates on [date]" not "expires on [date]"
- "Start My Free Trial →" → triggers App Store IAP sheet

### Trial Limits (universal — same regardless of plan chosen)
```js
// src/data/mockData.js → TRIAL_LIMITS
callMinutes:   15    // ~2-3 real calls
smsLimit:      10    // enough to test messaging
numberLimit:   1     // one country
freeCredits:  $2.00  // for overage testing
hasRecording: false  // no premium features in trial
requiresCard: true   // App Store handles this
```

### What changes on Day 4
- App Store charges card for chosen plan
- Your backend receives S2S webhook → call `fullPlanActivate()`
- `isInTrial` flips to false
- All plan features unlock (recording, auto-reply, more numbers, etc.)
- Trial banner disappears from dashboard
- Number stays — same number they had in trial

### Expired trial flow
- Trial banner on day 3 shows "Trial ends tomorrow" with notification
- Day 4: if payment fails or user cancelled → `expireTrial()` called
- On next app open → navigate("expired")
- ExpiredPaywall: no back, no trial, immediate billing
- If subscribed within 24h grace period → same number reinstated
- After 24h → DELETE number via Telnyx API: `DELETE /v2/phone_numbers/{id}`

---

## Backend TODOs

### Telnyx Number Provisioning
```js
// Called when user taps "Start My Free Trial →" AND card confirmed by App Store
// NOT before — only provision on confirmed payment

// 1. Search available numbers
GET https://api.telnyx.com/v2/available_phone_numbers
  ?filter[country_code]=US
  &filter[phone_number_type]=local
  &filter[limit]=5

// 2. Purchase number
POST https://api.telnyx.com/v2/phone_numbers
{
  "phone_number": "+14155551234",
  "connection_id": "YOUR_SIP_CONNECTION_ID"
}

// 3. On trial expiry (no payment) — ALWAYS run this
DELETE https://api.telnyx.com/v2/phone_numbers/{id}
```

### App Store Server Notifications
```js
// Listen for these Apple S2S events:
// "DID_RENEW" → trial ended, payment succeeded → call fullPlanActivate()
// "EXPIRED" → trial ended, payment failed → call expireTrial()
// "DID_CHANGE_RENEWAL_STATUS" → user cancelled → schedule expireTrial() for trial end date

// Google Play: use Google Play Developer API Real-time Developer Notifications
```

### Trial Number Cleanup Job
```js
// Run every hour — critical to avoid phantom Telnyx billing
const expiredTrials = await db.users.findAll({
  where: { trialExpired: true, numberDeleted: false,
           trialEndedAt: { $lt: new Date(Date.now() - 24*3600*1000) } }
});
for (const user of expiredTrials) {
  await telnyx.phoneNumbers.del(user.telnyxNumberId);
  await db.users.update({ numberDeleted: true }, { where: { id: user.id } });
}
```

---

## Pricing Summary (for reference)
| Plan | Monthly | Yearly | Store takes 15% | You receive |
|------|---------|--------|-----------------|-------------|
| Traveller | $7.99 | $6.42/mo ($76.99/yr) | $1.20 | $6.79 |
| Professional | $14.99 | $11.99/mo ($143.99/yr) | $2.25 | $12.74 |
| Business | $19.99 | $15.99/mo ($191.99/yr) | $3.00 | $16.99 |

Telnyx avg cost per user: $2.14 (Traveller) · $5.55 (Pro) · $9.70 (Business)
Trial cost per user: ~$0.48 avg · $2.29 worst case

---

## File Structure (v2.2)
```
src/
├── App.jsx                     ← routing, updated routes
├── context/AppContext.js       ← full state + trial management
├── components/
│   ├── UI.jsx                  ← shared components
│   └── TabBar.jsx
├── screens/
│   ├── Onboarding.jsx          ← UPDATED: ends at paywall
│   ├── Paywall.jsx             ← UPDATED: saves plan, goes to auth
│   ├── Auth.jsx                ← UPDATED: signup-first, goes to numassign
│   ├── NumberAssignment.jsx    ← NEW: country picker + trial activation
│   ├── ExpiredPaywall.jsx      ← NEW: hard paywall on trial expiry
│   ├── Dashboard.jsx           ← UPDATED: trial banner with usage bars
│   ├── [all other screens unchanged]
└── data/mockData.js            ← UPDATED: TRIAL_LIMITS added
```
