// src/screens/Credits.jsx
// Apple App Review compliance:
//   - Exact credit amounts shown before purchase
//   - All usage rates clearly listed (required disclosure)
//   - "Credits never expire" clearly stated
//   - No misleading bonus language — bonus already included in credits amount
//   - Restore Purchases button present (required by Apple)
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { CREDIT_PACKS, CREDIT_RATES } from "../data/mockData";

export default function Credits() {
  const { goBack, credits, addCredits } = useApp();
  const [loading,    setLoading]    = useState(null);
  const [justBought, setJustBought] = useState(null);
  const [showRates,  setShowRates]  = useState(false);

  const buy = (pack) => {
    setLoading(pack.id);
    // TODO: StoreKit 2 — initiate consumable IAP
    // Product ID format: com.dialglobal.credits.[c1|c2|c3|c4]
    // On successful transaction: addCredits(pack.credits)
    // credits field is the EXACT amount Apple approved for this product
    setTimeout(() => {
      addCredits(pack.credits);   // credits already includes bonus, no extra math
      setLoading(null);
      setJustBought(pack);
      setTimeout(() => setJustBought(null), 3500);
    }, 1600);
  };

  const RATES = [
    { label:"Outbound calls",   rate:`$${CREDIT_RATES.outboundCallPerMin.toFixed(3)}/min`,  note:"Calls you make to any number" },
    { label:"Inbound calls",    rate:`$${CREDIT_RATES.inboundCallPerMin.toFixed(3)}/min`,   note:"Calls you receive" },
    { label:"SMS",              rate:`$${CREDIT_RATES.smsPerMessage.toFixed(3)}/message`,   note:"Send or receive" },
    { label:"Call recording",   rate:`$${CREDIT_RATES.recordingPerMin.toFixed(3)}/min`,     note:"Per minute of recorded call" },
    { label:"Extra numbers",    rate:`$${CREDIT_RATES.extraNumberPerMonth.toFixed(2)}/mo`,  note:"Beyond your plan's number limit" },
  ];

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden" }}>

      {/* Header */}
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px",
        borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={goBack} style={{ background:"none", border:"none",
            display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{ fontSize:18, fontWeight:800, color:"var(--text-primary)" }}>
              Credit Wallet
            </h2>
            <p style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:1 }}>
              Top up to keep calling when your plan minutes run out
            </p>
          </div>
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"14px 16px" }}>

        {/* Balance card */}
        <div style={{
          background:"linear-gradient(135deg,var(--accent) 0%,var(--accent-dark) 100%)",
          borderRadius:"var(--r-xl)", padding:"20px", marginBottom:16,
          boxShadow:"var(--shadow-accent)", position:"relative", overflow:"hidden",
        }}>
          <div style={{ position:"absolute", top:-20, right:-20, width:80, height:80,
            borderRadius:"50%", background:"rgba(255,255,255,0.10)" }}/>
          <div style={{ fontSize:11, fontWeight:700, color:"rgba(255,255,255,0.65)",
            letterSpacing:1.8, marginBottom:6 }}>YOUR CREDIT BALANCE</div>
          <div style={{ fontSize:46, fontWeight:800, color:"#fff",
            letterSpacing:"-1.5px", lineHeight:1 }}>
            ${credits.toFixed(2)}
          </div>
          <div style={{ display:"flex", gap:16, marginTop:10 }}>
            <div>
              <div style={{ fontSize:13, fontWeight:700, color:"#fff" }}>
                ≈ {Math.floor(credits / CREDIT_RATES.outboundCallPerMin)} min
              </div>
              <div style={{ fontSize:10.5, color:"rgba(255,255,255,0.6)" }}>
                outbound calls
              </div>
            </div>
            <div style={{ width:1, background:"rgba(255,255,255,0.2)" }}/>
            <div>
              <div style={{ fontSize:13, fontWeight:700, color:"#fff" }}>
                ≈ {Math.floor(credits / CREDIT_RATES.smsPerMessage)} SMS
              </div>
              <div style={{ fontSize:10.5, color:"rgba(255,255,255,0.6)" }}>
                messages
              </div>
            </div>
          </div>
        </div>

        {/* Success toast */}
        {justBought && (
          <div className="fade-up" style={{ background:"var(--green-dim)",
            border:"1px solid rgba(24,168,90,0.25)", borderRadius:"var(--r-md)",
            padding:"11px 14px", marginBottom:14,
            display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:20 }}>✅</span>
            <div>
              <div style={{ fontSize:13, fontWeight:700, color:"var(--green)" }}>
                ${justBought.credits.toFixed(2)} added to your wallet
              </div>
              <div style={{ fontSize:11.5, color:"var(--text-secondary)", marginTop:1 }}>
                ≈ {justBought.approxMins} minutes of calls available
              </div>
            </div>
          </div>
        )}

        {/* How credits are used — Apple requires clear disclosure before purchase */}
        <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
          border:"1px solid var(--border)", overflow:"hidden",
          marginBottom:14, boxShadow:"var(--shadow-sm)" }}>
          <button onClick={() => setShowRates(r => !r)} style={{
            width:"100%", display:"flex", alignItems:"center",
            justifyContent:"space-between", padding:"13px 15px",
            background:"none", border:"none", cursor:"pointer",
            borderBottom: showRates ? "1px solid var(--border)" : "none",
          }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ width:34, height:34, borderRadius:10,
                background:"var(--accent-dim)",
                display:"flex", alignItems:"center",
                justifyContent:"center", fontSize:17 }}>📋</div>
              <div style={{ textAlign:"left" }}>
                <div style={{ fontSize:13.5, fontWeight:700,
                  color:"var(--text-primary)" }}>Credit usage rates</div>
                <div style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:1 }}>
                  What you're charged per minute / message
                </div>
              </div>
            </div>
            <Ic d={showRates ? "M18 15l-6-6-6 6" : "M6 9l6 6 6-6"}
              size={16} color="var(--text-muted)" sw={2.2}/>
          </button>

          {showRates && (
            <div className="fade-up">
              {RATES.map((r, i) => (
                <div key={i} style={{ display:"flex", alignItems:"center",
                  justifyContent:"space-between", padding:"10px 15px",
                  borderBottom: i < RATES.length - 1
                    ? "1px solid var(--border)" : "none", gap:12 }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:13, fontWeight:600,
                      color:"var(--text-primary)" }}>{r.label}</div>
                    <div style={{ fontSize:11.5, color:"var(--text-muted)",
                      marginTop:1 }}>{r.note}</div>
                  </div>
                  <div style={{ fontSize:13, fontWeight:800,
                    fontFamily:"var(--font-mono)",
                    color:"var(--accent)", flexShrink:0 }}>{r.rate}</div>
                </div>
              ))}
              <div style={{ padding:"10px 15px",
                background:"var(--bg-raised)",
                borderTop:"1px solid var(--border)" }}>
                <p style={{ fontSize:11.5, color:"var(--text-muted)",
                  lineHeight:1.6 }}>
                  Credits are deducted only when your plan's included minutes
                  or SMS are used up. Your plan resets at the start of each
                  billing cycle.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Credit packs */}
        <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
          letterSpacing:1.4, marginBottom:10 }}>TOP UP YOUR WALLET</div>

        {CREDIT_PACKS.map((pack, i) => (
          <div key={pack.id} className="fade-up" style={{
            background: pack.popular ? "var(--bg-card)" : "var(--bg-surface)",
            borderRadius:"var(--r-xl)", padding:"16px",
            marginBottom:10,
            border:`1.5px solid ${pack.popular
              ? "var(--accent)" : "var(--border)"}`,
            boxShadow: pack.popular
              ? "var(--shadow-accent)" : "var(--shadow-sm)",
            animationDelay:`${i*0.06}s`,
            display:"flex", alignItems:"center", gap:14,
          }}>
            <div style={{ flex:1 }}>
              {/* Pack name + badges */}
              <div style={{ display:"flex", alignItems:"center",
                flexWrap:"wrap", gap:6, marginBottom:5 }}>
                <span style={{ fontSize:15, fontWeight:800,
                  color:"var(--text-primary)" }}>{pack.label}</span>
                {pack.popular && (
                  <span style={{ fontSize:10, fontWeight:800,
                    color:"var(--accent)", background:"var(--accent-dim)",
                    padding:"2px 8px", borderRadius:99 }}>BEST VALUE</span>
                )}
                {pack.bonusLabel && (
                  <span style={{ fontSize:10, fontWeight:700,
                    color:"var(--green)", background:"var(--green-dim)",
                    padding:"2px 8px", borderRadius:99 }}>
                    {pack.bonusLabel}
                  </span>
                )}
              </div>

              {/* Exact wallet amount — Apple requires this to be unambiguous */}
              <div style={{ fontSize:13.5, fontWeight:800,
                color: pack.popular ? "var(--accent)" : "var(--text-primary)",
                marginBottom:3 }}>
                ${pack.credits.toFixed(2)} added to wallet
              </div>

              {/* Usage estimate */}
              <div style={{ fontSize:11.5, color:"var(--text-muted)" }}>
                {pack.equiv}
              </div>
            </div>

            {/* Buy button */}
            <div style={{ flexShrink:0, textAlign:"center" }}>
              <button onClick={() => buy(pack)} disabled={!!loading}
                className="press" style={{
                  height:46, padding:"0 20px",
                  background: pack.popular
                    ? "var(--accent)" : "var(--bg-raised)",
                  border: pack.popular
                    ? "none" : "1px solid var(--border-strong)",
                  borderRadius:"var(--r-md)",
                  color: pack.popular
                    ? "var(--bg-base)" : "var(--text-primary)",
                  fontSize:15, fontWeight:800,
                  cursor: loading ? "default" : "pointer",
                  display:"flex", alignItems:"center",
                  justifyContent:"center", gap:8,
                  boxShadow: pack.popular ? "var(--shadow-accent)" : "none",
                  opacity: loading && loading !== pack.id ? 0.5 : 1,
                  minWidth:80,
                }}>
                {loading === pack.id
                  ? <Spinner size={16}
                      color={pack.popular ? "var(--bg-base)" : "var(--accent)"}/>
                  : `$${pack.price}`}
              </button>
            </div>
          </div>
        ))}

        {/* Apple-required disclosures */}
        <div style={{ background:"var(--bg-raised)", borderRadius:"var(--r-md)",
          padding:"12px 14px", marginBottom:8 }}>
          <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
            letterSpacing:1.4, marginBottom:8 }}>IMPORTANT INFORMATION</div>
          {[
            "Credits are added to your wallet immediately upon purchase.",
            "Credits never expire while your subscription is active.",
            "Credits are non-refundable once used.",
            "Unused credits are forfeited if your subscription is cancelled.",
            "Purchases are processed by Apple and subject to their terms.",
          ].map((line, i) => (
            <div key={i} style={{ display:"flex", alignItems:"flex-start",
              gap:8, marginBottom: i < 4 ? 6 : 0 }}>
              <div style={{ width:4, height:4, borderRadius:"50%",
                background:"var(--text-muted)", flexShrink:0,
                marginTop:7 }}/>
              <p style={{ fontSize:11.5, color:"var(--text-secondary)",
                lineHeight:1.55 }}>{line}</p>
            </div>
          ))}
        </div>

        {/* Restore Purchases — Apple requires this button in the UI */}
        <button style={{
          width:"100%", height:44, background:"none",
          border:"1px solid var(--border)", borderRadius:"var(--r-md)",
          fontSize:13.5, fontWeight:600, color:"var(--text-secondary)",
          cursor:"pointer", marginBottom:8, fontFamily:"inherit",
          display:"flex", alignItems:"center", justifyContent:"center", gap:8,
        }}>
          <Ic d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"
            size={16} color="var(--text-secondary)" sw={2}/>
          Restore Purchases
        </button>

        <p style={{ textAlign:"center", fontSize:11,
          color:"var(--text-muted)", lineHeight:1.6,
          paddingBottom:16 }}>
          Payment charged to your Apple ID account at confirmation.
          <br/>Subscriptions managed in App Store settings.
        </p>
      </div>
    </div>
  );
}
