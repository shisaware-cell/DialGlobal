// src/screens/Onboarding.jsx
// Flow: Onboarding → Paywall → Auth → NumberAssignment → App
import React, { useState } from "react";
import { useApp } from "../context/AppContext";

const SLIDES = [
  {
    gradient: "linear-gradient(160deg, #FFF3DC 0%, #F4F1EC 100%)",
    accentColor: "#E8A020",
    icon: (
      <svg viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg" width="80" height="80">
        <circle cx="40" cy="40" r="36" fill="#E8A020" fillOpacity="0.12"/>
        <circle cx="40" cy="40" r="24" fill="#E8A020" fillOpacity="0.18"/>
        <text x="40" y="52" textAnchor="middle" fontSize="28">🌍</text>
      </svg>
    ),
    emoji: "🌍",
    eyebrow: "100+ COUNTRIES",
    title: "One number.\nAnywhere.",
    body: "Get a real virtual phone number in over 100 countries. Call and text like a local — from anywhere in the world.",
  },
  {
    gradient: "linear-gradient(160deg, #E8F5EE 0%, #F4F1EC 100%)",
    accentColor: "#18A85A",
    emoji: "📞",
    eyebrow: "REAL CALLS & SMS",
    title: "Calls to any\nnumber, worldwide.",
    body: "Make and receive calls to any mobile or landline on the planet. Get push notifications the moment someone calls.",
  },
  {
    gradient: "linear-gradient(160deg, #EDE8FF 0%, #F4F1EC 100%)",
    accentColor: "#7C3AED",
    emoji: "📡",
    eyebrow: "TRAVEL READY",
    title: "Stay online\nabroad with eSIM.",
    body: "Buy regional data plans and travel without roaming fees. One app for your number and your data.",
  },
];

export default function Onboarding() {
  const { navigate } = useApp();
  const [slide, setSlide] = useState(0);
  const s = SLIDES[slide];
  const isLast = slide === SLIDES.length - 1;

  return (
    <div style={{
      flex: 1, display: "flex", flexDirection: "column",
      background: s.gradient,
      transition: "background 0.5s ease",
      overflow: "hidden", position: "relative",
    }}>
      {/* Subtle dot texture */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none", zIndex: 0,
        backgroundImage: "radial-gradient(circle, rgba(0,0,0,0.04) 1px, transparent 1px)",
        backgroundSize: "22px 22px",
      }}/>

      {/* Skip */}
      <div style={{ display: "flex", justifyContent: "flex-end", padding: "12px 20px 0", position: "relative", zIndex: 1 }}>
        <button onClick={() => navigate("paywall")} style={{
          background: "rgba(0,0,0,0.06)", border: "none", borderRadius: 99,
          fontSize: 12.5, color: "var(--text-secondary)", fontWeight: 600,
          cursor: "pointer", padding: "5px 14px", letterSpacing: 0.2,
        }}>Skip</button>
      </div>

      {/* Illustration */}
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", position: "relative", zIndex: 1 }}>
        <div key={`ill-${slide}`} className="scale-in" style={{
          width: 200, height: 200, borderRadius: 56,
          background: "var(--bg-surface)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 96,
          boxShadow: `0 24px 64px ${s.accentColor}28, 0 4px 20px rgba(0,0,0,0.07)`,
          border: `2px solid ${s.accentColor}18`,
        }}>
          {s.emoji}
        </div>

        {/* Orbiting dots */}
        {[0,1,2].map(i => (
          <div key={i} style={{
            position: "absolute",
            width: 10, height: 10, borderRadius: "50%",
            background: s.accentColor,
            opacity: 0.25 + i * 0.15,
            top: `${35 + i * 12}%`,
            left: i % 2 === 0 ? `${18 + i * 3}%` : "auto",
            right: i % 2 !== 0 ? `${18 + i * 3}%` : "auto",
            animation: `float ${2.5 + i * 0.4}s ease-in-out ${i * 0.3}s infinite`,
          }}/>
        ))}
      </div>

      {/* Text block */}
      <div key={`txt-${slide}`} className="fade-up" style={{
        padding: "0 28px 0", marginBottom: 32, position: "relative", zIndex: 1,
      }}>
        <div style={{
          fontSize: 10.5, fontWeight: 800, letterSpacing: 2.2,
          color: s.accentColor, marginBottom: 10,
        }}>{s.eyebrow}</div>
        <h1 style={{
          fontSize: 32, fontWeight: 800, color: "var(--text-primary)",
          letterSpacing: "-0.9px", lineHeight: 1.18, marginBottom: 14,
          whiteSpace: "pre-line",
        }}>{s.title}</h1>
        <p style={{
          fontSize: 15, color: "var(--text-secondary)",
          lineHeight: 1.68, maxWidth: 300,
        }}>{s.body}</p>
      </div>

      {/* Bottom nav */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 28px 36px", position: "relative", zIndex: 1,
      }}>
        {/* Pill dots */}
        <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
          {SLIDES.map((_, i) => (
            <div key={i} onClick={() => setSlide(i)} style={{
              width: i === slide ? 24 : 7, height: 7, borderRadius: 99,
              background: i === slide ? s.accentColor : "var(--border-strong)",
              transition: "all 0.35s cubic-bezier(0.34,1.56,0.64,1)",
              cursor: "pointer",
            }}/>
          ))}
        </div>

        <button className="press" onClick={() => isLast ? navigate("paywall") : setSlide(s => s + 1)}
          style={{
            height: 52, padding: "0 28px",
            background: s.accentColor,
            border: "none", borderRadius: "var(--r-lg)",
            color: "#fff", fontSize: 15, fontWeight: 800,
            cursor: "pointer",
            boxShadow: `0 8px 24px ${s.accentColor}40`,
            display: "flex", alignItems: "center", gap: 8,
            letterSpacing: "-0.2px",
          }}>
          {isLast ? "Get Started" : "Next"}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2.8" strokeLinecap="round">
            <path d="M9 18l6-6-6-6"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
