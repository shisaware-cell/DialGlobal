// src/screens/Auth.jsx — shown AFTER paywall, before number assignment
import React, { useState } from "react";
import { Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";

export default function Auth() {
  const { navigate, pendingPlan } = useApp();
  const [mode,    setMode]    = useState("signup"); // signup first in this flow
  const [email,   setEmail]   = useState("");
  const [pass,    setPass]    = useState("");
  const [name,    setName]    = useState("");
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState(null);

  const canSubmit = email.trim() && pass.trim() && (mode === "login" || name.trim());

  const submit = () => {
    if (!canSubmit) return;
    setLoading(true);
    // TODO: call your auth API (Firebase/Supabase/custom)
    setTimeout(() => {
      setLoading(false);
      // After account created → go to number assignment
      navigate(mode === "signup" ? "numassign" : "home");
    }, 1400);
  };

  const inputStyle = (field) => ({
    width: "100%", height: 52, borderRadius: "var(--r-md)",
    border: `1.5px solid ${focused === field ? "var(--accent)" : "var(--border)"}`,
    background: focused === field ? "var(--bg-surface)" : "var(--bg-input)",
    padding: "0 16px", fontSize: 15,
    color: "var(--text-primary)", outline: "none",
    transition: "all 0.2s",
    boxShadow: focused === field ? "0 0 0 3px var(--accent-dim)" : "none",
    fontFamily: "inherit",
  });

  return (
    <div style={{
      flex: 1, display: "flex", flexDirection: "column",
      background: "var(--bg-base)", overflow: "hidden",
    }}>
      {/* Back to paywall */}
      <div style={{ padding: "10px 20px 0", display: "flex", alignItems: "center", gap: 10 }}>
        <button onClick={() => navigate("paywall")} style={{
          background: "none", border: "none", display: "flex",
          alignItems: "center", gap: 6, cursor: "pointer",
          color: "var(--text-muted)", fontSize: 13, fontWeight: 600, padding: "4px 0",
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
            <path d="M15 18l-6-6 6-6"/>
          </svg>
          Back
        </button>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "16px 24px 32px" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 28 }}>
          <div style={{
            width: 42, height: 42, borderRadius: 14,
            background: "var(--accent)",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "var(--shadow-accent)",
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
              stroke="var(--bg-base)" strokeWidth="2.2" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/>
              <line x1="2" y1="12" x2="22" y2="12"/>
              <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
            </svg>
          </div>
          <span style={{ fontSize: 19, fontWeight: 800, color: "var(--text-primary)", letterSpacing: "-0.5px" }}>
            DialGlobal
          </span>
        </div>

        <div key={mode} className="fade-up">
          <h2 style={{
            fontSize: 26, fontWeight: 800, color: "var(--text-primary)",
            letterSpacing: "-0.6px", marginBottom: 6,
          }}>
            {mode === "signup" ? "Create your account" : "Welcome back"}
          </h2>
          <p style={{ fontSize: 14, color: "var(--text-secondary)", marginBottom: 28, lineHeight: 1.6 }}>
            {mode === "signup"
              ? "One step away from your free trial number"
              : "Sign in to continue to DialGlobal"}
          </p>
        </div>

        {/* Fields */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 20 }}>
          {mode === "signup" && (
            <div className="fade-up">
              <label style={{ fontSize: 11.5, fontWeight: 700, color: "var(--text-muted)", letterSpacing: 0.6, display: "block", marginBottom: 7 }}>
                FULL NAME
              </label>
              <input
                value={name} onChange={e => setName(e.target.value)}
                onFocus={() => setFocused("name")} onBlur={() => setFocused(null)}
                placeholder="Your name"
                style={inputStyle("name")}
              />
            </div>
          )}

          <div>
            <label style={{ fontSize: 11.5, fontWeight: 700, color: "var(--text-muted)", letterSpacing: 0.6, display: "block", marginBottom: 7 }}>
              EMAIL
            </label>
            <input
              type="email" value={email} onChange={e => setEmail(e.target.value)}
              onFocus={() => setFocused("email")} onBlur={() => setFocused(null)}
              placeholder="you@example.com"
              style={inputStyle("email")}
            />
          </div>

          <div>
            <label style={{ fontSize: 11.5, fontWeight: 700, color: "var(--text-muted)", letterSpacing: 0.6, display: "block", marginBottom: 7 }}>
              PASSWORD
            </label>
            <input
              type="password" value={pass} onChange={e => setPass(e.target.value)}
              onFocus={() => setFocused("pass")} onBlur={() => setFocused(null)}
              placeholder={mode === "signup" ? "Create a password" : "Your password"}
              onKeyDown={e => e.key === "Enter" && submit()}
              style={inputStyle("pass")}
            />
          </div>
        </div>

        {mode === "login" && (
          <button style={{
            background: "none", border: "none", fontSize: 13,
            color: "var(--accent)", fontWeight: 700,
            marginBottom: 20, cursor: "pointer", padding: 0, display: "block",
          }}>Forgot password?</button>
        )}

        {/* Primary CTA */}
        <button className="press" onClick={submit} disabled={loading || !canSubmit}
          style={{
            width: "100%", height: 54, background: "var(--accent)",
            border: "none", borderRadius: "var(--r-md)",
            color: "var(--bg-base)", fontSize: 15, fontWeight: 800,
            display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
            cursor: canSubmit ? "pointer" : "default",
            boxShadow: canSubmit ? "var(--shadow-accent)" : "none",
            opacity: canSubmit ? 1 : 0.55,
            transition: "opacity 0.2s",
            marginBottom: 20,
          }}>
          {loading
            ? <><Spinner color="var(--bg-base)"/>Creating account…</>
            : mode === "signup" ? "Continue →" : "Sign In →"}
        </button>

        {/* Divider */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 18 }}>
          <div style={{ flex: 1, height: 1, background: "var(--border)" }}/>
          <span style={{ fontSize: 12, color: "var(--text-muted)", fontWeight: 500 }}>or</span>
          <div style={{ flex: 1, height: 1, background: "var(--border)" }}/>
        </div>

        {/* Social auth */}
        <div style={{ display: "flex", gap: 10, marginBottom: 28 }}>
          {[
            { label: "Google", emoji: "🔵" },
            { label: "Apple",  emoji: "⚫" },
          ].map(p => (
            <button key={p.label} className="press" onClick={() => navigate("numassign")}
              style={{
                flex: 1, height: 50, background: "var(--bg-surface)",
                border: "1.5px solid var(--border)", borderRadius: "var(--r-md)",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 9,
                fontSize: 14, fontWeight: 700, color: "var(--text-primary)",
                cursor: "pointer", boxShadow: "var(--shadow-sm)",
              }}>
              <span style={{ fontSize: 18 }}>{p.emoji}</span> {p.label}
            </button>
          ))}
        </div>

        {/* Switch mode */}
        <div style={{ textAlign: "center" }}>
          <span style={{ fontSize: 13.5, color: "var(--text-muted)" }}>
            {mode === "signup" ? "Already have an account? " : "New to DialGlobal? "}
          </span>
          <button onClick={() => setMode(mode === "signup" ? "login" : "signup")}
            style={{
              background: "none", border: "none", fontSize: 13.5,
              color: "var(--accent)", fontWeight: 800, cursor: "pointer",
            }}>
            {mode === "signup" ? "Sign in" : "Create account"}
          </button>
        </div>
      </div>
    </div>
  );
}
