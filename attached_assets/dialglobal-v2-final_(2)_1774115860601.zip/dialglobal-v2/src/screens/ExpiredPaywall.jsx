// src/screens/ExpiredPaywall.jsx
// Shown when trial has ended and user hasn't paid.
// No back button. No second trial. Immediate billing on subscribe.
import React, { useState } from "react";
import { Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { PLANS } from "../data/mockData";

export default function ExpiredPaywall() {
  const { navigate, upgradePlan, pendingPlan, trialPlan } = useApp();
  const [selected,  setSelected]  = useState(trialPlan || pendingPlan || "professional");
  const [billing,   setBilling]   = useState("monthly");
  const [loading,   setLoading]   = useState(false);

  const plan  = PLANS.find(p => p.id === selected);
  const price = billing === "yearly" ? plan.yearlyPrice : plan.monthlyPrice;

  const handleSubscribe = () => {
    setLoading(true);
    // TODO: initiate App Store IAP — NO trial, immediate charge
    setTimeout(() => {
      upgradePlan(selected, billing);
      setLoading(false);
      navigate("home");
    }, 1800);
  };

  return (
    <div style={{
      flex: 1, display: "flex", flexDirection: "column",
      background: "var(--bg-base)", overflow: "hidden",
    }}>
      {/* Top section — no close/back */}
      <div style={{
        background: "linear-gradient(160deg, #FFF0DC 0%, var(--bg-surface) 55%)",
        padding: "32px 22px 20px",
        borderBottom: "1px solid var(--border)",
        flexShrink: 0,
      }}>
        {/* Expired indicator */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 7,
          background: "rgba(224,53,53,0.1)", borderRadius: 99,
          padding: "5px 14px", marginBottom: 18,
        }}>
          <div style={{
            width: 7, height: 7, borderRadius: "50%",
            background: "var(--red)", animation: "pulse 1.5s ease infinite",
          }}/>
          <span style={{ fontSize: 12, fontWeight: 700, color: "var(--red)" }}>
            Trial ended
          </span>
        </div>

        <h2 style={{
          fontSize: 24, fontWeight: 800, color: "var(--text-primary)",
          letterSpacing: "-0.6px", marginBottom: 8, lineHeight: 1.2,
        }}>
          Subscribe to keep your number
        </h2>
        <p style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.65 }}>
          Your trial has ended. Subscribe now to reactivate your number and unlock all features.
        </p>

        {/* Billing toggle */}
        <div style={{
          display: "flex", background: "var(--bg-raised)",
          borderRadius: 99, padding: 3, marginTop: 18,
        }}>
          {[{ id: "monthly", label: "Monthly" }, { id: "yearly", label: "Yearly", badge: "Save 20%" }].map(b => (
            <button key={b.id} onClick={() => setBilling(b.id)} style={{
              flex: 1, height: 32, borderRadius: 99, border: "none",
              background: billing === b.id ? "var(--bg-surface)" : "transparent",
              color: billing === b.id ? "var(--text-primary)" : "var(--text-muted)",
              fontSize: 12.5, fontWeight: billing === b.id ? 700 : 400,
              cursor: "pointer", transition: "all 0.2s",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
              boxShadow: billing === b.id ? "var(--shadow-sm)" : "none",
            }}>
              {b.label}
              {b.badge && billing === b.id && (
                <span style={{ fontSize: 9, fontWeight: 800, background: "var(--green)",
                  color: "#fff", padding: "2px 6px", borderRadius: 99 }}>{b.badge}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Plan selector */}
      <div style={{ flex: 1, overflowY: "auto", padding: "14px 16px 8px" }}>
        {PLANS.map((p, i) => {
          const isSel = selected === p.id;
          const dp    = billing === "yearly" ? p.yearlyPrice : p.monthlyPrice;
          const wasTrial = trialPlan === p.id;
          return (
            <div key={p.id} onClick={() => setSelected(p.id)} className="press fade-up"
              style={{
                animationDelay: `${i * 0.07}s`,
                borderRadius: "var(--r-xl)", marginBottom: 10,
                border: `2px solid ${isSel ? "var(--accent)" : "var(--border)"}`,
                background: isSel ? "var(--bg-card)" : "var(--bg-surface)",
                cursor: "pointer", overflow: "hidden", position: "relative",
                boxShadow: isSel ? "var(--shadow-accent)" : "var(--shadow-sm)",
                transition: "all 0.2s cubic-bezier(0.22,1,0.36,1)",
              }}>
              {wasTrial && (
                <div style={{
                  position: "absolute", top: 0, right: 0,
                  background: "var(--accent)", color: "var(--bg-base)",
                  fontSize: 9.5, fontWeight: 800, letterSpacing: 0.8,
                  padding: "3px 10px",
                  borderRadius: "0 var(--r-xl) 0 var(--r-sm)",
                }}>YOUR TRIAL PLAN</div>
              )}
              <div style={{ display: "flex", alignItems: "center", padding: "14px 16px", gap: 12 }}>
                <div style={{
                  width: 20, height: 20, borderRadius: "50%", flexShrink: 0,
                  border: `2.5px solid ${isSel ? "var(--accent)" : "var(--border-strong)"}`,
                  background: isSel ? "var(--accent)" : "transparent",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  transition: "all 0.18s",
                  boxShadow: isSel ? "0 2px 8px var(--accent-glow)" : "none",
                }}>
                  {isSel && <div style={{ width: 7, height: 7, borderRadius: "50%", background: "white" }}/>}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15.5, fontWeight: 800, color: "var(--text-primary)",
                    letterSpacing: "-0.2px" }}>
                    {p.emoji} {p.name}
                  </div>
                  <div style={{ fontSize: 11.5, color: "var(--text-secondary)", marginTop: 2 }}>
                    {p.numberLimit} number{p.numberLimit > 1 ? "s" : ""} · {p.callMinutes} min · {p.smsLimit === 9999 ? "Unlimited SMS" : `${p.smsLimit} SMS`}
                  </div>
                  {billing === "yearly" && (
                    <div style={{ fontSize: 10.5, color: "var(--green)", fontWeight: 700, marginTop: 2 }}>
                      ${p.yearlyBilled}/yr · save ${((p.monthlyPrice - p.yearlyPrice) * 12).toFixed(2)}/yr
                    </div>
                  )}
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{
                    fontSize: 22, fontWeight: 800, fontFamily: "var(--font-mono)",
                    letterSpacing: "-0.5px",
                    color: isSel ? "var(--accent)" : "var(--text-primary)",
                  }}>${dp.toFixed(2)}</div>
                  <div style={{ fontSize: 10, color: "var(--text-muted)" }}>/month</div>
                </div>
              </div>
            </div>
          );
        })}

        <p style={{ fontSize: 12, color: "var(--text-muted)", textAlign: "center",
          lineHeight: 1.6, padding: "8px 8px 0" }}>
          No free trial on resubscription. Your number will be reactivated immediately after payment.
        </p>
      </div>

      {/* CTA */}
      <div style={{
        background: "var(--bg-surface)", borderTop: "1px solid var(--border)",
        padding: "12px 16px 26px",
      }}>
        <button className="press" onClick={handleSubscribe} disabled={loading}
          style={{
            width: "100%", height: 56, background: "var(--accent)",
            border: "none", borderRadius: "var(--r-xl)",
            color: "var(--bg-base)", fontSize: 16, fontWeight: 800,
            cursor: "pointer", boxShadow: "var(--shadow-accent)",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
            letterSpacing: "-0.2px",
          }}>
          {loading
            ? <><Spinner color="var(--bg-base)"/>Processing…</>
            : `Subscribe — $${price.toFixed(2)}/${billing === "yearly" ? "mo" : "month"} →`}
        </button>
        <p style={{ textAlign: "center", fontSize: 11, color: "var(--text-muted)", marginTop: 8 }}>
          {billing === "yearly"
            ? `$${plan.yearlyBilled} billed annually · Cancel anytime`
            : "Cancel anytime · Billed via App Store"}
        </p>
        <div style={{ display: "flex", justifyContent: "center", gap: 0, marginTop: 10 }}>
          {["Terms", "Restore", "Privacy"].map((label, i) => (
            <React.Fragment key={label}>
              {i > 0 && <span style={{ color: "var(--border-strong)", fontSize: 12, padding: "0 10px" }}>|</span>}
              <button style={{ background: "none", border: "none", fontSize: 12,
                color: "var(--text-muted)", cursor: "pointer", padding: 0 }}>{label}</button>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
