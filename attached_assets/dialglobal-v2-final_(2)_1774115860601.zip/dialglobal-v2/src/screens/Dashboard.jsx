// src/screens/Dashboard.jsx — Playful mobile-first home screen
import React, { useState } from "react";
import { Ic, DeleteSheet, Toggle } from "../components/UI";
import { useApp } from "../context/AppContext";

function QuickAction({ icon, label, color, bg, onClick }) {
  return (
    <button className="press" onClick={onClick} style={{
      flex:1, height:64, background:bg, border:"none",
      borderRadius:"var(--r-md)", display:"flex", flexDirection:"column",
      alignItems:"center", justifyContent:"center", gap:5, cursor:"pointer",
    }}>
      <Ic d={icon} size={18} color={color} sw={2.2}/>
      <span style={{fontSize:10,fontWeight:700,color,letterSpacing:0.2}}>{label}</span>
    </button>
  );
}

function NumberCard({ num, index }) {
  const { navigate, setSelectedNumber, removeNumber, dndNumbers, toggleDnd,
          recordings, toggleRecording, forwarding, toggleForwarding } = useApp();
  const [expanded, setExpanded] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  const openDetail = () => { setSelectedNumber(num); navigate("numdetail"); };
  const isPermanent = num.type === "permanent";

  return (
    <div className="fade-up" style={{animationDelay:`${index*0.08}s`, position:"relative",
      background:"var(--bg-surface)", borderRadius:"var(--r-lg)",
      marginBottom:12, overflow:"hidden", boxShadow:"var(--shadow-sm)",
      border:"1px solid var(--border)"}}>

      {/* Main row */}
      <div className="row-tap" onClick={() => setExpanded(o => !o)} style={{
        display:"flex", alignItems:"center", gap:12, padding:"14px 16px", cursor:"pointer",
      }}>
        <div style={{
          width:48, height:48, borderRadius:14, background:"var(--bg-raised)",
          display:"flex", alignItems:"center", justifyContent:"center", fontSize:22,
          flexShrink:0, position:"relative",
          boxShadow:"inset 0 1px 3px rgba(0,0,0,0.06)",
        }}>
          {num.flag}
          <div style={{position:"absolute",bottom:0,right:0,width:12,height:12,borderRadius:"50%",
            background:"var(--green)",border:"2.5px solid var(--bg-surface)"}}/>
        </div>

        <div style={{flex:1, minWidth:0}}>
          <div style={{fontSize:14,fontWeight:700,color:"var(--text-primary)",letterSpacing:"-0.3px",
            fontFamily:"var(--font-mono)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
            {num.number}
          </div>
          <div style={{display:"flex",alignItems:"center",gap:6,marginTop:3}}>
            <span style={{fontSize:11,color:"var(--text-secondary)",fontWeight:500}}>{num.country}</span>
            <span style={{width:3,height:3,borderRadius:"50%",background:"var(--border-strong)",display:"inline-block"}}/>
            <span style={{fontSize:10.5,fontWeight:700,
              color:isPermanent?"var(--accent)":"var(--green)"}}>
              {isPermanent?"Permanent":`⏱ ${num.expiresIn}`}
            </span>
          </div>
        </div>

        <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4}}>
          {num.missedCalls > 0 && (
            <div style={{display:"flex",alignItems:"center",gap:4,background:"var(--red-dim)",
              borderRadius:99,padding:"2px 8px"}}>
              <div style={{width:5,height:5,borderRadius:"50%",background:"var(--red)",
                animation:"pulse 1.5s ease infinite"}}/>
              <span style={{fontSize:10,color:"var(--red)",fontWeight:700}}>{num.missedCalls} missed</span>
            </div>
          )}
          <div style={{display:"flex",alignItems:"center",gap:1}}>
            <Ic d={expanded?"M18 15l-6-6-6 6":"M6 9l6 6 6-6"} size={16} color="var(--text-muted)" sw={2.2}/>
          </div>
        </div>
      </div>

      {/* Expanded features — inline, not in Settings */}
      {expanded && (
        <div className="fade-up" style={{borderTop:"1px solid var(--border)",padding:"12px 16px 14px"}}>
          {/* Quick actions */}
          <div style={{display:"flex",gap:8,marginBottom:12}}>
            <QuickAction
              icon="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"
              label="Call" color="var(--bg-base)" bg="var(--accent)"/>
            <QuickAction
              icon="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"
              label="Message" color="var(--blue)" bg="var(--blue-dim)"
              onClick={() => navigate("inbox")}/>
            <QuickAction
              icon="M12 20h9M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"
              label="Details" color="var(--text-secondary)" bg="var(--bg-raised)"
              onClick={openDetail}/>
          </div>

          {/* Inline feature toggles */}
          <div style={{background:"var(--bg-raised)",borderRadius:"var(--r-md)",overflow:"hidden"}}>
            {[
              {
                label:"Call Recording", sub:"Auto-save all calls",
                icon:"M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4",
                value:recordings[num.id]||false, toggle:()=>toggleRecording(num.id),
              },
              {
                label:"Call Forwarding", sub:"Route to another number",
                icon:"M5 12h14M12 5l7 7-7 7",
                value:forwarding[num.id]||false, toggle:()=>toggleForwarding(num.id),
              },
              {
                label:"Do Not Disturb", sub:"Silence this number",
                icon:"M1 1l22 22M16.72 11.06A10.94 10.94 0 0119 12.55M5 5a10.94 10.94 0 014.77-2.52M10.71 5.05A11 11 0 0122.54 9M1.42 9a9.91 9.91 0 015.33-4.36M8.53 16.11a6 6 0 006.95 0M12 20h.01",
                value:dndNumbers[num.id]||false, toggle:()=>toggleDnd(num.id),
              },
            ].map((row,i,arr)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",
                borderBottom:i<arr.length-1?"1px solid var(--border)":"none"}}>
                <div style={{width:30,height:30,borderRadius:8,background:"var(--accent-dim)",
                  display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <Ic d={row.icon} size={13} color="var(--accent)" sw={2}/>
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:12.5,fontWeight:600,color:"var(--text-primary)"}}>{row.label}</div>
                  <div style={{fontSize:10.5,color:"var(--text-muted)",marginTop:1}}>{row.sub}</div>
                </div>
                <Toggle value={row.value} onChange={row.toggle}/>
              </div>
            ))}
          </div>

          {/* Delete */}
          <button onClick={() => setShowDelete(true)} className="press" style={{
            width:"100%",height:36,marginTop:10,
            background:"var(--red-dim)",border:"1px solid rgba(224,53,53,0.15)",
            borderRadius:"var(--r-sm)",color:"var(--red)",fontSize:12,fontWeight:700,
            cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:6}}>
            <Ic d="M3 6h18M8 6V4h8v2M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6" size={13} color="var(--red)" sw={2}/>
            Release Number
          </button>
        </div>
      )}

      {showDelete && (
        <DeleteSheet
          title="Release this number?"
          body={`${num.number} will be permanently deleted and returned to the pool. This cannot be undone.`}
          confirmLabel="Yes, release"
          onClose={() => setShowDelete(false)}
          onConfirm={() => { removeNumber(num.id); setShowDelete(false); }}
        />
      )}
    </div>
  );
}

export default function Dashboard() {
  const { navigate, numbers, currentPlan, simulateIncomingCall, isInTrial, trialEnds, trialPlan, trialMinsUsed, trialSmsUsed, expireTrial } = useApp();
  const { TRIAL_LIMITS } = {TRIAL_LIMITS: {callMinutes:15, smsLimit:10}};
  const isUpgraded = currentPlan !== "trial" && currentPlan !== null;

  return (
    <div style={{flex:1, overflowY:"auto", background:"var(--bg-base)"}}>
      {/* Header */}
      <div style={{background:"var(--bg-surface)",padding:"6px 18px 16px",borderBottom:"1px solid var(--border)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
          <div>
            <p style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.8,margin:0}}>GOOD MORNING</p>
            <h2 style={{fontSize:24,fontWeight:800,color:"var(--text-primary)",margin:"3px 0 0",letterSpacing:"-0.6px"}}>
              Vusi 👋
            </h2>
          </div>
          <div style={{display:"flex",gap:9,alignItems:"center"}}>
            {/* Simulate incoming call button (demo) */}
            <button onClick={simulateIncomingCall} style={{width:40,height:40,borderRadius:"var(--r-md)",
              background:"var(--green-dim)",border:"1px solid var(--border)",
              display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",
              position:"relative"}}>
              <Ic d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"
                size={16} color="var(--green)"/>
              <div style={{position:"absolute",top:7,right:7,width:7,height:7,borderRadius:"50%",
                background:"var(--green)",border:"1.5px solid var(--bg-surface)",
                animation:"pulse 1.5s ease infinite"}}/>
            </button>
            <button onClick={() => navigate("profile")} style={{width:40,height:40,borderRadius:"var(--r-md)",
              background:"var(--accent)",border:"none",display:"flex",alignItems:"center",
              justifyContent:"center",fontSize:16,fontWeight:800,color:"var(--bg-base)",cursor:"pointer",
              boxShadow:"var(--shadow-accent)"}}>V</button>
          </div>
        </div>

        {/* Stats row */}
        <div style={{display:"flex",gap:8}}>
          {[
            {label:"Numbers", value:numbers.length, icon:"M9 12h6M9 16h4M13 4H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V9zM13 4v5h5", color:"var(--accent)", bg:"var(--accent-dim)"},
            {label:"Messages",value:55,             icon:"M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z",                        color:"var(--green)", bg:"var(--green-dim)"},
            {label:"Calls",   value:15,             icon:"M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z", color:"var(--blue)", bg:"var(--blue-dim)"},
          ].map((s,i)=>(
            <div key={i} className="fade-up" style={{flex:1,background:s.bg,borderRadius:"var(--r-md)",
              padding:"12px 10px",animationDelay:`${i*0.06}s`,cursor:"default"}}>
              <Ic d={s.icon} size={16} color={s.color} style={{marginBottom:7}}/>
              <div style={{fontSize:22,fontWeight:800,color:"var(--text-primary)",letterSpacing:"-0.5px"}}>{s.value}</div>
              <div style={{fontSize:10,color:"var(--text-secondary)",fontWeight:600,marginTop:1}}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Trial banner — shown when in active trial */}
      {isInTrial && trialEnds && (
        <div onClick={() => navigate("paywall")} style={{
          margin:"12px 16px 0",
          background:"linear-gradient(120deg,#534AB7,#7C3AED)",
          borderRadius:"var(--r-lg)", padding:"12px 16px",
          display:"flex", alignItems:"center", gap:12, cursor:"pointer",
          boxShadow:"0 6px 20px rgba(124,58,237,0.3)",
          position:"relative", overflow:"hidden",
        }}>
          <div style={{position:"absolute",top:-16,right:-16,width:64,height:64,borderRadius:"50%",background:"rgba(255,255,255,0.1)"}}/>
          <div style={{width:38,height:38,borderRadius:11,background:"rgba(255,255,255,0.2)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>⏳</div>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:800,color:"#fff"}}>Trial active — 3 days</div>
            <div style={{fontSize:11,color:"rgba(255,255,255,0.75)",marginTop:1}}>
              Limited to 15 min · 10 SMS · 1 number
            </div>
          </div>
          <div style={{background:"rgba(255,255,255,0.2)",borderRadius:99,padding:"4px 10px",fontSize:11,fontWeight:700,color:"#fff",whiteSpace:"nowrap"}}>
            Full plan day 4
          </div>
        </div>
      )}

      {/* Plan banner — shown when not yet subscribed */}
      {!isUpgraded && !isInTrial && (
        <div onClick={() => navigate("paywall")} className="press" style={{
          margin:"12px 16px 0",
          background:"linear-gradient(120deg,var(--accent) 0%,var(--accent-dark) 100%)",
          borderRadius:"var(--r-lg)",padding:"12px 16px",
          display:"flex",alignItems:"center",gap:12,cursor:"pointer",
          boxShadow:"var(--shadow-accent)",position:"relative",overflow:"hidden",
        }}>
          <div style={{position:"absolute",top:-20,right:-20,width:80,height:80,borderRadius:"50%",
            background:"rgba(255,255,255,0.12)",pointerEvents:"none"}}/>
          <div style={{width:38,height:38,borderRadius:11,background:"rgba(255,255,255,0.22)",
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>🚀</div>
          <div style={{flex:1}}>
            <div style={{fontSize:13.5,fontWeight:800,color:"#fff",letterSpacing:"-0.2px"}}>You're on Free</div>
            <div style={{fontSize:11.5,color:"rgba(255,255,255,0.75)",marginTop:2}}>Upgrade to unlock 5 numbers & recording</div>
          </div>
          <div style={{background:"rgba(255,255,255,0.22)",borderRadius:99,padding:"5px 12px",
            fontSize:11.5,fontWeight:700,color:"#fff"}}>Upgrade →</div>
        </div>
      )}

      {/* Numbers */}
      <div style={{padding:"14px 16px 8px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <h3 style={{fontSize:11,fontWeight:800,color:"var(--text-muted)",letterSpacing:1.6}}>MY NUMBERS</h3>
          <button onClick={() => navigate("picker")} style={{
            display:"flex",alignItems:"center",gap:5,fontSize:12.5,color:"var(--accent)",
            fontWeight:700,background:"var(--accent-dim)",border:"none",
            borderRadius:99,padding:"4px 12px",cursor:"pointer"}}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="3" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            Add Number
          </button>
        </div>

        {numbers.length === 0 ? (
          <div className="scale-in" style={{textAlign:"center",padding:"40px 20px",
            background:"var(--bg-surface)",borderRadius:"var(--r-xl)",border:"1.5px dashed var(--border-strong)"}}>
            <div style={{fontSize:40,marginBottom:12}}>📱</div>
            <div style={{fontSize:15,fontWeight:800,color:"var(--text-primary)",marginBottom:6}}>No numbers yet</div>
            <div style={{fontSize:12.5,color:"var(--text-muted)",marginBottom:20,lineHeight:1.6}}>
              Get your first virtual number to start making calls and sending SMS worldwide
            </div>
            <button className="press" onClick={() => navigate("picker")} style={{
              padding:"12px 28px",background:"var(--accent)",border:"none",
              borderRadius:"var(--r-md)",color:"var(--bg-base)",fontSize:14,fontWeight:800,
              boxShadow:"var(--shadow-accent)",cursor:"pointer"}}>
              Get a Number →
            </button>
          </div>
        ) : (
          numbers.map((num, i) => <NumberCard key={num.id} num={num} index={i}/>)
        )}
      </div>

      {/* Feature cards row */}
      <div style={{padding:"4px 16px 28px"}}>
        <h3 style={{fontSize:11,fontWeight:800,color:"var(--text-muted)",letterSpacing:1.6,marginBottom:10}}>QUICK ACCESS</h3>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          {[
            {emoji:"📡",title:"eSIM Data",sub:"Travel ready",screen:"esim",color:"var(--purple)",bg:"var(--purple-dim)"},
            {emoji:"🛡️",title:"Spam Blocker",sub:"Block unwanted",screen:"spamblocker",color:"var(--red)",bg:"var(--red-dim)"},
            {emoji:"💬",title:"Auto-Reply",sub:"Set away messages",screen:"autoreply",color:"var(--green)",bg:"var(--green-dim)"},
            {emoji:"👥",title:"Contacts",sub:"Sync & manage",screen:"contacts",color:"var(--blue)",bg:"var(--blue-dim)"},
          ].map((f,i)=>(
            <div key={i} onClick={() => navigate(f.screen)} className="press row-tap"
              style={{background:"var(--bg-surface)",borderRadius:"var(--r-lg)",
                padding:"14px 14px",cursor:"pointer",border:"1px solid var(--border)",
                boxShadow:"var(--shadow-sm)"}}>
              <div style={{width:38,height:38,borderRadius:11,background:f.bg,
                display:"flex",alignItems:"center",justifyContent:"center",
                fontSize:18,marginBottom:8}}>{f.emoji}</div>
              <div style={{fontSize:13,fontWeight:700,color:"var(--text-primary)"}}>{f.title}</div>
              <div style={{fontSize:11,color:"var(--text-muted)",marginTop:2}}>{f.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
