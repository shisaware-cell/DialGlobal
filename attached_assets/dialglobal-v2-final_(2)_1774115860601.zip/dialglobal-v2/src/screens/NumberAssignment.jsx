// src/screens/NumberAssignment.jsx
// Flow: pick country → pick plan → confirm trial → activating
// The plan selection lives HERE so users consciously choose
// before they see the card charge screen.
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { COUNTRIES, PLANS, TRIAL_LIMITS, genNumber } from "../data/mockData";

const POPULAR = COUNTRIES.filter(c => c.popular);

// ── Reusable small check icon ──────────────────────────────────────────────
function Check({ size = 10, color = "var(--green)" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6L9 17l-5-5"/>
    </svg>
  );
}

// ── Step indicator pill ────────────────────────────────────────────────────
function StepPill({ current, total }) {
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      background: "var(--accent-dim)", borderRadius: 99,
      padding: "4px 12px", marginBottom: 8,
    }}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} style={{
          width: i < current ? 16 : 7, height: 7, borderRadius: 99,
          background: i < current ? "var(--accent)" : "var(--border-strong)",
          transition: "all 0.3s cubic-bezier(0.34,1.56,0.64,1)",
        }}/>
      ))}
      <span style={{ fontSize: 10.5, fontWeight: 700, color: "var(--accent)",
        marginLeft: 4 }}>{current}/{total}</span>
    </div>
  );
}

export default function NumberAssignment() {
  const { navigate, selectPlan, upgradePlan, addNumber, addCredits } = useApp();

  const [step,     setStep]     = useState("country"); // country | plan | confirm | activating
  const [country,  setCountry]  = useState(null);
  const [number,   setNumber]   = useState("");
  const [selPlan,  setSelPlan]  = useState("professional");
  const [billing,  setBilling]  = useState("yearly");
  const [search,   setSearch]   = useState("");
  const [progress, setProgress] = useState(0);

  const plan     = PLANS.find(p => p.id === selPlan);
  const price    = billing === "yearly" ? plan.yearlyPrice : plan.monthlyPrice;
  const trialEnd = new Date(Date.now() + TRIAL_LIMITS.days * 86400000)
    .toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric" });

  const filtered = search
    ? COUNTRIES.filter(c =>
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.code.toLowerCase().includes(search.toLowerCase()))
    : COUNTRIES;

  const pickCountry = (c) => {
    setCountry(c);
    setNumber(genNumber(c.prefix));
  };

  const handleActivate = () => {
    setStep("activating");
    let p = 0;
    const iv = setInterval(() => {
      p += Math.random() * 20;
      if (p >= 100) {
        clearInterval(iv);
        setProgress(100);
        setTimeout(() => {
          addNumber({
            id: Date.now(), number, country: country.name, flag: country.flag,
            type: "trial", calls: 0, sms: 0,
            plan: plan.name, missedCalls: 0, lastActivity: "just now",
          });
          addCredits(TRIAL_LIMITS.freeCredits);
          selectPlan(selPlan);
          upgradePlan(selPlan, billing);
          navigate("home");
        }, 500);
      } else {
        setProgress(p);
      }
    }, 260);
  };

  // ── ACTIVATING ──────────────────────────────────────────────────────────
  if (step === "activating") return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      alignItems:"center", justifyContent:"center",
      background:"var(--bg-base)", padding:"32px 28px" }}>
      <div style={{ width:80, height:80, borderRadius:"50%",
        background:"var(--accent-dim)",
        display:"flex", alignItems:"center", justifyContent:"center",
        marginBottom:28 }}>
        {progress < 100
          ? <Spinner size={36} color="var(--accent)"/>
          : <span style={{ fontSize:40, animation:"pop 0.5s ease" }}>🎉</span>}
      </div>
      {progress < 100 ? (
        <>
          <h3 style={{ fontSize:20, fontWeight:800, color:"var(--text-primary)",
            marginBottom:8, letterSpacing:"-0.4px" }}>Activating your number…</h3>
          <p style={{ fontSize:13, color:"var(--text-secondary)", marginBottom:28,
            textAlign:"center" }}>{country?.flag} {number}</p>
          <div style={{ width:"100%", maxWidth:260, height:5,
            background:"var(--bg-raised)", borderRadius:99, overflow:"hidden" }}>
            <div style={{ width:`${progress}%`, height:"100%",
              background:"linear-gradient(90deg,var(--accent),var(--accent-light))",
              borderRadius:99, transition:"width 0.28s ease" }}/>
          </div>
          <div style={{ marginTop:28, width:"100%", maxWidth:260,
            display:"flex", flexDirection:"column", gap:10 }}>
            {[
              { label:"Creating your account",  done: progress > 20 },
              { label:"Reserving your number",   done: progress > 55 },
              { label:"Starting trial",          done: progress > 85 },
            ].map((s, i) => (
              <div key={i} style={{ display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ width:22, height:22, borderRadius:"50%",
                  background: s.done ? "var(--green)" : "var(--bg-raised)",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  flexShrink:0, transition:"background 0.3s" }}>
                  {s.done
                    ? <Check size={10} color="#fff"/>
                    : <div style={{ width:6, height:6, borderRadius:"50%",
                        background:"var(--border-strong)" }}/>}
                </div>
                <span style={{ fontSize:13, fontWeight: s.done ? 600 : 400,
                  color: s.done ? "var(--text-primary)" : "var(--text-muted)" }}>
                  {s.label}
                </span>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="fade-up" style={{ textAlign:"center" }}>
          <h2 style={{ fontSize:26, fontWeight:800, color:"var(--text-primary)",
            letterSpacing:"-0.6px" }}>You're all set!</h2>
        </div>
      )}
    </div>
  );

  // ── CONFIRM ──────────────────────────────────────────────────────────────
  if (step === "confirm") return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden" }}>
      <div style={{ flex:1, overflowY:"auto", padding:"18px 20px 0" }}>

        <button onClick={() => setStep("plan")} style={{
          background:"none", border:"none", display:"flex", alignItems:"center",
          gap:6, cursor:"pointer", color:"var(--text-muted)", fontSize:13,
          fontWeight:600, marginBottom:20, padding:0, fontFamily:"inherit",
        }}>
          <Ic d="M15 18l-6-6 6-6" size={15} color="var(--text-muted)" sw={2.2}/>
          Back
        </button>

        <StepPill current={3} total={3}/>
        <h2 style={{ fontSize:22, fontWeight:800, color:"var(--text-primary)",
          letterSpacing:"-0.5px", marginBottom:4 }}>Confirm your trial</h2>
        <p style={{ fontSize:13.5, color:"var(--text-secondary)",
          marginBottom:20, lineHeight:1.55 }}>
          Review what's included, then start your free trial.
        </p>

        {/* Number display */}
        <div style={{ textAlign:"center", marginBottom:18 }}>
          <div style={{
            display:"inline-flex", flexDirection:"column", alignItems:"center",
            background:"var(--bg-surface)", borderRadius:"var(--r-xl)",
            padding:"20px 28px", boxShadow:"var(--shadow-md)",
            border:"1.5px solid var(--border)",
          }}>
            <span style={{ fontSize:38, marginBottom:8 }}>{country?.flag}</span>
            <div style={{ fontSize:22, fontWeight:800, fontFamily:"var(--font-mono)",
              color:"var(--text-primary)", letterSpacing:"-0.5px", marginBottom:5 }}>
              {number}
            </div>
            <div style={{ fontSize:12, color:"var(--text-secondary)" }}>
              {country?.name} · {country?.prefix}
            </div>
          </div>
          <button onClick={() => setNumber(genNumber(country.prefix))} style={{
            display:"inline-flex", alignItems:"center", gap:5,
            marginTop:8, background:"none", border:"none",
            fontSize:12, color:"var(--accent)", fontWeight:700,
            cursor:"pointer", fontFamily:"inherit",
          }}>
            <Ic d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"
              size={12} color="var(--accent)" sw={2.5}/>
            Get a different number
          </button>
        </div>

        {/* Trial benefits card */}
        <div style={{ background:"var(--bg-surface)", borderRadius:"var(--r-xl)",
          border:"1px solid var(--border)", overflow:"hidden",
          marginBottom:14, boxShadow:"var(--shadow-sm)" }}>
          <div style={{
            background:"linear-gradient(120deg,var(--accent),var(--accent-dark))",
            padding:"13px 17px",
          }}>
            <div style={{ fontSize:10.5, fontWeight:800,
              color:"rgba(255,255,255,0.7)", letterSpacing:1.6, marginBottom:3 }}>
              YOUR 3-DAY FREE TRIAL
            </div>
            <div style={{ fontSize:15, fontWeight:800, color:"#fff" }}>
              Everything to get you started
            </div>
          </div>
          {[
            { emoji:"📞", label:`${TRIAL_LIMITS.callMinutes} minutes`,
              sub:"Call any number worldwide" },
            { emoji:"💬", label:`${TRIAL_LIMITS.smsLimit} SMS`,
              sub:"Send & receive messages" },
            { emoji:"📱", label:"1 virtual number",
              sub:`${country?.name} · ${number}` },
            { emoji:"💳", label:`$${TRIAL_LIMITS.freeCredits.toFixed(2)} free credits`,
              sub:"Top up when minutes run out" },
          ].map((r, i, arr) => (
            <div key={i} style={{
              display:"flex", alignItems:"center", gap:13, padding:"12px 17px",
              borderBottom: i < arr.length - 1 ? "1px solid var(--border)" : "none",
            }}>
              <div style={{ width:38, height:38, borderRadius:11, flexShrink:0,
                background:"var(--accent-dim)",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:19 }}>{r.emoji}</div>
              <div>
                <div style={{ fontSize:13.5, fontWeight:700,
                  color:"var(--text-primary)" }}>{r.label}</div>
                <div style={{ fontSize:11.5, color:"var(--text-secondary)",
                  marginTop:2 }}>{r.sub}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Plan activates on day 4 */}
        <div style={{ background:"var(--bg-raised)", borderRadius:"var(--r-lg)",
          padding:"13px 15px", marginBottom:14, border:"1px solid var(--border)" }}>
          <div style={{ fontSize:10.5, fontWeight:800, color:"var(--text-muted)",
            letterSpacing:1.5, marginBottom:9 }}>
            {plan.emoji} {plan.name.toUpperCase()} PLAN ACTIVATES {trialEnd.toUpperCase().split(",")[0]}
          </div>
          <div style={{ display:"flex", flexWrap:"wrap", gap:"5px 14px" }}>
            {plan.features.map((f, i) => (
              <div key={i} style={{ display:"flex", alignItems:"center", gap:5 }}>
                <div style={{ width:14, height:14, borderRadius:"50%",
                  background:"var(--green-dim)",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  flexShrink:0 }}>
                  <Check size={8} color="var(--green)"/>
                </div>
                <span style={{ fontSize:12, color:"var(--text-secondary)" }}>{f}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Renews note */}
        <div style={{ display:"flex", alignItems:"flex-start", gap:9,
          background:"var(--accent-soft)", borderRadius:"var(--r-md)",
          padding:"11px 13px", marginBottom:8,
          border:"1px solid rgba(232,160,32,0.12)" }}>
          <span style={{ fontSize:17, flexShrink:0 }}>📅</span>
          <p style={{ fontSize:12.5, color:"var(--text-secondary)",
            lineHeight:1.6, margin:0 }}>
            Your <strong style={{ color:"var(--text-primary)" }}>{plan.name}</strong> plan
            activates on <strong style={{ color:"var(--text-primary)" }}>{trialEnd}</strong>.
            Cancel anytime before then — no charge.
          </p>
        </div>
      </div>

      {/* CTA */}
      <div style={{ background:"var(--bg-surface)", borderTop:"1px solid var(--border)",
        padding:"13px 18px 26px", flexShrink:0 }}>
        <button className="press" onClick={handleActivate} style={{
          width:"100%", height:56, background:"var(--accent)",
          border:"none", borderRadius:"var(--r-xl)",
          color:"var(--bg-base)", fontSize:16, fontWeight:800,
          cursor:"pointer", boxShadow:"var(--shadow-accent)",
          letterSpacing:"-0.2px",
        }}>
          Start My Free Trial →
        </button>
        <p style={{ textAlign:"center", fontSize:11, color:"var(--text-muted)",
          marginTop:8, lineHeight:1.5 }}>
          3 days free · then ${price.toFixed(2)}/{billing==="yearly"?"mo (billed $"+plan.yearlyBilled+"/yr)":"month"} · Cancel anytime
        </p>
        <div style={{ display:"flex", justifyContent:"center", marginTop:10 }}>
          {["Terms","Restore","Privacy"].map((l, i) => (
            <React.Fragment key={l}>
              {i > 0 && <span style={{ color:"var(--border-strong)",
                fontSize:12, padding:"0 10px" }}>|</span>}
              <button style={{ background:"none", border:"none", fontSize:12,
                color:"var(--text-muted)", cursor:"pointer",
                padding:0, fontFamily:"inherit" }}>{l}</button>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );

  // ── PLAN SELECTION ────────────────────────────────────────────────────────
  if (step === "plan") return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden" }}>
      {/* Header */}
      <div style={{ background:"linear-gradient(160deg,#FFF6E0 0%,var(--bg-surface) 60%)",
        padding:"12px 18px 14px", borderBottom:"1px solid var(--border)",
        flexShrink:0 }}>
        <button onClick={() => setStep("country")} style={{
          background:"none", border:"none", display:"flex", alignItems:"center",
          gap:6, cursor:"pointer", color:"var(--text-muted)", fontSize:13,
          fontWeight:600, marginBottom:12, padding:0, fontFamily:"inherit",
        }}>
          <Ic d="M15 18l-6-6 6-6" size={15} color="var(--text-muted)" sw={2.2}/>
          Back
        </button>

        <StepPill current={2} total={3}/>
        <h2 style={{ fontSize:22, fontWeight:800, color:"var(--text-primary)",
          letterSpacing:"-0.5px", marginBottom:4 }}>Choose your plan</h2>
        <p style={{ fontSize:13, color:"var(--text-secondary)",
          marginBottom:14, lineHeight:1.5 }}>
          Your 3-day trial starts now. You'll be charged after the trial ends.
        </p>

        {/* Billing toggle */}
        <div style={{ display:"flex", background:"var(--bg-raised)",
          borderRadius:99, padding:3 }}>
          {[
            { id:"monthly", label:"Monthly" },
            { id:"yearly",  label:"Yearly", badge:"Save 20%" },
          ].map(b => (
            <button key={b.id} onClick={() => setBilling(b.id)} style={{
              flex:1, height:32, borderRadius:99, border:"none",
              background: billing === b.id ? "var(--bg-surface)" : "transparent",
              color: billing === b.id ? "var(--text-primary)" : "var(--text-muted)",
              fontSize:12.5, fontWeight: billing === b.id ? 700 : 400,
              cursor:"pointer", transition:"all 0.2s",
              display:"flex", alignItems:"center", justifyContent:"center", gap:7,
              boxShadow: billing === b.id ? "var(--shadow-sm)" : "none",
              fontFamily:"inherit",
            }}>
              {b.label}
              {b.badge && billing === b.id && (
                <span style={{ fontSize:9, fontWeight:800, background:"var(--green)",
                  color:"#fff", padding:"2px 6px", borderRadius:99 }}>{b.badge}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Plan cards */}
      <div style={{ flex:1, overflowY:"auto", padding:"12px 14px 8px" }}>
        {PLANS.map((p, i) => {
          const isSel = selPlan === p.id;
          const dp    = billing === "yearly" ? p.yearlyPrice : p.monthlyPrice;
          return (
            <div key={p.id} style={{
              animationDelay:`${i*0.07}s`,
              // Extra top margin on Professional to make room for floating badge
              marginTop: p.id === "professional" ? 18 : 0,
              marginBottom: 10,
              position:"relative",
            }} className="fade-up">
              {/* BEST OFFER badge — floats above card, always visible */}
              {p.id === "professional" && (
                <div style={{
                  position:"absolute", top:-13, left:"50%",
                  transform:"translateX(-50%)", zIndex:4,
                  background:"var(--accent)", color:"var(--bg-base)",
                  fontSize:10, fontWeight:800, letterSpacing:1.2,
                  padding:"3px 14px", borderRadius:99, whiteSpace:"nowrap",
                  boxShadow:"0 2px 8px var(--accent-glow)",
                }}>BEST OFFER</div>
              )}
              <div onClick={() => setSelPlan(p.id)} className="press" style={{
                borderRadius:"var(--r-xl)",
                border:`2px solid ${isSel ? "var(--accent)" : "var(--border)"}`,
                background: isSel ? "var(--bg-card)" : "var(--bg-surface)",
                cursor:"pointer", overflow:"hidden",
                boxShadow: isSel
                  ? "var(--shadow-accent), var(--shadow-md)"
                  : "var(--shadow-sm)",
                transition:"all 0.22s cubic-bezier(0.22,1,0.36,1)",
              }}>
              <div style={{ display:"flex", alignItems:"flex-start",
                padding:"14px 16px",
                gap:12 }}>

                {/* Radio */}
                <div style={{
                  width:22, height:22, borderRadius:"50%", flexShrink:0, marginTop:2,
                  border:`2.5px solid ${isSel ? "var(--accent)" : "var(--border-strong)"}`,
                  background: isSel ? "var(--accent)" : "transparent",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  transition:"all 0.18s",
                  boxShadow: isSel ? "0 2px 8px var(--accent-glow)" : "none",
                }}>
                  {isSel && <div style={{ width:7, height:7, borderRadius:"50%",
                    background:"white" }}/>}
                </div>

                <div style={{ flex:1 }}>
                  <div style={{ display:"flex", alignItems:"baseline",
                    justifyContent:"space-between", gap:10, marginBottom:4 }}>
                    <div>
                      <div style={{ fontSize:16, fontWeight:800,
                        color:"var(--text-primary)", letterSpacing:"-0.2px" }}>
                        {p.emoji} {p.name}
                      </div>
                      <div style={{ fontSize:11.5, color:"var(--text-secondary)",
                        marginTop:2 }}>
                        {p.persona}
                      </div>
                    </div>
                    <div style={{ textAlign:"right", flexShrink:0 }}>
                      <div style={{ fontSize:22, fontWeight:800,
                        fontFamily:"var(--font-mono)", letterSpacing:"-0.5px",
                        color: isSel ? "var(--accent)" : "var(--text-primary)" }}>
                        ${dp.toFixed(2)}
                      </div>
                      <div style={{ fontSize:10, color:"var(--text-muted)" }}>
                        /month
                      </div>
                      {billing === "yearly" && (
                        <div style={{ fontSize:9.5, color:"var(--green)",
                          fontWeight:700, marginTop:2 }}>
                          ${p.yearlyBilled}/yr
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Key stats chips */}
                  <div style={{ display:"flex", flexWrap:"wrap", gap:5 }}>
                    {[
                      `${p.numberLimit} number${p.numberLimit>1?"s":""}`,
                      `${p.callMinutes} min`,
                      p.smsLimit===9999 ? "Unlimited SMS" : `${p.smsLimit} SMS`,
                      p.includedCredits > 0 ? `$${p.includedCredits} credits/mo` : null,
                    ].filter(Boolean).map((s, si) => (
                      <span key={si} style={{
                        fontSize:10.5, fontWeight:700, borderRadius:99,
                        padding:"3px 9px",
                        background: isSel ? "var(--accent-dim)" : "var(--bg-raised)",
                        color: isSel ? "var(--accent)" : "var(--text-secondary)",
                      }}>{s}</span>
                    ))}
                  </div>

                  {/* Expanded features — shown for ANY selected plan */}
                  {isSel && (
                    <div className="fade-up" style={{ marginTop:10, paddingTop:10,
                      borderTop:"1px solid var(--border)" }}>
                      {p.features.map((f, fi) => (
                        <div key={fi} style={{ display:"flex", alignItems:"center",
                          gap:7, marginBottom: fi < p.features.length-1 ? 6 : 0 }}>
                          <div style={{ width:15, height:15, borderRadius:"50%",
                            background:"var(--green-dim)", flexShrink:0,
                            display:"flex", alignItems:"center",
                            justifyContent:"center" }}>
                            <Check size={8} color="var(--green)"/>
                          </div>
                          <span style={{ fontSize:12, color:"var(--text-secondary)" }}>
                            {f}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
            </div>
          );
        })}

        {/* Trial reminder */}
        <div style={{ display:"flex", alignItems:"center", gap:10,
          background:"var(--accent-dim)", borderRadius:"var(--r-md)",
          padding:"11px 14px", marginBottom:8 }}>
          <span style={{ fontSize:18, flexShrink:0 }}>🎁</span>
          <div>
            <div style={{ fontSize:12.5, fontWeight:700, color:"var(--accent-dark)" }}>
              3-day free trial on all plans
            </div>
            <div style={{ fontSize:11.5, color:"var(--text-secondary)", marginTop:1 }}>
              Plus $2.00 in free credits to test calls & SMS
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div style={{ background:"var(--bg-surface)", borderTop:"1px solid var(--border)",
        padding:"12px 16px 24px", flexShrink:0 }}>
        <button className="press" onClick={() => setStep("confirm")} style={{
          width:"100%", height:54, background:"var(--accent)",
          border:"none", borderRadius:"var(--r-xl)",
          color:"var(--bg-base)", fontSize:16, fontWeight:800,
          cursor:"pointer", boxShadow:"var(--shadow-accent)",
          letterSpacing:"-0.2px",
        }}>
          Continue with {plan.name} →
        </button>
        <p style={{ textAlign:"center", fontSize:11, color:"var(--text-muted)",
          marginTop:8 }}>
          Free for 3 days · ${price.toFixed(2)}/mo after trial
        </p>
      </div>
    </div>
  );

  // ── PICK COUNTRY ──────────────────────────────────────────────────────────
  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden" }}>
      <div style={{ background:"var(--bg-surface)", padding:"14px 18px 14px",
        borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <StepPill current={1} total={3}/>
        <h2 style={{ fontSize:22, fontWeight:800, color:"var(--text-primary)",
          letterSpacing:"-0.5px", marginBottom:4 }}>Choose your country</h2>
        <p style={{ fontSize:13, color:"var(--text-secondary)",
          marginBottom:13, lineHeight:1.5 }}>
          Pick where you want your trial number. Add more countries after your trial.
        </p>

        {/* Search */}
        <div style={{ position:"relative" }}>
          <div style={{ position:"absolute", left:13, top:"50%",
            transform:"translateY(-50%)", pointerEvents:"none" }}>
            <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z"
              size={15} color="var(--text-muted)" sw={2}/>
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search country or dial code…"
            style={{ width:"100%", height:42, borderRadius:99,
              border:"1.5px solid var(--border)",
              background:"var(--bg-raised)", padding:"0 14px 0 38px",
              fontSize:13, color:"var(--text-primary)", outline:"none",
              fontFamily:"inherit" }}/>
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"12px 15px 100px" }}>
        {!search && (
          <>
            <div style={{ fontSize:10.5, fontWeight:800, color:"var(--text-muted)",
              letterSpacing:1.6, marginBottom:9 }}>POPULAR</div>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:18 }}>
              {POPULAR.map(c => (
                <button key={c.code} onClick={() => pickCountry(c)} className="press"
                  style={{
                    display:"flex", flexDirection:"column", alignItems:"center", gap:5,
                    padding:"12px 10px", minWidth:70,
                    background: country?.code===c.code ? "var(--accent-dim)" : "var(--bg-surface)",
                    border:`1.5px solid ${country?.code===c.code ? "var(--accent)" : "var(--border)"}`,
                    borderRadius:"var(--r-lg)", cursor:"pointer",
                    boxShadow: country?.code===c.code ? "var(--shadow-accent)" : "var(--shadow-sm)",
                    transition:"all 0.18s cubic-bezier(0.34,1.56,0.64,1)",
                  }}>
                  <span style={{ fontSize:26 }}>{c.flag}</span>
                  <span style={{ fontSize:10.5, fontWeight:700,
                    color: country?.code===c.code ? "var(--accent)" : "var(--text-secondary)" }}>
                    {c.code}
                  </span>
                </button>
              ))}
            </div>
            <div style={{ fontSize:10.5, fontWeight:800, color:"var(--text-muted)",
              letterSpacing:1.6, marginBottom:9 }}>ALL COUNTRIES</div>
          </>
        )}

        {filtered.map((c, i) => {
          const isSel = country?.code === c.code;
          return (
            <div key={c.code} onClick={() => pickCountry(c)}
              className="row-tap fade-up"
              style={{
                display:"flex", alignItems:"center", gap:13,
                padding:"12px 14px", marginBottom:8,
                background: isSel ? "var(--accent-dim)" : "var(--bg-surface)",
                borderRadius:"var(--r-lg)",
                border:`1.5px solid ${isSel ? "var(--accent)" : "var(--border)"}`,
                cursor:"pointer",
                boxShadow: isSel ? "var(--shadow-accent)" : "var(--shadow-sm)",
                transition:"all 0.18s",
                animationDelay:`${i * 0.025}s`,
              }}>
              <div style={{ width:46, height:46, borderRadius:13,
                background: isSel ? "rgba(232,160,32,0.15)" : "var(--bg-raised)",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:24, flexShrink:0 }}>{c.flag}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14.5, fontWeight:700,
                  color: isSel ? "var(--accent)" : "var(--text-primary)" }}>
                  {c.name}
                </div>
                <div style={{ display:"flex", gap:8, marginTop:3 }}>
                  <span style={{ fontSize:12, color:"var(--text-muted)",
                    fontFamily:"var(--font-mono)" }}>{c.prefix}</span>
                  {c.instant && (
                    <span style={{ fontSize:9.5, fontWeight:700, color:"var(--green)",
                      background:"var(--green-dim)", padding:"1px 7px", borderRadius:99 }}>
                      ⚡ Instant
                    </span>
                  )}
                </div>
              </div>
              {isSel
                ? <div style={{ width:24, height:24, borderRadius:"50%",
                    background:"var(--accent)", display:"flex",
                    alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <Check size={11} color="white"/>
                  </div>
                : <Ic d="M9 18l6-6-6-6" size={14} color="var(--text-muted)" sw={2}/>}
            </div>
          );
        })}
      </div>

      {/* Sticky bottom CTA */}
      {country && (
        <div className="slide-up" style={{ background:"var(--bg-surface)",
          borderTop:"1px solid var(--border)", padding:"11px 16px 24px",
          flexShrink:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:12,
            background:"var(--bg-raised)", borderRadius:"var(--r-md)",
            padding:"10px 14px", marginBottom:11 }}>
            <span style={{ fontSize:24 }}>{country.flag}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:14, fontWeight:700,
                color:"var(--text-primary)" }}>{country.name}</div>
              <div style={{ fontSize:12, color:"var(--text-muted)",
                fontFamily:"var(--font-mono)" }}>{number}</div>
            </div>
            <button onClick={() => setNumber(genNumber(country.prefix))} style={{
              background:"none", border:"none", fontSize:12,
              color:"var(--accent)", fontWeight:700,
              cursor:"pointer", fontFamily:"inherit",
            }}>Refresh</button>
          </div>
          <button className="press" onClick={() => setStep("plan")} style={{
            width:"100%", height:54, background:"var(--accent)",
            border:"none", borderRadius:"var(--r-xl)",
            color:"var(--bg-base)", fontSize:16, fontWeight:800,
            cursor:"pointer", boxShadow:"var(--shadow-accent)",
            letterSpacing:"-0.2px",
          }}>
            Use this number →
          </button>
        </div>
      )}
    </div>
  );
}
