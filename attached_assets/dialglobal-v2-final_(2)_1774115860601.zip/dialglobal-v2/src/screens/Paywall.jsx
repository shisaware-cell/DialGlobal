// src/screens/Paywall.jsx — Clean paywall inspired by 2nd Line reference design
// Structure: Hero benefits → Plan selection → Trial CTA → Legal footer
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { PLANS, TRIAL_LIMITS } from "../data/mockData";

// Floating icon — decorative, like the reference image flags/icons
function FloatIcon({ emoji, style }) {
  return (
    <div style={{
      position:"absolute",
      width:52, height:52, borderRadius:16,
      background:"var(--bg-surface)",
      display:"flex", alignItems:"center", justifyContent:"center",
      fontSize:26,
      boxShadow:"0 4px 16px rgba(0,0,0,0.10)",
      transform:"rotate(-8deg)",
      animation:"float 3s ease-in-out infinite",
      ...style,
    }}>{emoji}</div>
  );
}

export default function Paywall() {
  const { goBack, navigate, upgradePlan, currentPlan } = useApp();
  const [selected,  setSelected]  = useState(pendingPlan || "professional");
  const [billing,   setBilling]   = useState("yearly");
  const [loading,   setLoading]   = useState(false);
  const [step,      setStep]      = useState("plans"); // plans | trial_info | success

  const plan    = PLANS.find(p => p.id === selected);
  const price   = billing === "yearly" ? plan.yearlyPrice : plan.monthlyPrice;
  const billed  = billing === "yearly" ? plan.yearlyBilled : null;
  const saving  = billing === "yearly"
    ? ((plan.monthlyPrice - plan.yearlyPrice) * 12).toFixed(2)
    : null;

  const handleContinue = () => {
    // Save plan selection to context, then go to account creation
    selectPlan(selected);
    navigate("auth");
  };

  // ── SUCCESS SCREEN ────────────────────────────────────────────────────────
  if (step === "REMOVED_SUCCESS") return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"linear-gradient(160deg,#FFF6E0 0%,var(--bg-base) 50%)",
      overflow:"hidden" }}>
      <div style={{ flex:1, display:"flex", flexDirection:"column",
        alignItems:"center", justifyContent:"center", padding:"32px 28px" }}>

        <div style={{ fontSize:72, marginBottom:20, animation:"pop 0.5s ease" }}>🎉</div>

        <h2 style={{ fontSize:26, fontWeight:800, color:"var(--text-primary)",
          textAlign:"center", letterSpacing:"-0.6px", marginBottom:8 }}>
          Trial started!
        </h2>
        <p style={{ fontSize:14, color:"var(--text-secondary)", textAlign:"center",
          lineHeight:1.7, marginBottom:24 }}>
          Your 3-day free trial is active. You won't be charged until{" "}
          <strong style={{ color:"var(--text-primary)" }}>
            {new Date(Date.now()+3*864e5).toLocaleDateString("en-US",
              { weekday:"long", month:"long", day:"numeric" })}
          </strong>.
        </p>

        {/* Trial limits card */}
        <div style={{ width:"100%", background:"var(--bg-surface)",
          borderRadius:"var(--r-xl)", padding:"18px 20px", marginBottom:16,
          border:"1px solid var(--border)", boxShadow:"var(--shadow-sm)" }}>
          <div style={{ fontSize:11, fontWeight:800, color:"var(--text-muted)",
            letterSpacing:1.6, marginBottom:12 }}>DURING YOUR 3-DAY TRIAL</div>
          {[
            { emoji:"📞", label:"15 min calls",     sub:"To any number worldwide" },
            { emoji:"💬", label:"10 SMS",           sub:"Send & receive" },
            { emoji:"🌍", label:"1 virtual number", sub:"Any country you choose" },
            { emoji:"💳", label:"$2.00 free credits",sub:"For extra calls & SMS" },
          ].map((r, i) => (
            <div key={i} style={{ display:"flex", alignItems:"center", gap:12,
              padding:"9px 0",
              borderBottom:i < 3 ? "1px solid var(--border)" : "none" }}>
              <div style={{ width:38, height:38, borderRadius:11,
                background:"var(--accent-dim)", display:"flex",
                alignItems:"center", justifyContent:"center",
                fontSize:18, flexShrink:0 }}>{r.emoji}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:13.5, fontWeight:700,
                  color:"var(--text-primary)" }}>{r.label}</div>
                <div style={{ fontSize:11.5, color:"var(--text-muted)",
                  marginTop:1 }}>{r.sub}</div>
              </div>
            </div>
          ))}
        </div>

        {/* What unlocks on day 4 */}
        <div style={{ width:"100%", background:"linear-gradient(120deg,var(--accent),var(--accent-dark))",
          borderRadius:"var(--r-xl)", padding:"16px 20px", marginBottom:28,
          boxShadow:"var(--shadow-accent)", position:"relative", overflow:"hidden" }}>
          <div style={{ position:"absolute", top:-16, right:-16, width:64, height:64,
            borderRadius:"50%", background:"rgba(255,255,255,0.12)" }}/>
          <div style={{ fontSize:11, fontWeight:800, color:"rgba(255,255,255,0.7)",
            letterSpacing:1.6, marginBottom:8 }}>
            UNLOCKS ON DAY 4 — {plan.name.toUpperCase()} PLAN
          </div>
          <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
            {[
              `${plan.callMinutes} min/mo`,
              plan.smsLimit === 9999 ? "Unlimited SMS" : `${plan.smsLimit} SMS`,
              `${plan.numberLimit} number${plan.numberLimit>1?"s":""}`,
              plan.hasRecording ? "Call recording" : null,
              plan.hasAutoReply ? "Auto-reply" : null,
              plan.includedCredits > 0 ? `$${plan.includedCredits} credits/mo` : null,
            ].filter(Boolean).map((f, i) => (
              <div key={i} style={{ display:"flex", alignItems:"center", gap:5 }}>
                <Ic d="M20 6L9 17l-5-5" size={11} color="rgba(255,255,255,0.9)" sw={3}/>
                <span style={{ fontSize:12, color:"rgba(255,255,255,0.9)",
                  fontWeight:600 }}>{f}</span>
              </div>
            ))}
          </div>
        </div>

        <button className="press" onClick={goBack} style={{ width:"100%", height:52,
          background:"var(--accent)", border:"none", borderRadius:"var(--r-md)",
          color:"var(--bg-base)", fontSize:15, fontWeight:800,
          cursor:"pointer", boxShadow:"var(--shadow-accent)" }}>
          Set up my number →
        </button>
      </div>
    </div>
  );

  // ── MAIN PAYWALL ──────────────────────────────────────────────────────────
  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"linear-gradient(180deg,#EBE9FF 0%,#F4F1EC 45%)",
      overflow:"hidden" }}>

      {/* Close / back */}
      <button onClick={goBack} style={{ position:"absolute", top:56, right:18,
        zIndex:10, width:32, height:32, borderRadius:"50%",
        background:"rgba(0,0,0,0.12)", border:"none",
        display:"flex", alignItems:"center", justifyContent:"center",
        cursor:"pointer" }}>
        <Ic d="M18 6L6 18M6 6l12 12" size={14} color="var(--text-primary)" sw={2.5}/>
      </button>

      <div style={{ flex:1, overflowY:"auto" }}>

        {/* ── HERO SECTION ── */}
        <div style={{ position:"relative", height:280, overflow:"hidden",
          display:"flex", alignItems:"center", justifyContent:"center",
          flexDirection:"column", paddingTop:40 }}>

          {/* Floating decorative icons — like the reference */}
          <FloatIcon emoji="🌍" style={{ top:30,  left:22,  animationDelay:"0s",   transform:"rotate(-12deg)" }}/>
          <FloatIcon emoji="📞" style={{ top:20,  right:28, animationDelay:"0.4s", transform:"rotate(8deg)"  }}/>
          <FloatIcon emoji="💬" style={{ top:110, left:14,  animationDelay:"0.8s", transform:"rotate(6deg)"  }}/>
          <FloatIcon emoji="🎙️" style={{ top:100, right:16, animationDelay:"1.2s", transform:"rotate(-6deg)" }}/>
          <FloatIcon emoji="🇺🇸" style={{ top:170, left:30,  animationDelay:"0.3s", transform:"rotate(-8deg)" }}/>
          <FloatIcon emoji="🇬🇧" style={{ top:168, right:24, animationDelay:"0.9s", transform:"rotate(10deg)" }}/>

          {/* App logo */}
          <div style={{ width:80, height:80, borderRadius:22,
            background:"linear-gradient(135deg,var(--accent),var(--accent-dark))",
            display:"flex", alignItems:"center", justifyContent:"center",
            boxShadow:"0 8px 32px rgba(232,160,32,0.4)",
            marginBottom:16, position:"relative", zIndex:2 }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none"
              stroke="white" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/>
              <line x1="2" y1="12" x2="22" y2="12"/>
              <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
            </svg>
          </div>

          <h1 style={{ fontSize:28, fontWeight:800, color:"var(--text-primary)",
            textAlign:"center", letterSpacing:"-0.7px", lineHeight:1.2,
            position:"relative", zIndex:2, padding:"0 60px" }}>
            Get Your Global Number Today
          </h1>
        </div>

        {/* ── BENEFITS LIST ── */}
        <div style={{ background:"var(--bg-base)", padding:"0 24px 20px" }}>
          {[
            { icon:"M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z",
              text:"Calls & texts to any number worldwide" },
            { icon:"M9 12h6M9 16h4M13 4H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V9zM13 4v5h5",
              text:"Real virtual number in 100+ countries" },
            { icon:"M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0",
              text:"Incoming calls & push notifications" },
            { icon:"M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4M12 11V3",
              text:"Voicemail, recording & auto-reply" },
          ].map((b, i) => (
            <div key={i} className="fade-up"
              style={{ display:"flex", alignItems:"center", gap:14,
                marginBottom:i < 3 ? 16 : 0,
                animationDelay:`${i*0.08}s` }}>
              <div style={{ width:42, height:42, borderRadius:13, flexShrink:0,
                background:"var(--accent)", display:"flex", alignItems:"center",
                justifyContent:"center", boxShadow:"0 4px 12px var(--acc-glow)" }}>
                <Ic d={b.icon} size={18} color="white" sw={2}/>
              </div>
              <span style={{ fontSize:15.5, fontWeight:600,
                color:"var(--text-primary)" }}>{b.text}</span>
            </div>
          ))}
        </div>

        {/* ── PLAN SELECTOR ── */}
        <div style={{ background:"var(--bg-base)", padding:"4px 18px 16px" }}>

          {/* Billing toggle pill */}
          <div style={{ display:"flex", background:"var(--bg-raised)",
            borderRadius:99, padding:3, marginBottom:14 }}>
            {[
              { id:"monthly", label:"Monthly" },
              { id:"yearly",  label:"Yearly",  badge:"Save 20%" },
            ].map(b => (
              <button key={b.id} onClick={() => setBilling(b.id)} style={{
                flex:1, height:32, borderRadius:99, border:"none",
                background:billing===b.id ? "var(--bg-surface)" : "transparent",
                color:billing===b.id ? "var(--text-primary)" : "var(--text-muted)",
                fontSize:12.5, fontWeight:billing===b.id ? 700 : 400,
                cursor:"pointer", transition:"all 0.2s",
                display:"flex", alignItems:"center", justifyContent:"center", gap:7,
                boxShadow:billing===b.id ? "var(--shadow-sm)" : "none",
              }}>
                {b.label}
                {b.badge && billing===b.id && (
                  <span style={{ fontSize:9, fontWeight:800, background:"var(--green)",
                    color:"#fff", padding:"2px 6px", borderRadius:99 }}>{b.badge}</span>
                )}
              </button>
            ))}
          </div>

          {/* Plan cards — one row per plan, clean like reference */}
          {PLANS.map((p, i) => {
            const isSel = selected === p.id;
            const dp    = billing === "yearly" ? p.yearlyPrice : p.monthlyPrice;
            const isRec = p.id === "professional";
            return (
              <div key={p.id} onClick={() => setSelected(p.id)}
                className="press"
                style={{
                  marginBottom:10,
                  borderRadius:"var(--r-xl)",
                  border:`2px solid ${isSel ? "var(--accent)" : "var(--border-strong)"}`,
                  background:isSel ? "var(--bg-surface)" : "var(--bg-surface)",
                  cursor:"pointer", position:"relative", overflow:"visible",
                  boxShadow:isSel ? "var(--shadow-accent)" : "var(--shadow-sm)",
                  transition:"all 0.2s cubic-bezier(0.22,1,0.36,1)",
                }}>

                {/* Best offer badge — floats above card like reference image */}
                {isRec && (
                  <div style={{
                    position:"absolute", top:-11, left:"50%",
                    transform:"translateX(-50%)",
                    background:"var(--accent)", color:"var(--bg-base)",
                    fontSize:10, fontWeight:800, letterSpacing:1.2,
                    padding:"3px 14px", borderRadius:99,
                    whiteSpace:"nowrap", zIndex:3,
                    boxShadow:"0 2px 8px var(--accent-glow)",
                  }}>BEST OFFER</div>
                )}

                <div style={{ display:"flex", alignItems:"center",
                  padding:"15px 18px", gap:14 }}>

                  {/* Radio circle */}
                  <div style={{
                    width:22, height:22, borderRadius:"50%", flexShrink:0,
                    border:`2.5px solid ${isSel ? "var(--accent)" : "var(--border-strong)"}`,
                    background:isSel ? "var(--accent)" : "transparent",
                    display:"flex", alignItems:"center", justifyContent:"center",
                    transition:"all 0.18s",
                    boxShadow:isSel ? "0 2px 8px var(--accent-glow)" : "none",
                  }}>
                    {isSel && (
                      <div style={{ width:8, height:8, borderRadius:"50%",
                        background:"white" }}/>
                    )}
                  </div>

                  {/* Plan info */}
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:15, fontWeight:800,
                      color:"var(--text-primary)", letterSpacing:"-0.2px" }}>
                      {p.name}
                    </div>
                    <div style={{ fontSize:11.5, color:"var(--text-secondary)",
                      marginTop:2 }}>
                      {p.numberLimit} number{p.numberLimit>1?"s":""} · {p.callMinutes} min · {p.smsLimit===9999?"Unlimited SMS":`${p.smsLimit} SMS`}
                    </div>
                    {billing === "yearly" && (
                      <div style={{ fontSize:10.5, color:"var(--green)",
                        fontWeight:700, marginTop:2 }}>
                        Billed ${p.yearlyBilled}/yr · save ${saving}/yr
                      </div>
                    )}
                  </div>

                  {/* Price */}
                  <div style={{ textAlign:"right", flexShrink:0 }}>
                    <div style={{ fontSize:22, fontWeight:800,
                      fontFamily:"var(--font-mono)", letterSpacing:"-0.5px",
                      color:isSel ? "var(--accent)" : "var(--text-primary)" }}>
                      ${dp.toFixed(2)}
                    </div>
                    <div style={{ fontSize:10, color:"var(--text-muted)" }}>
                      per month
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── STICKY BOTTOM CTA ── */}
      <div style={{ background:"var(--bg-base)", padding:"10px 18px 20px",
        borderTop:"1px solid var(--border)", flexShrink:0 }}>

        {/* Sub note */}
        <p style={{ textAlign:"center", fontSize:11.5, color:"var(--text-muted)",
          marginBottom:10, lineHeight:1.5 }}>
          Cancel anytime ·{" "}
          {billing === "yearly"
            ? `$${plan.yearlyBilled} billed yearly`
            : `$${plan.monthlyPrice.toFixed(2)} billed monthly`}{" "}
          · auto-renews after trial
        </p>

        {/* Main CTA — "Continue" like the reference */}
        <button className="press" onClick={handleContinue} disabled={loading}
          style={{ width:"100%", height:56, borderRadius:"var(--r-xl)",
            background:"var(--accent)", border:"none",
            color:"var(--bg-base)", fontSize:17, fontWeight:800,
            cursor:"pointer", boxShadow:"var(--shadow-accent)",
            display:"flex", alignItems:"center", justifyContent:"center",
            gap:10, letterSpacing:"-0.2px" }}>
          {loading
            ? <><Spinner color="var(--bg-base)"/>Processing…</>
            : `Continue with ${activePlan.name} →`}
        </button>

        {/* Legal footer — exactly like the reference */}
        <div style={{ display:"flex", justifyContent:"center",
          gap:0, marginTop:14 }}>
          {["Terms", "Restore", "Privacy"].map((label, i) => (
            <React.Fragment key={label}>
              {i > 0 && (
                <span style={{ color:"var(--border-strong)",
                  fontSize:12, padding:"0 10px" }}>|</span>
              )}
              <button style={{ background:"none", border:"none",
                fontSize:12, color:"var(--text-muted)",
                cursor:"pointer", padding:0 }}>{label}</button>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
