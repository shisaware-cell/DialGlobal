// src/App.jsx
import React from "react";
import "./styles/globals.css";
import { AppProvider, useApp } from "./context/AppContext";
import { StatusBar, DynamicIsland, IncomingCallOverlay, Toast } from "./components/UI";
import TabBar from "./components/TabBar";

import Onboarding        from "./screens/Onboarding";
import Auth              from "./screens/Auth";
import NumberAssignment  from "./screens/NumberAssignment";
import Dashboard         from "./screens/Dashboard";
import Picker            from "./screens/Picker";
import Inbox             from "./screens/Inbox";
import Calls             from "./screens/Calls";
import Settings          from "./screens/Settings";
import Profile           from "./screens/Profile";
import Paywall           from "./screens/Paywall";
import ExpiredPaywall    from "./screens/ExpiredPaywall";
import NumberDetail      from "./screens/NumberDetail";
import ESim              from "./screens/ESim";
import Contacts          from "./screens/Contacts";
import AutoReply         from "./screens/AutoReply";
import SpamBlocker       from "./screens/SpamBlocker";
import Credits           from "./screens/Credits";

const NO_STATUSBAR = ["onboarding", "auth", "numassign", "paywall", "expired"];
const NO_TABBAR    = [
  "onboarding", "auth", "numassign", "paywall", "expired",
  "profile", "numdetail", "esim", "contacts",
  "autoreply", "spamblocker", "credits", "picker",
];

function Router() {
  const { screen, incomingCall, dismissIncomingCall, toast, showToast } = useApp();

  const renderScreen = () => {
    switch (screen) {
      case "onboarding":  return <Onboarding/>;
      case "auth":        return <Auth/>;
      case "numassign":   return <NumberAssignment/>;
      case "paywall":     return <Paywall/>;
      case "expired":     return <ExpiredPaywall/>;
      case "home":        return <Dashboard/>;
      case "picker":      return <Picker/>;
      case "inbox":       return <Inbox defaultTab="messages"/>;
      case "calls":       return <Calls/>;
      case "settings":    return <Settings/>;
      case "profile":     return <Profile/>;
      case "numdetail":   return <NumberDetail/>;
      case "esim":        return <ESim/>;
      case "contacts":    return <Contacts/>;
      case "autoreply":   return <AutoReply/>;
      case "spamblocker": return <SpamBlocker/>;
      case "credits":     return <Credits/>;
      default:            return <Dashboard/>;
    }
  };

  const showSB  = !NO_STATUSBAR.includes(screen);
  const showTab = !NO_TABBAR.includes(screen);

  return (
    <div style={{
      width: 390, height: 844,
      background: "var(--bg-base)",
      borderRadius: 52,
      boxShadow: "0 40px 80px rgba(0,0,0,0.15), 0 0 0 10px #D4CFC6, 0 0 0 12px #C6C1B8, inset 0 0 0 1px rgba(0,0,0,0.06)",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      position: "relative",
    }}>
      <DynamicIsland/>
      {showSB && <StatusBar/>}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", position: "relative" }}>
        {renderScreen()}
        {incomingCall && (
          <IncomingCallOverlay
            caller={incomingCall.caller}
            number={incomingCall.number}
            onAccept={() => { dismissIncomingCall(); showToast("Call connected! 📞", "success"); }}
            onDecline={() => { dismissIncomingCall(); showToast("Call declined", "info"); }}
          />
        )}
        {toast && <Toast message={toast.message} type={toast.type} onDismiss={() => {}}/>}
      </div>
      {showTab && <TabBar/>}
    </div>
  );
}

function DevShell() {
  const { screen, navigate } = useApp();

  const screens = [
    { id:"onboarding", l:"Onboard"  },
    { id:"paywall",    l:"Paywall"  },
    { id:"auth",       l:"Auth"     },
    { id:"numassign",  l:"Get #"    },
    { id:"home",       l:"Home"     },
    { id:"expired",    l:"Expired"  },
    { id:"inbox",      l:"Inbox"    },
    { id:"calls",      l:"Calls"    },
    { id:"settings",   l:"Settings" },
    { id:"profile",    l:"Profile"  },
    { id:"numdetail",  l:"# Detail" },
    { id:"esim",       l:"eSIM"     },
    { id:"credits",    l:"Credits"  },
    { id:"autoreply",  l:"AutoReply"},
    { id:"spamblocker",l:"Spam"     },
  ];

  return (
    <div style={{
      minHeight: "100vh", background: "#E0DBD1",
      display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      padding: "24px 16px",
      fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif",
    }}>
      {/* Wordmark */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <div style={{
          width: 30, height: 30, borderRadius: 9, background: "var(--accent)",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 4px 12px rgba(232,160,32,0.35)",
        }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
            stroke="var(--bg-base)" strokeWidth="2.2" strokeLinecap="round">
            <circle cx="12" cy="12" r="10"/>
            <line x1="2" y1="12" x2="22" y2="12"/>
            <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
          </svg>
        </div>
        <span style={{ color: "#1A1714", fontSize: 17, fontWeight: 800, letterSpacing: "-0.4px" }}>
          DialGlobal
        </span>
        <span style={{
          fontSize: 11, background: "var(--accent-dim)", color: "var(--accent)",
          padding: "2px 8px", borderRadius: 99, fontWeight: 700,
        }}>v2.2</span>
      </div>

      {/* Screen nav */}
      <div style={{
        display: "flex", gap: 5, marginBottom: 14,
        flexWrap: "wrap", justifyContent: "center", maxWidth: 480,
      }}>
        {screens.map(p => (
          <button key={p.id} onClick={() => navigate(p.id)} style={{
            padding: "4px 11px", borderRadius: 99,
            border: `1px solid ${screen === p.id ? "var(--accent)" : "rgba(0,0,0,0.13)"}`,
            background: screen === p.id ? "var(--accent)" : "rgba(255,255,255,0.5)",
            color: screen === p.id ? "var(--bg-base)" : "#6B6560",
            fontSize: 10.5, fontWeight: screen === p.id ? 700 : 400,
            cursor: "pointer", transition: "all 0.15s", whiteSpace: "nowrap",
          }}>{p.l}</button>
        ))}
      </div>

      <Router/>

      <p style={{ color: "rgba(0,0,0,0.25)", fontSize: 10.5, marginTop: 14, textAlign: "center" }}>
        DialGlobal v2.2 · Powered by Telnyx
      </p>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <DevShell/>
    </AppProvider>
  );
}
