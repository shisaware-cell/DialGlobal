// src/screens/Picker.jsx — Add number for existing logged-in users
// Matches the onboarding NumberAssignment country picker design exactly
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";
import { COUNTRIES, PLANS, genNumber } from "../data/mockData";

const POPULAR = COUNTRIES.filter(c => c.popular);

function Check({ size = 11, color = "#fff" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6L9 17l-5-5"/>
    </svg>
  );
}

export default function Picker() {
  const { goBack, navigate, addNumber, currentPlan } = useApp();
  const [search,   setSearch]   = useState("");
  const [selected, setSelected] = useState(null);
  const [number,   setNumber]   = useState("");
  const [loading,  setLoading]  = useState(false);
  const [focused,  setFocused]  = useState(false);

  const plan    = PLANS.find(p => p.id === currentPlan);
  const filtered = search
    ? COUNTRIES.filter(c =>
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.code.toLowerCase().includes(search.toLowerCase()) ||
        c.prefix.includes(search))
    : COUNTRIES;

  const pickCountry = (c) => {
    setSelected(c);
    setNumber(genNumber(c.prefix));
  };

  const confirm = () => {
    setLoading(true);
    // TODO: POST /v2/available_phone_numbers?country_code={selected.code} to Telnyx
    // then POST /v2/phone_numbers to purchase
    setTimeout(() => {
      addNumber({
        id:           Date.now(),
        number,
        country:      selected.name,
        flag:         selected.flag,
        type:         "permanent",
        calls:        0,
        sms:          0,
        plan:         plan?.name,
        missedCalls:  0,
        lastActivity: "just now",

      });
      setLoading(false);
      navigate("home");
    }, 1800);
  };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column",
      background:"var(--bg-base)", overflow:"hidden" }}>

      {/* Header */}
      <div style={{ background:"var(--bg-surface)", padding:"10px 18px 14px",
        borderBottom:"1px solid var(--border)", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
          <button onClick={goBack} style={{ background:"none", border:"none",
            display:"flex", padding:4, cursor:"pointer" }}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{ fontSize:21, fontWeight:800, color:"var(--text-primary)",
              letterSpacing:"-0.5px" }}>Add a number</h2>
            <p style={{ fontSize:12, color:"var(--text-muted)", marginTop:2 }}>
              {plan
                ? `${plan.numberLimit} number${plan.numberLimit > 1 ? "s" : ""} on your ${plan.name} plan`
                : "Choose your country"}
            </p>
          </div>
        </div>

        {/* Search */}
        <div style={{ position:"relative" }}>
          <div style={{ position:"absolute", left:13, top:"50%",
            transform:"translateY(-50%)", pointerEvents:"none", zIndex:1 }}>
            <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z"
              size={15} color={focused ? "var(--accent)" : "var(--text-muted)"} sw={2}/>
          </div>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            placeholder="Search country or dial code…"
            style={{
              width:"100%", height:44, borderRadius:99,
              border:`1.5px solid ${focused ? "var(--accent)" : "var(--border)"}`,
              background: focused ? "var(--bg-surface)" : "var(--bg-raised)",
              padding:"0 14px 0 38px",
              fontSize:13.5, color:"var(--text-primary)", outline:"none",
              transition:"all 0.2s",
              boxShadow: focused ? "0 0 0 3px var(--accent-dim)" : "none",
              fontFamily:"inherit",
            }}
          />
          {search && (
            <button onClick={() => setSearch("")} style={{
              position:"absolute", right:12, top:"50%",
              transform:"translateY(-50%)",
              background:"var(--bg-raised)", border:"none",
              width:22, height:22, borderRadius:"50%",
              display:"flex", alignItems:"center", justifyContent:"center",
              cursor:"pointer",
            }}>
              <Ic d="M18 6L6 18M6 6l12 12" size={11}
                color="var(--text-muted)" sw={2.5}/>
            </button>
          )}
        </div>
      </div>

      {/* Country list */}
      <div style={{ flex:1, overflowY:"auto", padding:"12px 15px 120px" }}>

        {/* Popular chips — only when not searching */}
        {!search && (
          <>
            <div style={{ fontSize:10.5, fontWeight:800, color:"var(--text-muted)",
              letterSpacing:1.6, marginBottom:9 }}>POPULAR</div>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:18 }}>
              {POPULAR.map(c => (
                <button key={c.code} onClick={() => pickCountry(c)} className="press"
                  style={{
                    display:"flex", flexDirection:"column",
                    alignItems:"center", gap:5,
                    padding:"12px 10px", minWidth:70,
                    background: selected?.code === c.code
                      ? "var(--accent-dim)" : "var(--bg-surface)",
                    border:`1.5px solid ${selected?.code === c.code
                      ? "var(--accent)" : "var(--border)"}`,
                    borderRadius:"var(--r-lg)", cursor:"pointer",
                    boxShadow: selected?.code === c.code
                      ? "var(--shadow-accent)" : "var(--shadow-sm)",
                    transition:"all 0.18s cubic-bezier(0.34,1.56,0.64,1)",
                  }}>
                  <span style={{ fontSize:26 }}>{c.flag}</span>
                  <span style={{ fontSize:10.5, fontWeight:700,
                    color: selected?.code === c.code
                      ? "var(--accent)" : "var(--text-secondary)" }}>
                    {c.code}
                  </span>
                </button>
              ))}
            </div>
            <div style={{ fontSize:10.5, fontWeight:800, color:"var(--text-muted)",
              letterSpacing:1.6, marginBottom:9 }}>ALL COUNTRIES</div>
          </>
        )}

        {filtered.length === 0 && (
          <div style={{ textAlign:"center", padding:"40px 20px" }}>
            <div style={{ fontSize:36, marginBottom:10 }}>🌐</div>
            <div style={{ fontSize:14, fontWeight:700,
              color:"var(--text-primary)", marginBottom:6 }}>
              No results for "{search}"
            </div>
            <div style={{ fontSize:12.5, color:"var(--text-muted)" }}>
              Try searching by country name or dial code like "+44"
            </div>
          </div>
        )}

        {filtered.map((c, i) => {
          const isSel = selected?.code === c.code;
          return (
            <div key={c.code} onClick={() => pickCountry(c)}
              className="row-tap fade-up"
              style={{
                display:"flex", alignItems:"center", gap:13,
                padding:"12px 14px", marginBottom:8,
                background: isSel ? "var(--accent-dim)" : "var(--bg-surface)",
                borderRadius:"var(--r-lg)",
                border:`1.5px solid ${isSel ? "var(--accent)" : "var(--border)"}`,
                cursor:"pointer",
                boxShadow: isSel ? "var(--shadow-accent)" : "var(--shadow-sm)",
                transition:"all 0.18s",
                animationDelay:`${Math.min(i * 0.025, 0.3)}s`,
              }}>

              {/* Flag box */}
              <div style={{
                width:46, height:46, borderRadius:13, flexShrink:0,
                background: isSel ? "rgba(232,160,32,0.15)" : "var(--bg-raised)",
                display:"flex", alignItems:"center",
                justifyContent:"center", fontSize:24,
              }}>{c.flag}</div>

              {/* Info */}
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:14.5, fontWeight:700,
                  color: isSel ? "var(--accent)" : "var(--text-primary)",
                  marginBottom:3 }}>
                  {c.name}
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                  <span style={{ fontSize:12, color:"var(--text-muted)",
                    fontFamily:"var(--font-mono)" }}>{c.prefix}</span>
                  {c.instant && (
                    <span style={{ fontSize:9.5, fontWeight:700, color:"var(--green)",
                      background:"var(--green-dim)", padding:"1px 7px",
                      borderRadius:99 }}>⚡ Instant</span>
                  )}
                  {!c.instant && (
                    <span style={{ fontSize:9.5, fontWeight:600,
                      color:"var(--text-muted)" }}>1–2 days</span>
                  )}
                </div>
              </div>

              {/* Check or arrow */}
              {isSel
                ? <div style={{ width:26, height:26, borderRadius:"50%",
                    background:"var(--accent)", flexShrink:0,
                    display:"flex", alignItems:"center", justifyContent:"center",
                    boxShadow:"0 2px 8px var(--accent-glow)" }}>
                    <Check size={12} color="white"/>
                  </div>
                : <Ic d="M9 18l6-6-6-6" size={14}
                    color="var(--text-muted)" sw={2}/>
              }
            </div>
          );
        })}
      </div>

      {/* Sticky bottom CTA — appears when a country is selected */}
      {selected && (
        <div className="slide-up" style={{
          position:"absolute", bottom:0, left:0, right:0,
          background:"var(--bg-surface)",
          borderTop:"1px solid var(--border)",
          padding:"14px 17px 28px",
          boxShadow:"0 -8px 32px rgba(0,0,0,0.09)",
        }}>
          {/* Selected number preview */}
          <div style={{
            display:"flex", alignItems:"center", gap:12,
            background:"var(--bg-raised)",
            borderRadius:"var(--r-md)", padding:"11px 14px", marginBottom:12,
          }}>
            <span style={{ fontSize:24 }}>{selected.flag}</span>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:15, fontWeight:800,
                fontFamily:"var(--font-mono)", color:"var(--text-primary)",
                letterSpacing:"-0.3px", overflow:"hidden",
                textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                {number}
              </div>
              <div style={{ fontSize:11.5, color:"var(--text-muted)", marginTop:2 }}>
                {selected.name} · {selected.prefix} · ${selected.price}/mo
              </div>
            </div>
            <button onClick={() => setNumber(genNumber(selected.prefix))}
              style={{ background:"none", border:"none", fontSize:12,
                color:"var(--accent)", fontWeight:700, cursor:"pointer",
                flexShrink:0, fontFamily:"inherit" }}>
              Refresh
            </button>
          </div>

          {/* CTA — "Get {Country} Number" */}
          <button className="press" onClick={confirm} disabled={loading} style={{
            width:"100%", height:54,
            background: loading ? "var(--accent-dim)" : "var(--accent)",
            border:"none", borderRadius:"var(--r-xl)",
            color: loading ? "var(--accent)" : "var(--bg-base)",
            fontSize:15.5, fontWeight:800,
            display:"flex", alignItems:"center", justifyContent:"center", gap:10,
            cursor: loading ? "default" : "pointer",
            boxShadow: loading ? "none" : "var(--shadow-accent)",
            letterSpacing:"-0.2px",
            transition:"all 0.15s",
          }}>
            {loading
              ? <><Spinner color="var(--accent)"/>Provisioning via Telnyx…</>
              : `Get ${selected.name} Number →`
            }
          </button>
        </div>
      )}
    </div>
  );
}
