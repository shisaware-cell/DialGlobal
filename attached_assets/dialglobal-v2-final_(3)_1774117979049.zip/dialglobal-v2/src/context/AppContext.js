// src/context/AppContext.js — Full state management
import React, { createContext, useContext, useState } from "react";
import { MOCK_NUMBERS } from "../data/mockData";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [screen,          setScreen]         = useState("onboarding");
  const [prevScreen,      setPrevScreen]     = useState(null);

  // Plan & subscription
  const [currentPlan,     setCurrentPlan]    = useState(null);       // null = not subscribed
  const [pendingPlan,     setPendingPlan]    = useState("professional"); // selected in paywall
  const [billing,         setBilling]        = useState("monthly");
  const [trialPlan,       setTrialPlan]      = useState(null);
  const [isInTrial,       setIsInTrial]      = useState(false);
  const [trialEnds,       setTrialEnds]      = useState(null);
  const [trialExpired,    setTrialExpired]   = useState(false);

  // Usage
  const [credits,         setCredits]        = useState(0);
  const [trialMinsUsed,   setTrialMinsUsed]  = useState(4);   // demo: some usage
  const [trialSmsUsed,    setTrialSmsUsed]   = useState(3);

  // Numbers
  const [numbers,         setNumbers]        = useState(MOCK_NUMBERS);
  const [selectedNumber,  setSelectedNumber] = useState(null);

  // Features
  const [ghostMode,       setGhostMode]      = useState(false);
  const [contacts,        setContacts]       = useState([]);
  const [dndNumbers,      setDndNumbers]     = useState({});
  const [spamEnabled,     setSpamEnabled]    = useState({});
  const [autoReplies,     setAutoReplies]    = useState({});
  const [recordings,      setRecordings]     = useState({});
  const [forwarding,      setForwarding]     = useState({});
  const [forwardingNums,  setForwardingNums] = useState({});
  const [notifications,   setNotifications]  = useState(true);

  // StoreKit — local currency prices fetched at runtime
  // Key: App Store product ID → value: { displayPrice, price, currency }
  // Falls back to USD defaults from mockData until StoreKit loads
  // In production: populate via native StoreKit 2 bridge on app launch
  const [storeProducts,   setStoreProducts]   = useState({});
  const [storeLoading,    setStoreLoading]    = useState(false);

  // UI
  const [toast,           setToast]          = useState(null);
  const [incomingCall,    setIncomingCall]   = useState(null);
  const [activeEsim,      setActiveEsim]     = useState(null);

  function navigate(to) { setPrevScreen(screen); setScreen(to); }
  function goBack()      { setScreen(prevScreen || "home"); setPrevScreen(null); }

  function selectPlan(planId) { setPendingPlan(planId); }

  function upgradePlan(planId, billingCycle = "monthly") {
    setTrialPlan(planId);
    setCurrentPlan(planId);
    setBilling(billingCycle);
    setIsInTrial(true);
    setTrialExpired(false);
    setTrialEnds(new Date(Date.now() + 3 * 86400000));
    // In production: App Store webhook on day 4 sets isInTrial=false
  }

  function expireTrial() {
    setIsInTrial(false);
    setTrialExpired(true);
    setCurrentPlan(null);
  }

  function fullPlanActivate() {
    setIsInTrial(false);
    setTrialExpired(false);
    // currentPlan stays set — full features now unlocked
  }

  function setTrialActive(val) { setIsInTrial(val); }

  function addCredits(amount) { setCredits(c => c + amount); }
  function addNumber(num)     { setNumbers(prev => [...prev, num]); }
  function removeNumber(id)   { setNumbers(prev => prev.filter(n => n.id !== id)); }
  function toggleDnd(id)          { setDndNumbers(p => ({ ...p, [id]: !p[id] })); }
  function toggleSpam(id)         { setSpamEnabled(p => ({ ...p, [id]: !p[id] })); }
  function toggleRecording(id)    { setRecordings(p => ({ ...p, [id]: !p[id] })); }
  function toggleForwarding(id)   { setForwarding(p => ({ ...p, [id]: !p[id] })); }
  function setForwardingNum(id, num) { setForwardingNums(p => ({ ...p, [id]: num })); }
  function setAutoReply(id, msg)  { setAutoReplies(p => ({ ...p, [id]: msg })); }
  function importContacts(list)   {
    setContacts(prev => {
      const existing = new Set(prev.map(c => c.phone));
      return [...prev, ...list.filter(c => !existing.has(c.phone))];
    });
  }
  function showToast(message, type = "info") {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  }
  function simulateIncomingCall() {
    setIncomingCall({ caller: "Marcus Webb", number: "+1 917 555 0134" });
  }
  function dismissIncomingCall() { setIncomingCall(null); }
  function activateEsim(plan)    { setActiveEsim(plan); }

  // StoreKit price loader — called from native bridge when products are fetched
  // productMap format: { "com.dialglobal.traveller.monthly": { displayPrice:"R 149", price:7.99, currency:"ZAR" }, ... }
  function loadStoreProducts(productMap) {
    setStoreProducts(productMap);
    setStoreLoading(false);
  }

  // Helper: get display price for a product, fall back to USD default
  function getDisplayPrice(productId, usdFallback) {
    const p = storeProducts[productId];
    return p ? p.displayPrice : (usdFallback ? `$${usdFallback}` : "...");
  }

  return (
    <AppContext.Provider value={{
      screen, navigate, goBack,
      currentPlan, pendingPlan, selectPlan, billing,
      trialPlan, isInTrial, trialEnds, trialExpired,
      trialMinsUsed, trialSmsUsed,
      upgradePlan, expireTrial, fullPlanActivate, setTrialActive,
      credits, addCredits,
      numbers, addNumber, removeNumber,
      selectedNumber, setSelectedNumber,
      ghostMode, setGhostMode,
      contacts, importContacts,
      dndNumbers, toggleDnd,
      spamEnabled, toggleSpam,
      autoReplies, setAutoReply,
      recordings, toggleRecording,
      forwarding, toggleForwarding,
      forwardingNums, setForwardingNum,
      notifications, setNotifications,
      toast, showToast,
      incomingCall, simulateIncomingCall, dismissIncomingCall,
      activeEsim, activateEsim,
      storeProducts, storeLoading, loadStoreProducts, getDisplayPrice,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() { return useContext(AppContext); }
