// src/data/mockData.js — Final pricing v3

export const COUNTRIES = [
  {code:"US",name:"United States", flag:"🇺🇸",prefix:"+1", price:2.99,instant:true, popular:true},
  {code:"GB",name:"United Kingdom",flag:"🇬🇧",prefix:"+44",price:2.99,instant:true, popular:true},
  {code:"CA",name:"Canada",        flag:"🇨🇦",prefix:"+1", price:2.99,instant:true, popular:true},
  {code:"AU",name:"Australia",     flag:"🇦🇺",prefix:"+61",price:3.99,instant:true, popular:true},
  {code:"DE",name:"Germany",       flag:"🇩🇪",prefix:"+49",price:3.99,instant:true, popular:false},
  {code:"FR",name:"France",        flag:"🇫🇷",prefix:"+33",price:3.99,instant:true, popular:false},
  {code:"NL",name:"Netherlands",   flag:"🇳🇱",prefix:"+31",price:3.49,instant:true, popular:false},
  {code:"SG",name:"Singapore",     flag:"🇸🇬",prefix:"+65",price:4.99,instant:true, popular:false},
  {code:"JP",name:"Japan",         flag:"🇯🇵",prefix:"+81",price:5.99,instant:false,popular:false},
  {code:"ZA",name:"South Africa",  flag:"🇿🇦",prefix:"+27",price:3.99,instant:false,popular:false},
  {code:"SE",name:"Sweden",        flag:"🇸🇪",prefix:"+46",price:3.49,instant:true, popular:false},
  {code:"NZ",name:"New Zealand",   flag:"🇳🇿",prefix:"+64",price:3.99,instant:true, popular:false},
];

export const MOCK_NUMBERS = [
  {id:1,number:"+1 (415) 823-4921",country:"United States", flag:"🇺🇸",type:"permanent",calls:12,sms:47,plan:"Professional",missedCalls:2,lastActivity:"2m ago"},
  {id:2,number:"+44 7700 123 456", country:"United Kingdom",flag:"🇬🇧",type:"temporary",calls:3, sms:8, plan:"Traveller",  missedCalls:0,lastActivity:"1h ago",expiresIn:"5 days"},
];

export const MOCK_MESSAGES = [
  {id:1,name:"Marcus Webb",  number:"+1 917 555 0134", preview:"Hey, are you free for a call tomorrow?",time:"2m", unread:2,flag:"🇺🇸",type:"sms"},
  {id:2,name:"Priya Sharma", number:"+44 7900 112233", preview:"The contract has been sent to your email",time:"14m",unread:0,flag:"🇬🇧",type:"sms"},
  {id:3,name:"Unknown",      number:"+1 650 555 7823", preview:"Missed call",                              time:"1h", unread:1,flag:"🇺🇸",type:"missed"},
  {id:4,name:"David Chen",   number:"+61 4 1234 5678", preview:"Thanks for getting back to me!",          time:"3h", unread:0,flag:"🇦🇺",type:"sms"},
  {id:5,name:"Sarah Miller", number:"+49 30 1234567",  preview:"Voicemail: 0:42",                         time:"1d", unread:0,flag:"🇩🇪",type:"voicemail"},
];

export const MOCK_CALLS = [
  {id:1,name:"Marcus Webb",  number:"+1 917 555 0134", flag:"🇺🇸",type:"incoming", duration:"4:32", time:"2m ago"},
  {id:2,name:"Priya Sharma", number:"+44 7900 112233", flag:"🇬🇧",type:"outgoing", duration:"12:05",time:"1h ago"},
  {id:3,name:"Unknown",      number:"+1 650 555 7823", flag:"🇺🇸",type:"missed",   duration:"",     time:"2h ago"},
  {id:4,name:"David Chen",   number:"+61 4 1234 5678", flag:"🇦🇺",type:"outgoing", duration:"1:44", time:"Yesterday"},
  {id:5,name:"Sarah Miller", number:"+49 30 1234567",  flag:"🇩🇪",type:"voicemail",duration:"0:42", time:"Yesterday"},
];

export function genNumber(prefix) {
  const a=Math.floor(Math.random()*900+100),b=Math.floor(Math.random()*900+100),c=Math.floor(Math.random()*9000+1000);
  if(prefix==="+1")  return `${prefix} (${a}) ${b}-${c}`;
  if(prefix==="+44") return `${prefix} 7${a} ${b} ${c}`;
  return `${prefix} ${a} ${b} ${c}`;
}

// ─── FINAL PRICING ─────────────────────────────────────────────────────────
// All prices are App Store / Google Play prices (store takes 15%).
// Your net after store fee: multiply price × 0.85
// Telnyx costs: number $1.10/mo, call $0.007/min outbound, $0.0055/min inbound,
//               SMS $0.007/msg, recording $0.002/min extra
//
// Minutes = calls to ANY phone number worldwide (not just app users)
// Overage: deducted from credit wallet at $0.02/min, $0.02/SMS
// ───────────────────────────────────────────────────────────────────────────
export const PLANS = [
  {
    id:           "traveller",
    name:         "Traveller",
    persona:      "For people who travel and need a local number abroad",
    emoji:        "✈️",
    color:        "var(--blue)",
    colorDim:     "var(--blue-dim)",
    monthlyPrice: 7.99,
    yearlyPrice:  6.42,          // 20% off → billed as $76.99/yr
    yearlyBilled: 76.99,
    numberLimit:  1,
    callMinutes:  100,           // any number worldwide
    smsLimit:     300,
    hasRecording: false,
    hasAutoReply: false,
    hasSpamBlock: false,
    hasForwarding:true,
    hasPriority:  false,
    includedCredits: 0,
    features: [
      "1 virtual number (any country)",
      "100 min calls to any number worldwide",
      "300 SMS included",
      "Call forwarding & voicemail",
      "Push notifications for calls & SMS",
      "eSIM plans available separately",
    ],
    notIncluded: ["Call recording","Auto-reply","Spam blocker","Extra numbers"],
    telnyx_cost_est: 2.14,      // 1 number + avg 80min + 80 SMS
  },
  {
    id:           "professional",
    name:         "Professional",
    persona:      "For freelancers, remote workers & side businesses",
    emoji:        "💼",
    color:        "var(--green)",
    colorDim:     "var(--green-dim)",
    monthlyPrice: 14.99,
    yearlyPrice:  11.99,
    yearlyBilled: 143.99,
    numberLimit:  3,
    callMinutes:  300,
    smsLimit:     9999,          // unlimited SMS
    hasRecording: true,
    hasAutoReply: true,
    hasSpamBlock: true,
    hasForwarding:true,
    hasPriority:  false,
    includedCredits: 5,          // $5 credit wallet topped up monthly
    features: [
      "3 virtual numbers (any country)",
      "300 min calls to any number worldwide",
      "Unlimited SMS",
      "Call recording & voicemail transcription",
      "Auto-reply & spam blocker",
      "Call forwarding",
      "$5 credits included monthly",
      "eSIM plans available separately",
    ],
    notIncluded: ["More than 3 numbers","API access"],
    telnyx_cost_est: 5.55,
  },
  {
    id:           "business",
    name:         "Business",
    persona:      "For teams, entrepreneurs & power users",
    emoji:        "🏢",
    color:        "var(--purple)",
    colorDim:     "var(--purple-dim)",
    monthlyPrice: 19.99,
    yearlyPrice:  15.99,
    yearlyBilled: 191.99,
    numberLimit:  10,
    callMinutes:  500,           // 500 min included; overage via credits
    smsLimit:     9999,
    hasRecording: true,
    hasAutoReply: true,
    hasSpamBlock: true,
    hasForwarding:true,
    hasPriority:  true,
    includedCredits: 15,
    features: [
      "10 virtual numbers (100+ countries)",
      "500 min calls to any number worldwide",
      "Unlimited SMS",
      "Everything in Professional",
      "Custom caller ID",
      "API access",
      "$15 credits included monthly",
      "Priority support",
      "eSIM plans available separately",
    ],
    notIncluded: [],
    telnyx_cost_est: 9.70,
  },
];

// ─── CREDIT PACKS ──────────────────────────────────────────────────────────
// Sold via App Store IAP (store takes 15%).
// Credits are a dollar wallet: $1 credit = $1 of usage.
// Usage rates charged from wallet:
//   Outbound call: $0.02/min  (your cost $0.007, markup ~185%)
//   Inbound call:  $0.015/min (your cost $0.0055)
//   SMS:           $0.02/msg  (your cost $0.007)
//   Recording:     $0.005/min (your cost $0.002)
//   Extra number:  $1.50/number/month
// ───────────────────────────────────────────────────────────────────────────
// ─── CREDIT PACKS ──────────────────────────────────────────────────────────
// Apple App Review requirements:
//   - credits = EXACT dollar amount user receives in their wallet (no ambiguity)
//   - bonusLabel = marketing display only, bonus IS already included in credits amount
//   - equiv = accurate usage estimate based on $0.02/min charge rate
//   - All credits amounts verified: profitable even after bonus (65% margin on usage)
//
// Margin check per pack:
//   We receive after 15% store fee = price × 0.85
//   When wallet fully spent at $0.02/min → Telnyx costs us credits × 0.35
//   Net profit = (price × 0.85) - (credits × 0.35)
//
//   Starter: $2.54 received - ($2.54 × 0.35 = $0.89) = $1.65 profit (55% margin)
//   Standard:$5.94 received - ($6.50 × 0.35 = $2.28) = $3.66 profit (52% margin)
//   Value:  $11.04 received - ($12.50 × 0.35 = $4.38) = $6.66 profit (51% margin)
//   Power:  $21.24 received - ($24.00 × 0.35 = $8.40) = $12.84 profit (51% margin)
// ───────────────────────────────────────────────────────────────────────────
export const CREDIT_PACKS = [
  {
    id:"c1", label:"Starter", price:2.99,
    credits:2.54,         // exact wallet amount (price × 0.85, no bonus)
    bonusLabel:null,
    popular:false,
    equiv:"~127 minutes of calls or 127 SMS",
    approxMins:127,
  },
  {
    id:"c2", label:"Standard", price:6.99,
    credits:6.50,         // $5.94 after store fee + $0.56 bonus = $6.50 total
    bonusLabel:"+$0.56 bonus",
    popular:true,
    equiv:"~325 minutes of calls or 325 SMS",
    approxMins:325,
  },
  {
    id:"c3", label:"Value", price:12.99,
    credits:12.50,        // $11.04 after store fee + $1.46 bonus = $12.50 total
    bonusLabel:"+$1.46 bonus",
    popular:false,
    equiv:"~625 minutes of calls or 625 SMS",
    approxMins:625,
  },
  {
    id:"c4", label:"Power", price:24.99,
    credits:24.00,        // $21.24 after store fee + $2.76 bonus = $24.00 total
    bonusLabel:"+$2.76 bonus",
    popular:false,
    equiv:"~1,200 minutes of calls or 1,200 SMS",
    approxMins:1200,
  },
];

// ─── eSIM PLANS ─────────────────────────────────────────────────────────────
export const ESIM_PLANS = [
  {id:"e1",region:"Africa & Middle East",emoji:"🌍",data:"1 GB",dataGB:1,days:7, price:5.99, perDay:"$0.86/day",popular:false,countryFlags:"🇿🇦🇳🇬🇦🇪",features:["30+ countries","LTE speeds","Instant activation"]},
  {id:"e2",region:"Americas",            emoji:"🌎",data:"3 GB",dataGB:3,days:14,price:9.99, perDay:"$0.71/day",popular:true, countryFlags:"🇺🇸🇨🇦🇲🇽🇧🇷",features:["25+ countries","LTE/5G speeds","Instant activation"]},
  {id:"e3",region:"Asia Pacific",        emoji:"🌏",data:"2 GB",dataGB:2,days:10,price:7.99, perDay:"$0.80/day",popular:false,countryFlags:"🇸🇬🇯🇵🇦🇺🇳🇿",features:["20+ countries","LTE speeds","Instant activation"]},
  {id:"e4",region:"Europe",              emoji:"🇪🇺",data:"5 GB",dataGB:5,days:30,price:15.99,perDay:"$0.53/day",popular:false,countryFlags:"🇬🇧🇩🇪🇫🇷🇸🇪",features:["40+ countries","LTE/5G speeds","Instant activation"]},
  {id:"e5",region:"Global",              emoji:"🌐",data:"3 GB",dataGB:3,days:15,price:21.99,perDay:"$1.47/day",popular:false,countryFlags:"🌍🌎🌏",          features:["160+ countries","LTE/5G","Single eSIM works everywhere"]},
];

// ─── CREDIT USAGE RATES ────────────────────────────────────────────────────
// These are the rates deducted from the credit wallet for overage usage.
// Must match exactly what is displayed in the Credits screen and Terms of Service.
// Apple requires these to be clearly disclosed in the app before purchase.
export const CREDIT_RATES = {
  outboundCallPerMin:  0.020,   // $0.020/min  (Telnyx costs $0.007 → 65% margin)
  inboundCallPerMin:   0.015,   // $0.015/min  (Telnyx costs $0.0055 → 63% margin)
  smsPerMessage:       0.020,   // $0.020/SMS  (Telnyx costs $0.007 → 65% margin)
  recordingPerMin:     0.005,   // $0.005/min  (Telnyx costs $0.002 → 60% margin)
  extraNumberPerMonth: 1.990,   // $1.99/number/month (Telnyx $1.10 → 45% margin)
  // Note: eSIM plans are separate purchases, not credit-rate based
};

// ─── APP STORE PRODUCT IDs ─────────────────────────────────────────────────
// Create these exact product IDs in App Store Connect.
// The displayPrice for each will be fetched via StoreKit at runtime
// and stored in AppContext.storeProducts.
// Until fetched, the app shows USD fallback prices from PLANS/CREDIT_PACKS above.
export const STORE_PRODUCT_IDS = {
  // Auto-renewable subscriptions (6 products)
  traveller_monthly:    "com.dialglobal.traveller.monthly",
  traveller_yearly:     "com.dialglobal.traveller.yearly",
  professional_monthly: "com.dialglobal.professional.monthly",
  professional_yearly:  "com.dialglobal.professional.yearly",
  business_monthly:     "com.dialglobal.business.monthly",
  business_yearly:      "com.dialglobal.business.yearly",
  // Consumable IAPs (4 products)
  credits_starter:      "com.dialglobal.credits.starter",
  credits_standard:     "com.dialglobal.credits.standard",
  credits_value:        "com.dialglobal.credits.value",
  credits_power:        "com.dialglobal.credits.power",
};

// Helper: map plan ID + billing to its App Store product ID
export function getPlanProductId(planId, billing) {
  return STORE_PRODUCT_IDS[`${planId}_${billing}`] || null;
}

// Trial config
export const TRIAL_CONFIG = {
  days: 3,
  freeCredits: 2.00,   // $2 gifted on signup
  requiresCard: true,
};

// ─── UNIVERSAL TRIAL LIMITS ─────────────────────────────────────────────────
// Same trial regardless of which plan user selects.
// Plan determines what they get AFTER trial ends on day 4.
// We keep trial cheap for us (~$0.30 Telnyx cost) while being useful enough
// to show value and convert.
export const TRIAL_LIMITS = {
  days:           3,
  callMinutes:    15,       // enough for 2-3 real test calls
  smsLimit:       10,       // enough to test messaging
  numberLimit:    1,        // one number only during trial
  freeCredits:    2.00,     // $2 wallet credit to test with
  hasRecording:   false,    // no recording in trial
  hasAutoReply:   false,
  hasSpamBlock:   false,
  hasForwarding:  false,    // no forwarding in trial
  requiresCard:   true,     // card required — prevents abuse
  // What trial users CAN do:
  canCall:        true,
  canSMS:         true,
  canReceiveCalls:true,
  canPickCountry: true,     // pick any country for their 1 number
  // Cost to us per trial user:
  // ~$1.10 (number) + $0.10 (15min) + $0.07 (10 SMS) + $2 credits = ~$3.27
  // Most trial users won't even hit the limits — avg cost ~$1.50
};
