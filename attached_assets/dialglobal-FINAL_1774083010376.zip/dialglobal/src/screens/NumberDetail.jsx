// src/screens/NumberDetail.jsx
import React, { useState } from "react";
import { Ic, Toggle, DeleteSheet } from "../components/UI";
import { useApp } from "../context/AppContext";
import { MOCK_CALLS } from "../data/mockData";

export default function NumberDetail() {
  const { goBack, navigate, selectedNumber, removeNumber } = useApp();
  const num = selectedNumber;

  const [voicemail,    setVoicemail]    = useState(true);
  const [recording,    setRecording]    = useState(false);
  const [forwarding,   setForwarding]   = useState(false);
  const [fwdNum,       setFwdNum]       = useState("");
  const [showDelete,   setShowDelete]   = useState(false);

  if (!num) { navigate("home"); return null; }

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden",position:"relative"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <h2 style={{fontSize:18,fontWeight:700,color:"var(--text-primary)",letterSpacing:"-0.3px"}}>Number Details</h2>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <div style={{width:52,height:52,borderRadius:16,background:"var(--bg-raised)",
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:26}}>{num.flag}</div>
          <div style={{flex:1}}>
            <div style={{fontSize:17,fontWeight:700,color:"var(--text-primary)",letterSpacing:"-0.4px",fontFamily:"var(--font-mono)"}}>{num.number}</div>
            <div style={{fontSize:12,color:"var(--text-secondary)",marginTop:2}}>{num.country}</div>
          </div>
          <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:5}}>
            <span style={{fontSize:9.5,fontWeight:700,padding:"3px 9px",borderRadius:99,
              color:num.type==="permanent"?"var(--accent)":"var(--green)",
              background:num.type==="permanent"?"var(--accent-dim)":"var(--green-dim)"}}>
              {num.type==="permanent"?"Permanent":`⏱ ${num.expiresIn}`}
            </span>
            <div style={{display:"flex",alignItems:"center",gap:4}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:"var(--green)",animation:"pulse 2s ease infinite"}}/>
              <span style={{fontSize:10,color:"var(--green)",fontWeight:600}}>Active</span>
            </div>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"14px 16px 28px"}}>
        {/* Quick actions */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:20}}>
          {[
            {label:"Call",    d:"M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z", accent:true},
            {label:"Message", d:"M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z", onClick:()=>navigate("inbox")},
            {label:"Share",   d:"M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8M16 6l-4-4-4 4M12 2v13"},
          ].map((a,i)=>(
            <button key={i} className="press" onClick={a.onClick} style={{height:62,
              background:a.accent?"var(--accent)":"var(--bg-surface)",
              border:a.accent?"none":"1px solid var(--border)",borderRadius:"var(--r-md)",
              display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:6,
              cursor:"pointer",transition:"transform 0.1s",
              boxShadow:a.accent?"0 4px 14px var(--accent-glow)":"none"}}>
              <Ic d={a.d} size={18} color={a.accent?"var(--bg-base)":"var(--text-secondary)"} sw={a.accent?2.5:2}/>
              <span style={{fontSize:11,fontWeight:600,color:a.accent?"var(--bg-base)":"var(--text-secondary)"}}>{a.label}</span>
            </button>
          ))}
        </div>

        {/* Stats */}
        <div style={{display:"flex",gap:8,marginBottom:20}}>
          {[{label:"Calls",value:num.calls,c:"var(--accent)"},{label:"Messages",value:num.sms,c:"var(--green)"},{label:"Last active",value:num.lastActivity,c:"var(--blue)"}].map((s,i)=>(
            <div key={i} style={{flex:1,background:"var(--bg-surface)",border:"1px solid var(--border)",
              borderRadius:"var(--r-md)",padding:"11px 8px",textAlign:"center"}}>
              <div style={{fontSize:19,fontWeight:700,color:s.c,letterSpacing:"-0.4px",fontFamily:"var(--font-mono)"}}>{s.value}</div>
              <div style={{fontSize:9,color:"var(--text-muted)",marginTop:2}}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Settings */}
        <div style={{background:"var(--bg-surface)",border:"1px solid var(--border)",
          borderRadius:"var(--r-lg)",overflow:"hidden",marginBottom:16}}>
          <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,padding:"14px 16px 0"}}>NUMBER SETTINGS</div>
          {[
            {label:"Voicemail",      sublabel:"Record missed calls",           value:voicemail,  set:setVoicemail},
            {label:"Call Recording", sublabel:"Save all calls automatically",  value:recording,  set:setRecording},
            {label:"Call Forwarding",sublabel:"Route to another number",       value:forwarding, set:setForwarding},
          ].map((row,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:12,
              padding:"13px 16px",borderTop:"1px solid var(--border)"}}>
              <div style={{flex:1}}>
                <div style={{fontSize:13.5,fontWeight:500,color:"var(--text-primary)"}}>{row.label}</div>
                <div style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>{row.sublabel}</div>
              </div>
              <Toggle value={row.value} onChange={row.set}/>
            </div>
          ))}
          {forwarding && (
            <div style={{padding:"0 16px 14px"}}>
              <input value={fwdNum} onChange={e=>setFwdNum(e.target.value)} placeholder="+1 (555) 000-0000"
                style={{width:"100%",height:42,borderRadius:"var(--r-sm)",border:"1.5px solid var(--border)",
                  background:"var(--bg-input)",padding:"0 13px",fontSize:13,color:"var(--text-primary)",
                  outline:"none",fontFamily:"var(--font-mono)"}}/>
            </div>
          )}
        </div>

        {/* Recent calls */}
        <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:8}}>RECENT CALLS</div>
        <div style={{background:"var(--bg-surface)",border:"1px solid var(--border)",
          borderRadius:"var(--r-lg)",overflow:"hidden",marginBottom:16}}>
          {MOCK_CALLS.slice(0,3).map((cl,i)=>{
            const colors={missed:"var(--red)",incoming:"var(--green)",outgoing:"var(--blue)",voicemail:"var(--text-secondary)"};
            return(
              <div key={cl.id} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",
                borderBottom:i<2?"1px solid var(--border)":"none"}}>
                <div style={{width:36,height:36,borderRadius:11,
                  background:cl.type==="missed"?"var(--red-dim)":cl.type==="incoming"?"var(--green-dim)":"var(--blue-dim)",
                  display:"flex",alignItems:"center",justifyContent:"center"}}>
                  <Ic d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-.4-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 8.15a16 16 0 006.93 6.93l1.51-1.51a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"
                    size={14} color={colors[cl.type]||colors.outgoing} sw={2}/>
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,fontWeight:600,color:cl.type==="missed"?"var(--red)":"var(--text-primary)"}}>{cl.name}</div>
                  <div style={{fontSize:10.5,color:"var(--text-muted)",fontFamily:"var(--font-mono)"}}>{cl.number}</div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:10.5,color:"var(--text-muted)"}}>{cl.time}</div>
                  {cl.duration&&<div style={{fontSize:10,color:"var(--text-secondary)",fontFamily:"var(--font-mono)"}}>{cl.duration}</div>}
                </div>
              </div>
            );
          })}
        </div>

        {/* Danger zone */}
        <div style={{background:"var(--red-dim)",border:"1px solid rgba(220,38,38,0.15)",
          borderRadius:"var(--r-lg)",padding:"14px 16px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div>
            <div style={{fontSize:13.5,fontWeight:600,color:"var(--red)"}}>Release Number</div>
            <div style={{fontSize:11,color:"var(--text-muted)",marginTop:2}}>Permanently delete this number</div>
          </div>
          <button className="press" onClick={() => setShowDelete(true)} style={{height:34,padding:"0 14px",
            background:"var(--red)",border:"none",borderRadius:"var(--r-sm)",
            color:"white",fontSize:12,fontWeight:700,transition:"transform 0.1s",cursor:"pointer"}}>
            Release
          </button>
        </div>
      </div>

      {showDelete && (
        <DeleteSheet
          title="Release this number?"
          body={`${num.number} will be permanently deleted and returned to the pool. This cannot be undone.`}
          confirmLabel="Yes, release number"
          onClose={() => setShowDelete(false)}
          onConfirm={() => { removeNumber(num.id); setShowDelete(false); navigate("home"); }}
        />
      )}
    </div>
  );
}
