// src/screens/AutoReply.jsx
import React, { useState } from "react";
import { Toggle } from "../components/UI";
import { useApp } from "../context/AppContext";
import { Ic } from "../components/UI";

const TEMPLATES = [
  "I'm currently unavailable. I'll get back to you soon.",
  "Hi! I'm in a meeting right now. I'll reply shortly.",
  "Travelling at the moment — will respond when I land!",
  "This number is for business hours only (Mon–Fri 9–5).",
  "Please send your enquiry to email instead.",
];

export default function AutoReply() {
  const { goBack, numbers, autoReplies, setAutoReply } = useApp();
  const [activeNum, setActiveNum] = useState(numbers[0]?.id || null);
  const [text, setText]           = useState(autoReplies[numbers[0]?.id] || "");
  const [enabled, setEnabled]     = useState(!!autoReplies[numbers[0]?.id]);
  const [saved, setSaved]         = useState(false);

  const selectNum = (id) => {
    setActiveNum(id);
    setText(autoReplies[id] || "");
    setEnabled(!!autoReplies[id]);
    setSaved(false);
  };

  const save = () => {
    if (activeNum) setAutoReply(activeNum, enabled ? text : "");
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{fontSize:18,fontWeight:700,color:"var(--text-primary)"}}>Auto-Reply</h2>
            <p style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>Send automatic replies when you're away</p>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"14px 16px"}}>
        {/* Number selector */}
        {numbers.length > 1 && (
          <div style={{marginBottom:16}}>
            <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:8}}>SELECT NUMBER</div>
            <div style={{display:"flex",gap:8,overflowX:"auto",paddingBottom:4}}>
              {numbers.map(n=>(
                <button key={n.id} onClick={()=>selectNum(n.id)} style={{flexShrink:0,height:36,padding:"0 14px",
                  borderRadius:99,border:`1.5px solid ${activeNum===n.id?"var(--accent)":"var(--border)"}`,
                  background:activeNum===n.id?"var(--accent-dim)":"var(--bg-surface)",
                  color:activeNum===n.id?"var(--accent)":"var(--text-secondary)",
                  fontSize:12,fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:6}}>
                  <span>{n.flag}</span><span style={{fontFamily:"var(--font-mono)",fontSize:11}}>{n.number.split(" ").slice(0,2).join(" ")}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Toggle */}
        <div style={{background:"var(--bg-surface)",border:"1px solid var(--border)",borderRadius:"var(--r-lg)",
          padding:"14px 16px",marginBottom:16,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div>
            <div style={{fontSize:14,fontWeight:600,color:"var(--text-primary)"}}>Enable Auto-Reply</div>
            <div style={{fontSize:11,color:"var(--text-muted)",marginTop:2}}>Send when you're unavailable</div>
          </div>
          <Toggle value={enabled} onChange={setEnabled}/>
        </div>

        {enabled && (
          <>
            {/* Message editor */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:8}}>YOUR MESSAGE</div>
              <textarea value={text} onChange={e=>setText(e.target.value)}
                placeholder="Type your auto-reply message…"
                rows={4}
                style={{width:"100%",borderRadius:"var(--r-md)",border:"1.5px solid var(--border)",
                  background:"var(--bg-surface)",padding:"12px 14px",fontSize:13.5,
                  color:"var(--text-primary)",outline:"none",resize:"none",lineHeight:1.6,
                  fontFamily:"inherit"}}/>
              <div style={{fontSize:11,color:"var(--text-muted)",textAlign:"right",marginTop:4}}>
                {text.length}/160
              </div>
            </div>

            {/* Templates */}
            <div style={{marginBottom:16}}>
              <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:8}}>QUICK TEMPLATES</div>
              <div style={{display:"flex",flexDirection:"column",gap:7}}>
                {TEMPLATES.map((t,i)=>(
                  <button key={i} onClick={()=>setText(t)} style={{textAlign:"left",padding:"10px 13px",
                    background:"var(--bg-surface)",border:"1px solid var(--border)",borderRadius:"var(--r-sm)",
                    fontSize:12.5,color:"var(--text-secondary)",lineHeight:1.5,cursor:"pointer",
                    transition:"background 0.12s",fontFamily:"inherit"}}
                    onMouseEnter={e=>e.target.style.background="var(--bg-raised)"}
                    onMouseLeave={e=>e.target.style.background="var(--bg-surface)"}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Save */}
        {saved ? (
          <div className="fade-in" style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,
            height:52,background:"var(--green-dim)",borderRadius:"var(--r-md)"}}>
            <Ic d="M20 6L9 17l-5-5" size={16} color="var(--green)" sw={2.5}/>
            <span style={{fontSize:14,fontWeight:700,color:"var(--green)"}}>Auto-reply saved!</span>
          </div>
        ) : (
          <button className="press" onClick={save} style={{width:"100%",height:52,
            background:"var(--accent)",border:"none",borderRadius:"var(--r-md)",
            color:"var(--bg-base)",fontSize:14,fontWeight:700,
            boxShadow:"0 6px 20px var(--accent-glow)",transition:"transform 0.1s",cursor:"pointer"}}>
            Save Auto-Reply
          </button>
        )}
      </div>
    </div>
  );
}
