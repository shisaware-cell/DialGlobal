// src/screens/SpamBlocker.jsx
import React, { useState } from "react";
import { Ic, Toggle } from "../components/UI";
import { useApp } from "../context/AppContext";

export default function SpamBlocker() {
  const { goBack, numbers, ghostMode, setGhostMode, dndNumbers, toggleDnd, spamEnabled, toggleSpam } = useApp();
  const [robocall, setRobocall]   = useState(true);
  const [unknown,  setUnknown]    = useState(false);
  const [international, setIntl]  = useState(false);

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{fontSize:18,fontWeight:700,color:"var(--text-primary)"}}>Privacy & Blocking</h2>
            <p style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>Spam blocking, DND & Ghost Mode</p>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"14px 16px"}}>
        {/* Ghost Mode */}
        <div style={{background:ghostMode?"#1A1714":"var(--bg-surface)",
          border:`1px solid ${ghostMode?"transparent":"var(--border)"}`,
          borderRadius:"var(--r-lg)",padding:"16px",marginBottom:20,
          transition:"background 0.3s",overflow:"hidden",position:"relative"}}>
          {ghostMode && <div style={{position:"absolute",inset:0,background:"linear-gradient(135deg,#1A1714,#2a2420)",opacity:0.95}}/>}
          <div style={{position:"relative",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
            <div>
              <div style={{fontSize:15,fontWeight:700,color:ghostMode?"white":"var(--text-primary)",
                display:"flex",alignItems:"center",gap:8}}>
                👻 Ghost Mode
                {ghostMode&&<span style={{fontSize:9,fontWeight:700,background:"rgba(255,255,255,0.15)",
                  color:"rgba(255,255,255,0.8)",padding:"2px 8px",borderRadius:99,letterSpacing:0.5}}>ACTIVE</span>}
              </div>
              <div style={{fontSize:11,color:ghostMode?"rgba(255,255,255,0.5)":"var(--text-muted)",marginTop:3,lineHeight:1.5}}>
                Silences all numbers, hides badges, and shows no activity
              </div>
            </div>
            <Toggle value={ghostMode} onChange={setGhostMode}/>
          </div>
        </div>

        {/* Spam blocking */}
        <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:8}}>SPAM BLOCKING</div>
        <div style={{background:"var(--bg-surface)",border:"1px solid var(--border)",borderRadius:"var(--r-lg)",overflow:"hidden",marginBottom:20}}>
          {[
            {label:"Robocall Blocker",    sublabel:"Block automated & spam calls",   value:robocall,      set:setRobocall},
            {label:"Unknown Numbers",     sublabel:"Block callers with no Caller ID", value:unknown,       set:setUnknown},
            {label:"International Block", sublabel:"Block all international numbers", value:international, set:setIntl},
          ].map((row,i,arr)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"13px 16px",
              borderBottom:i<arr.length-1?"1px solid var(--border)":"none"}}>
              <div style={{width:34,height:34,borderRadius:10,background:"var(--red-dim)",
                display:"flex",alignItems:"center",justifyContent:"center"}}>
                <Ic d="M18 6L6 18M6 6l12 12" size={15} color="var(--red)" sw={2}/>
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:13.5,fontWeight:500,color:"var(--text-primary)"}}>{row.label}</div>
                <div style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>{row.sublabel}</div>
              </div>
              <Toggle value={row.value} onChange={row.set}/>
            </div>
          ))}
        </div>

        {/* Per-number DND */}
        <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:8}}>DO NOT DISTURB — PER NUMBER</div>
        <div style={{background:"var(--bg-surface)",border:"1px solid var(--border)",borderRadius:"var(--r-lg)",overflow:"hidden",marginBottom:20}}>
          {numbers.map((num,i)=>(
            <div key={num.id} style={{display:"flex",alignItems:"center",gap:12,padding:"13px 16px",
              borderBottom:i<numbers.length-1?"1px solid var(--border)":"none"}}>
              <div style={{width:38,height:38,borderRadius:12,background:"var(--bg-raised)",
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>{num.flag}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:600,color:"var(--text-primary)",fontFamily:"var(--font-mono)"}}>{num.number}</div>
                <div style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>{num.country}</div>
              </div>
              <Toggle value={!!dndNumbers[num.id]} onChange={()=>toggleDnd(num.id)}/>
            </div>
          ))}
        </div>

        {/* Per-number spam */}
        <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:8}}>SPAM FILTER — PER NUMBER</div>
        <div style={{background:"var(--bg-surface)",border:"1px solid var(--border)",borderRadius:"var(--r-lg)",overflow:"hidden",marginBottom:20}}>
          {numbers.map((num,i)=>(
            <div key={num.id} style={{display:"flex",alignItems:"center",gap:12,padding:"13px 16px",
              borderBottom:i<numbers.length-1?"1px solid var(--border)":"none"}}>
              <div style={{width:38,height:38,borderRadius:12,background:"var(--bg-raised)",
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>{num.flag}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:600,color:"var(--text-primary)",fontFamily:"var(--font-mono)"}}>{num.number}</div>
              </div>
              <Toggle value={!!spamEnabled[num.id]} onChange={()=>toggleSpam(num.id)}/>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
