// src/screens/Credits.jsx
// Credit-based pay-as-you-go system inspired by 2ndLine paywall screenshot
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";

const PACKS = [
  { id:"c1", credits:500,   price:2.99,  bonus:null,         tag:null           },
  { id:"c2", credits:1000,  price:4.99,  bonus:"+100 free",  tag:"POPULAR"      },
  { id:"c3", credits:2500,  price:9.99,  bonus:"+500 free",  tag:"BEST VALUE"   },
  { id:"c4", credits:10000, price:29.99, bonus:"+2000 free", tag:"PRO"          },
];

const RATES = [
  { type:"SMS outbound",    credits:1,   icon:"💬" },
  { type:"SMS inbound",     credits:0,   icon:"💬", free:true },
  { type:"Call (per min)",  credits:2,   icon:"📞" },
  { type:"MMS (send)",      credits:3,   icon:"📷" },
  { type:"Voicemail transcription", credits:5, icon:"🎤" },
];

export default function Credits() {
  const { goBack, credits, addCredits } = useApp();
  const [selected,  setSelected]  = useState("c2");
  const [loading,   setLoading]   = useState(false);
  const [showRates, setShowRates] = useState(false);

  const pack = PACKS.find(p => p.id === selected);

  const purchase = () => {
    setLoading(true);
    // TODO: createCheckout(pack) from api.js → Stripe
    setTimeout(() => {
      addCredits(pack.credits + (pack.bonus ? parseInt(pack.bonus) : 0));
      setLoading(false);
    }, 1600);
  };

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{fontSize:18,fontWeight:700,color:"var(--text-primary)"}}>Credits</h2>
            <p style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>Pay-as-you-go for calls & messages</p>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"16px 16px"}}>
        {/* Current balance */}
        <div style={{background:"linear-gradient(135deg,var(--accent),#c87d10)",borderRadius:"var(--r-lg)",
          padding:"20px",marginBottom:20,textAlign:"center",
          boxShadow:"0 8px 28px var(--accent-glow)"}}>
          <div style={{fontSize:42,marginBottom:4}}>⭐</div>
          <div style={{fontSize:42,fontWeight:800,color:"var(--bg-base)",letterSpacing:"-1px",lineHeight:1}}>
            {credits.toLocaleString()}
          </div>
          <div style={{fontSize:13,color:"rgba(26,23,20,0.65)",marginTop:4,fontWeight:600}}>Available Credits</div>
        </div>

        {/* Pack selection */}
        <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:10}}>BUY CREDITS</div>
        {PACKS.map((pack,i)=>{
          const isSel = selected === pack.id;
          return (
            <div key={pack.id} onClick={()=>setSelected(pack.id)} className="fade-up" style={{
              display:"flex",alignItems:"center",padding:"14px 16px",
              borderRadius:"var(--r-md)",marginBottom:8,cursor:"pointer",
              border:`1.5px solid ${isSel?"var(--accent)":"var(--border)"}`,
              background:isSel?"var(--accent-dim)":"var(--bg-surface)",
              transition:"all 0.15s",animationDelay:`${i*0.05}s`,position:"relative",overflow:"hidden"}}>
              {pack.tag && (
                <div style={{position:"absolute",top:0,right:0,background:"var(--accent)",
                  padding:"3px 10px",borderRadius:"0 var(--r-md) 0 8px"}}>
                  <span style={{fontSize:8.5,fontWeight:700,letterSpacing:1,color:"var(--bg-base)"}}>{pack.tag}</span>
                </div>
              )}
              {/* Radio */}
              <div style={{width:20,height:20,borderRadius:"50%",flexShrink:0,marginRight:12,
                border:`2px solid ${isSel?"var(--accent)":"var(--border-strong)"}`,
                background:isSel?"var(--accent)":"transparent",
                display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s"}}>
                {isSel&&<div style={{width:7,height:7,borderRadius:"50%",background:"var(--bg-base)"}}/>}
              </div>
              <div style={{flex:1}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                  <span style={{fontSize:20,fontWeight:800,color:isSel?"var(--accent)":"var(--text-primary)",
                    fontFamily:"var(--font-mono)",letterSpacing:"-0.5px"}}>
                    {pack.credits.toLocaleString()}
                  </span>
                  <span style={{fontSize:12,color:"var(--text-secondary)"}}>credits</span>
                  {pack.bonus&&<span style={{fontSize:10,fontWeight:700,color:"var(--green)",
                    background:"var(--green-dim)",padding:"2px 7px",borderRadius:99}}>{pack.bonus}</span>}
                </div>
                <div style={{fontSize:11,color:"var(--text-muted)"}}>
                  ~{Math.round(pack.credits/2)} min calls · {pack.credits} SMS
                </div>
              </div>
              <div style={{textAlign:"right",flexShrink:0}}>
                <div style={{fontSize:18,fontWeight:700,color:isSel?"var(--accent)":"var(--text-primary)",
                  fontFamily:"var(--font-mono)"}}>${pack.price}</div>
              </div>
            </div>
          );
        })}

        {/* Rates */}
        <button onClick={()=>setShowRates(s=>!s)} style={{width:"100%",background:"none",border:"none",
          display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 0",cursor:"pointer"}}>
          <span style={{fontSize:12,color:"var(--text-muted)",fontWeight:600}}>View credit rates</span>
          <Ic d={showRates?"M18 15l-6-6-6 6":"M6 9l6 6 6-6"} size={14} color="var(--text-muted)" sw={2}/>
        </button>
        {showRates && (
          <div className="fade-up" style={{background:"var(--bg-surface)",border:"1px solid var(--border)",
            borderRadius:"var(--r-md)",overflow:"hidden",marginBottom:16}}>
            {RATES.map((r,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",padding:"10px 14px",
                borderBottom:i<RATES.length-1?"1px solid var(--border)":"none"}}>
                <span style={{fontSize:16,marginRight:10}}>{r.icon}</span>
                <span style={{flex:1,fontSize:12.5,color:"var(--text-secondary)"}}>{r.type}</span>
                {r.free ? (
                  <span style={{fontSize:11,fontWeight:700,color:"var(--green)",background:"var(--green-dim)",
                    padding:"2px 8px",borderRadius:99}}>FREE</span>
                ) : (
                  <span style={{fontSize:12,fontWeight:700,color:"var(--accent)",fontFamily:"var(--font-mono)"}}>
                    {r.credits} cr
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* CTA */}
      <div style={{background:"var(--bg-surface)",borderTop:"1px solid var(--border)",
        padding:"12px 18px 20px",flexShrink:0}}>
        <button className="press" onClick={purchase} disabled={loading} style={{width:"100%",height:52,
          background:loading?"var(--accent-dim)":"var(--accent)",border:"none",borderRadius:"var(--r-md)",
          color:loading?"var(--accent)":"var(--bg-base)",fontSize:14,fontWeight:700,
          display:"flex",alignItems:"center",justifyContent:"center",gap:10,
          boxShadow:loading?"none":"0 6px 22px var(--accent-glow)",transition:"transform 0.1s",cursor:"pointer"}}>
          {loading ? <><Spinner/>Processing…</> : `Buy ${pack?.credits.toLocaleString()} Credits — $${pack?.price} →`}
        </button>
        <div style={{textAlign:"center",marginTop:8,fontSize:11,color:"var(--text-muted)"}}>
          Credits never expire · Secure payment via Stripe
        </div>
      </div>
    </div>
  );
}
