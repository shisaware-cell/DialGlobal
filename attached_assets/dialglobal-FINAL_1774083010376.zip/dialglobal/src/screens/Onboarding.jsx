// src/screens/Onboarding.jsx
// Redesigned: airy light-blue gradient, big single-word titles, illustrated visuals
import React, { useState } from "react";
import { useApp } from "../context/AppContext";

const SLIDES = [
  {
    id: 0,
    word: "Global",
    sub: "Calls & texts from any part of the world",
    gradient: "linear-gradient(170deg, #D6EEFF 0%, #EBF5FF 40%, #F5F3EF 100%)",
    visual: () => (
      <div style={{position:"relative",width:280,height:280,margin:"0 auto",display:"flex",alignItems:"center",justifyContent:"center"}}>
        {/* Globe */}
        <div style={{width:180,height:180,borderRadius:"50%",background:"linear-gradient(135deg,#4A9BE8 0%,#2563EB 60%,#1e50c8 100%)",
          boxShadow:"0 20px 60px rgba(37,99,235,0.35)",position:"relative",overflow:"hidden"}}>
          {/* land masses */}
          <div style={{position:"absolute",top:"20%",left:"15%",width:"35%",height:"28%",borderRadius:"40% 60% 55% 45%",background:"#3ECF6A",opacity:0.85}}/>
          <div style={{position:"absolute",top:"38%",left:"55%",width:"30%",height:"35%",borderRadius:"50% 40% 60% 35%",background:"#3ECF6A",opacity:0.85}}/>
          <div style={{position:"absolute",top:"60%",left:"25%",width:"22%",height:"18%",borderRadius:"50%",background:"#3ECF6A",opacity:0.7}}/>
          <div style={{position:"absolute",inset:0,borderRadius:"50%",background:"radial-gradient(circle at 30% 25%,rgba(255,255,255,0.22) 0%,transparent 50%)"}}/>
        </div>
        {/* Floating elements */}
        {[
          {emoji:"🇺🇸",s:{top:10,left:20},  delay:"0s",  dur:"2.4s"},
          {emoji:"🇨🇦",s:{top:20,right:15}, delay:"0.5s",dur:"2.8s"},
          {emoji:"🇳🇱",s:{bottom:50,left:10},delay:"0.9s",dur:"2.2s"},
          {emoji:"🔔",  s:{bottom:20,right:30},delay:"0.3s",dur:"3s"},
          {emoji:"🚀",  s:{top:5,right:60}, delay:"0.7s",dur:"2.6s"},
        ].map((f,i)=>(
          <div key={i} style={{position:"absolute",...f.s,fontSize:28,
            animation:`float ${f.dur} ease-in-out infinite`,animationDelay:f.delay,
            filter:"drop-shadow(0 4px 8px rgba(0,0,0,0.15))"}}>{f.emoji}</div>
        ))}
      </div>
    ),
  },
  {
    id: 1,
    word: "Instant",
    sub: "Get numbers and make calls instantly",
    gradient: "linear-gradient(170deg, #E8F4FF 0%, #EDF9F3 40%, #F5F3EF 100%)",
    visual: () => (
      <div style={{position:"relative",width:280,height:280,margin:"0 auto",display:"flex",alignItems:"center",justifyContent:"center"}}>
        {/* Phone mockup */}
        <div style={{width:160,height:220,background:"#1A1714",borderRadius:24,boxShadow:"0 20px 50px rgba(0,0,0,0.25)",
          overflow:"hidden",display:"flex",flexDirection:"column"}}>
          <div style={{height:32,background:"var(--accent)",display:"flex",alignItems:"center",justifyContent:"center"}}>
            <span style={{fontSize:10,fontWeight:700,color:"#1A1714",letterSpacing:1.5}}>SELECT COUNTRY</span>
          </div>
          <div style={{padding:"8px 10px",flex:1,background:"white"}}>
            <div style={{height:28,background:"#F0EDE8",borderRadius:8,display:"flex",alignItems:"center",paddingLeft:8,gap:6,marginBottom:8}}>
              <span style={{fontSize:10}}>🔍</span>
              <span style={{fontSize:10,color:"#A09890"}}>Search country…</span>
            </div>
            {[{flag:"🇺🇸",name:"United States"},{flag:"🇨🇦",name:"Canada"},{flag:"🇬🇧",name:"UK"}].map((c,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:7,padding:"7px 4px",
                borderBottom:i<2?"1px solid #F0EDE8":"none"}}>
                <span style={{fontSize:16}}>{c.flag}</span>
                <div style={{flex:1}}>
                  <div style={{fontSize:9.5,fontWeight:700,color:"#1A1714"}}>{c.name}</div>
                  <div style={{fontSize:8,color:"#A09890",marginTop:1}}>📞 Calls · 💬 SMS</div>
                </div>
                <span style={{fontSize:10,color:"#A09890"}}>›</span>
              </div>
            ))}
          </div>
        </div>
        {/* Number cards floating */}
        {[
          {num:"+1 321 984-2856",top:30,left:-20},
          {num:"+1 337 753-2495",bottom:40,left:-10},
        ].map((c,i)=>(
          <div key={i} style={{position:"absolute",top:c.top,bottom:c.bottom,left:c.left,
            background:"white",borderRadius:12,padding:"8px 14px",
            boxShadow:"0 8px 24px rgba(0,0,0,0.12)",whiteSpace:"nowrap",
            animation:`float ${2.2+i*0.4}s ease-in-out infinite`,animationDelay:`${i*0.4}s`}}>
            <span style={{fontSize:13,fontWeight:700,color:"#1A1714"}}>{c.num}</span>
          </div>
        ))}
        <div style={{position:"absolute",top:20,right:-10,fontSize:28,
          animation:"float 2s ease-in-out infinite",animationDelay:"0.6s",
          filter:"drop-shadow(0 4px 8px rgba(0,0,0,0.15))"}}>👆</div>
      </div>
    ),
  },
  {
    id: 2,
    word: "Private",
    sub: "Keep your real number completely hidden",
    gradient: "linear-gradient(170deg, #FFF8EC 0%, #FFF3E0 40%, #F5F3EF 100%)",
    visual: () => (
      <div style={{position:"relative",width:280,height:280,margin:"0 auto",display:"flex",alignItems:"center",justifyContent:"center"}}>
        <div style={{width:160,height:160,borderRadius:"50%",
          background:"linear-gradient(135deg,#FDE9C0,#E8A020)",
          boxShadow:"0 16px 48px rgba(232,160,32,0.35)",
          display:"flex",alignItems:"center",justifyContent:"center",fontSize:72}}>
          👑
        </div>
        {[
          {txt:"🔒 Encrypted",  c:"var(--accent)",  s:{top:20,left:10}},
          {txt:"✓ Verified",    c:"var(--green)",   s:{top:60,right:-5}},
          {txt:"🚫 No spam",    c:"var(--red)",     s:{bottom:50,left:0}},
          {txt:"👁 Private",    c:"var(--blue)",    s:{bottom:20,right:15}},
        ].map((b,i)=>(
          <div key={i} style={{position:"absolute",...b.s,background:"white",
            borderRadius:20,padding:"6px 12px",fontSize:11,fontWeight:700,color:b.c,
            boxShadow:"0 4px 14px rgba(0,0,0,0.1)",whiteSpace:"nowrap",
            animation:`float ${2+i*0.3}s ease-in-out infinite`,animationDelay:`${i*0.25}s`}}>{b.txt}</div>
        ))}
      </div>
    ),
  },
];

export default function Onboarding() {
  const { navigate } = useApp();
  const [step, setStep] = useState(0);
  const sl = SLIDES[step];
  const Visual = sl.visual;

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",background:sl.gradient,transition:"background 0.6s ease"}}>
      {/* Status bar area */}
      <div style={{height:44,flexShrink:0}}/>

      {/* Skip */}
      <div style={{display:"flex",justifyContent:"flex-end",padding:"0 22px 0"}}>
        {step < SLIDES.length - 1 && (
          <button onClick={() => navigate("auth")} style={{background:"none",border:"none",
            fontSize:13,color:"rgba(26,23,20,0.45)",fontWeight:500,cursor:"pointer"}}>Skip</button>
        )}
      </div>

      {/* Visual */}
      <div key={`v${step}`} className="fade-up" style={{flex:1,display:"flex",alignItems:"center",
        justifyContent:"center",padding:"10px 20px"}}>
        <Visual/>
      </div>

      {/* Bottom content */}
      <div style={{background:"white",borderRadius:"32px 32px 0 0",
        padding:"28px 28px 40px",boxShadow:"0 -8px 32px rgba(0,0,0,0.06)"}}>
        <div key={`c${step}`} className="fade-up">
          {/* Big single word */}
          <h1 style={{fontSize:42,fontWeight:800,color:"#1A1714",letterSpacing:"-1px",
            marginBottom:8,lineHeight:1}}>{sl.word}</h1>
          <p style={{fontSize:15,color:"rgba(26,23,20,0.5)",lineHeight:1.55,marginBottom:28}}>{sl.sub}</p>
        </div>

        {/* Progress dots */}
        <div style={{display:"flex",gap:6,marginBottom:22,alignItems:"center"}}>
          {SLIDES.map((_,i)=>(
            <div key={i} style={{height:4,borderRadius:99,
              background:i===step?"var(--accent)":"rgba(26,23,20,0.12)",
              width:i===step?28:8,transition:"all 0.35s ease"}}/>
          ))}
        </div>

        <button className="press" onClick={() => step < SLIDES.length-1 ? setStep(s=>s+1) : navigate("auth")}
          style={{width:"100%",height:56,background:"var(--accent)",border:"none",
            borderRadius:28,color:"var(--bg-base)",fontSize:16,fontWeight:700,
            boxShadow:"0 8px 28px var(--accent-glow)",transition:"transform 0.1s",cursor:"pointer"}}>
          Continue
        </button>

        {step === 0 && (
          <button onClick={() => navigate("auth")} style={{width:"100%",height:44,background:"none",
            border:"none",color:"rgba(26,23,20,0.4)",fontSize:13,marginTop:6,cursor:"pointer"}}>
            Already have an account · Log in
          </button>
        )}
      </div>
    </div>
  );
}
