// src/screens/ESim.jsx
import React, { useState } from "react";
import { Ic, Spinner } from "../components/UI";
import { useApp } from "../context/AppContext";

const ESIM_PLANS = [
  { id:"e1", region:"🌍 Africa & Middle East", data:"1 GB", days:7,  price:4.99 },
  { id:"e2", region:"🌎 Americas",             data:"3 GB", days:14, price:8.99 },
  { id:"e3", region:"🌏 Asia Pacific",         data:"2 GB", days:10, price:6.99 },
  { id:"e4", region:"🌍 Europe",               data:"5 GB", days:30, price:14.99 },
  { id:"e5", region:"🌐 Global (160 countries)",data:"2 GB",days:15, price:19.99 },
];

export default function ESim() {
  const { goBack, navigate } = useApp();
  const [mode, setMode]       = useState("plans"); // "plans" | "scan" | "manual" | "done"
  const [selected, setSelected] = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [qrInput,  setQrInput]  = useState("");

  const activate = () => {
    setLoading(true);
    // TODO: call backend eSIM provisioning API
    setTimeout(() => { setLoading(false); setMode("done"); }, 2200);
  };

  if (mode === "done") return (
    <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
      justifyContent:"center",background:"var(--bg-base)",padding:"0 32px"}}>
      <div style={{fontSize:64,marginBottom:16,animation:"pop 0.5s ease"}}>📶</div>
      <h2 style={{fontSize:24,fontWeight:700,color:"var(--text-primary)",textAlign:"center",marginBottom:8,letterSpacing:"-0.5px"}}>eSIM Activated!</h2>
      <p style={{fontSize:13,color:"var(--text-secondary)",textAlign:"center",lineHeight:1.7,marginBottom:28}}>
        Your eSIM is ready. You can now make calls and use data with your virtual number while travelling.
      </p>
      <div style={{background:"var(--bg-surface)",border:"1px solid var(--border-strong)",borderRadius:"var(--r-lg)",
        padding:"16px 20px",marginBottom:28,width:"100%",textAlign:"center"}}>
        <div style={{fontSize:13,color:"var(--text-muted)",marginBottom:4}}>Active eSIM Plan</div>
        <div style={{fontSize:16,fontWeight:700,color:"var(--text-primary)"}}>{selected?.region}</div>
        <div style={{fontSize:12,color:"var(--text-secondary)",marginTop:4}}>{selected?.data} · {selected?.days} days</div>
        <div style={{display:"inline-flex",alignItems:"center",gap:6,background:"var(--green-dim)",borderRadius:99,padding:"4px 12px",marginTop:10}}>
          <div style={{width:6,height:6,borderRadius:"50%",background:"var(--green)",animation:"pulse 1.5s ease infinite"}}/>
          <span style={{fontSize:11,fontWeight:700,color:"var(--green)"}}>Active</span>
        </div>
      </div>
      <button className="press" onClick={() => navigate("home")} style={{width:"100%",height:52,
        background:"var(--accent)",border:"none",borderRadius:"var(--r-md)",color:"var(--bg-base)",
        fontSize:15,fontWeight:700,boxShadow:"0 6px 20px var(--accent-glow)",transition:"transform 0.1s",cursor:"pointer"}}>
        Done
      </button>
    </div>
  );

  if (mode === "scan" || mode === "manual") return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <button onClick={()=>setMode("plans")} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <h2 style={{fontSize:18,fontWeight:700,color:"var(--text-primary)"}}>
            {mode==="scan"?"Scan QR Code":"Enter Activation Code"}
          </h2>
        </div>
      </div>
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",padding:"32px 24px"}}>
        {mode==="scan" ? (
          <>
            <div style={{width:220,height:220,background:"var(--bg-raised)",border:"2px dashed var(--border-strong)",
              borderRadius:16,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
              marginBottom:24,gap:12}}>
              <div style={{fontSize:48}}>📷</div>
              <div style={{fontSize:13,color:"var(--text-muted)",textAlign:"center"}}>Camera permission required</div>
            </div>
            <div style={{fontSize:13,color:"var(--text-secondary)",textAlign:"center",marginBottom:24,lineHeight:1.6}}>
              Point your camera at the QR code provided by your eSIM carrier to activate instantly.
            </div>
            <button onClick={()=>setMode("manual")} style={{fontSize:13,color:"var(--accent)",fontWeight:600,
              background:"none",border:"none",cursor:"pointer"}}>
              Enter code manually instead →
            </button>
          </>
        ) : (
          <>
            <div style={{fontSize:48,marginBottom:16}}>🔢</div>
            <div style={{fontSize:13,color:"var(--text-secondary)",textAlign:"center",marginBottom:20,lineHeight:1.6}}>
              Enter the activation code from your eSIM QR code
            </div>
            <input value={qrInput} onChange={e=>setQrInput(e.target.value)}
              placeholder="LPA:1$example.server.com$ABCDEF123456"
              style={{width:"100%",height:48,borderRadius:"var(--r-md)",border:"1.5px solid var(--border)",
                background:"var(--bg-input)",padding:"0 14px",fontSize:12,color:"var(--text-primary)",
                outline:"none",fontFamily:"var(--font-mono)",marginBottom:16}}/>
            <button className="press" onClick={activate} disabled={loading||!qrInput.trim()}
              style={{width:"100%",height:52,background:qrInput.trim()?"var(--accent)":"var(--bg-raised)",
                border:"none",borderRadius:"var(--r-md)",
                color:qrInput.trim()?"var(--bg-base)":"var(--text-muted)",
                fontSize:14,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",gap:10,
                boxShadow:qrInput.trim()?"0 6px 20px var(--accent-glow)":"none",transition:"transform 0.1s",cursor:"pointer"}}>
              {loading?<><Spinner/>Activating…</>:"Activate eSIM →"}
            </button>
          </>
        )}
      </div>
    </div>
  );

  // Plans list
  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 16px",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{fontSize:18,fontWeight:700,color:"var(--text-primary)",letterSpacing:"-0.3px"}}>eSIM</h2>
            <p style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>Stay connected while travelling</p>
          </div>
        </div>
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"14px 16px"}}>
        {/* Already have eSIM */}
        <div style={{background:"var(--bg-surface)",border:"1px solid var(--border)",borderRadius:"var(--r-lg)",
          padding:"14px 16px",marginBottom:16,display:"flex",alignItems:"center",gap:12,cursor:"pointer"}}
          onClick={() => setMode("scan")}>
          <div style={{width:40,height:40,borderRadius:12,background:"var(--accent-dim)",
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>📲</div>
          <div style={{flex:1}}>
            <div style={{fontSize:13.5,fontWeight:600,color:"var(--text-primary)"}}>Activate existing eSIM</div>
            <div style={{fontSize:11,color:"var(--text-muted)",marginTop:2}}>Scan QR code or enter activation code</div>
          </div>
          <Ic d="M9 18l6-6-6-6" size={14} color="var(--text-muted)" sw={2}/>
        </div>

        <div style={{fontSize:10,fontWeight:700,color:"var(--text-muted)",letterSpacing:1.4,marginBottom:10}}>BUY A NEW eSIM</div>

        {ESIM_PLANS.map((plan,i)=>(
          <div key={plan.id} onClick={()=>setSelected(plan)} className="fade-up" style={{
            background:selected?.id===plan.id?"var(--accent-dim)":"var(--bg-surface)",
            border:`1.5px solid ${selected?.id===plan.id?"rgba(232,160,32,0.4)":"var(--border)"}`,
            borderRadius:"var(--r-md)",padding:"13px 14px",marginBottom:8,cursor:"pointer",
            transition:"all 0.15s",animationDelay:`${i*0.05}s`,display:"flex",alignItems:"center",gap:12}}>
            <div style={{flex:1}}>
              <div style={{fontSize:13.5,fontWeight:600,color:"var(--text-primary)"}}>{plan.region}</div>
              <div style={{fontSize:11,color:"var(--text-secondary)",marginTop:3,display:"flex",gap:10}}>
                <span>📦 {plan.data}</span><span>📅 {plan.days} days</span>
              </div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:16,fontWeight:700,color:selected?.id===plan.id?"var(--accent)":"var(--text-primary)",
                fontFamily:"var(--font-mono)"}}>${plan.price}</div>
              {selected?.id===plan.id&&<div style={{width:16,height:16,borderRadius:"50%",background:"var(--accent)",
                display:"flex",alignItems:"center",justifyContent:"center",marginLeft:"auto",marginTop:4}}>
                <Ic d="M20 6L9 17l-5-5" size={9} color="var(--bg-base)" sw={3}/>
              </div>}
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="slide-up" style={{background:"var(--bg-surface)",borderTop:"1px solid var(--border)",
          padding:"14px 18px 20px",flexShrink:0}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:12,
            padding:"10px 12px",background:"var(--bg-raised)",borderRadius:"var(--r-sm)"}}>
            <div>
              <div style={{fontSize:13,fontWeight:600,color:"var(--text-primary)"}}>{selected.region}</div>
              <div style={{fontSize:11,color:"var(--text-muted)"}}>{selected.data} · {selected.days} days</div>
            </div>
            <div style={{fontSize:18,fontWeight:700,color:"var(--accent)",fontFamily:"var(--font-mono)"}}>${selected.price}</div>
          </div>
          <button className="press" onClick={activate} disabled={loading} style={{width:"100%",height:52,
            background:loading?"var(--accent-dim)":"var(--accent)",border:"none",borderRadius:"var(--r-md)",
            color:loading?"var(--accent)":"var(--bg-base)",fontSize:14,fontWeight:700,
            display:"flex",alignItems:"center",justifyContent:"center",gap:10,
            boxShadow:loading?"none":"0 6px 20px var(--accent-glow)",transition:"transform 0.1s",cursor:"pointer"}}>
            {loading?<><Spinner/>Activating eSIM…</>:"Buy & Activate eSIM →"}
          </button>
        </div>
      )}
    </div>
  );
}
