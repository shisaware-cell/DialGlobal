// src/screens/Calls.jsx
import React, { useState } from "react";
import { Ic } from "../components/UI";
import { MOCK_CALLS } from "../data/mockData";

const TYPES = {
  missed:   {bg:"var(--red-dim)",  c:"var(--red)",  l:"Missed"},
  incoming: {bg:"var(--green-dim)",c:"var(--green)", l:"Incoming"},
  outgoing: {bg:"var(--blue-dim)", c:"var(--blue)",  l:"Outgoing"},
  voicemail:{bg:"var(--bg-raised)",c:"var(--text-secondary)",l:"Voicemail"},
};

export default function Calls() {
  const [filter, setFilter] = useState("all");
  const list = filter === "all" ? MOCK_CALLS : MOCK_CALLS.filter(c => c.type === filter);

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 20px 0",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <h2 style={{fontSize:20,fontWeight:700,color:"var(--text-primary)",margin:"0 0 14px",letterSpacing:"-0.4px"}}>Calls</h2>
        <div style={{display:"flex",gap:7,paddingBottom:13,overflowX:"auto"}}>
          {[{id:"all",l:"All"},{id:"missed",l:"Missed"},{id:"incoming",l:"Incoming"},{id:"outgoing",l:"Outgoing"},{id:"voicemail",l:"Voicemail"}].map(f=>(
            <button key={f.id} onClick={()=>setFilter(f.id)} style={{flexShrink:0,height:28,padding:"0 12px",borderRadius:99,
              border:`1.5px solid ${filter===f.id?"var(--accent)":"var(--border)"}`,
              background:filter===f.id?"var(--accent-dim)":"transparent",
              color:filter===f.id?"var(--accent)":"var(--text-muted)",
              fontSize:11.5,fontWeight:600,transition:"all 0.15s",cursor:"pointer"}}>{f.l}</button>
          ))}
        </div>
      </div>
      <div style={{flex:1,overflowY:"auto"}}>
        {list.length === 0 && <div style={{textAlign:"center",padding:"40px 0",color:"var(--text-muted)",fontSize:13}}>No calls found</div>}
        {list.map(cl=>{
          const cv = TYPES[cl.type] || TYPES.outgoing;
          return (
            <div key={cl.id} className="row-hover" style={{display:"flex",alignItems:"center",padding:"13px 18px",
              gap:11,borderBottom:"1px solid var(--border)",background:"var(--bg-base)",transition:"background 0.12s",cursor:"pointer"}}>
              <div style={{width:46,height:46,borderRadius:"var(--r-md)",background:cv.bg,
                display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:18}}>{cl.flag}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:13.5,fontWeight:600,color:cl.type==="missed"?"var(--red)":"var(--text-primary)",marginBottom:3}}>{cl.name}</div>
                <div style={{fontSize:11.5,color:"var(--text-muted)",display:"flex",alignItems:"center",gap:5,fontFamily:"var(--font-mono)"}}>
                  <span>{cl.number}</span>{cl.duration&&<><span>·</span><span>{cl.duration}</span></>}
                </div>
              </div>
              <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:5}}>
                <span style={{fontSize:11,color:"var(--text-muted)"}}>{cl.time}</span>
                <span style={{fontSize:9,fontWeight:700,padding:"2px 8px",borderRadius:99,background:cv.bg,color:cv.c}}>{cv.l}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
