// src/screens/Contacts.jsx
import React, { useState } from "react";
import { Ic } from "../components/UI";
import { useApp } from "../context/AppContext";

const SAMPLE_CONTACTS = [
  {name:"Alice Johnson",   phone:"+1 415 555 0101", initials:"AJ"},
  {name:"Bob Nakamura",    phone:"+1 212 555 0172", initials:"BN"},
  {name:"Chidi Okeke",     phone:"+27 82 123 4567", initials:"CO"},
  {name:"Diana Ferreira",  phone:"+44 7911 123456", initials:"DF"},
  {name:"Ethan Goldberg",  phone:"+1 310 555 0198", initials:"EG"},
  {name:"Fatima Al-Hassan",phone:"+971 50 123 4567",initials:"FA"},
  {name:"Grace Thompson",  phone:"+61 4 1234 5678", initials:"GT"},
  {name:"Hassan Malik",    phone:"+92 300 1234567", initials:"HM"},
];

const COLORS = ["#E8A020","#16A34A","#2563EB","#DC2626","#7C3AED","#0891B2"];

export default function Contacts() {
  const { goBack, contacts, importContacts } = useApp();
  const [search, setSearch]     = useState("");
  const [selected, setSelected] = useState(new Set());
  const [imported, setImported] = useState(false);
  const [mode, setMode]         = useState("list"); // "list" | "csv"

  const all = [...SAMPLE_CONTACTS, ...contacts].filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) || c.phone.includes(search)
  );

  const toggle = (phone) => {
    setSelected(prev => {
      const n = new Set(prev);
      n.has(phone) ? n.delete(phone) : n.add(phone);
      return n;
    });
  };

  const doImport = () => {
    const toAdd = SAMPLE_CONTACTS.filter(c => selected.has(c.phone));
    importContacts(toAdd);
    setImported(true);
    setTimeout(() => { setImported(false); setSelected(new Set()); }, 2000);
  };

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column",background:"var(--bg-base)",overflow:"hidden"}}>
      <div style={{background:"var(--bg-surface)",padding:"10px 18px 0",borderBottom:"1px solid var(--border)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
          <button onClick={goBack} style={{background:"none",border:"none",display:"flex",padding:4,cursor:"pointer"}}>
            <Ic d="M15 18l-6-6 6-6" size={20} color="var(--text-primary)" sw={2.2}/>
          </button>
          <div>
            <h2 style={{fontSize:18,fontWeight:700,color:"var(--text-primary)",letterSpacing:"-0.3px"}}>Import Contacts</h2>
            <p style={{fontSize:11,color:"var(--text-muted)",marginTop:1}}>Sync your contacts with DialGlobal</p>
          </div>
        </div>

        {/* Mode toggle */}
        <div style={{display:"flex",gap:7,paddingBottom:13}}>
          {[{id:"list",l:"📱 Phone Contacts"},{id:"csv",l:"📄 Import CSV"}].map(m=>(
            <button key={m.id} onClick={()=>setMode(m.id)} style={{flexShrink:0,height:28,padding:"0 12px",borderRadius:99,
              border:`1.5px solid ${mode===m.id?"var(--accent)":"var(--border)"}`,
              background:mode===m.id?"var(--accent-dim)":"transparent",
              color:mode===m.id?"var(--accent)":"var(--text-muted)",
              fontSize:11.5,fontWeight:600,transition:"all 0.15s",cursor:"pointer"}}>{m.l}</button>
          ))}
        </div>
      </div>

      {mode === "csv" ? (
        <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",
          justifyContent:"center",padding:"32px 24px",gap:16}}>
          <div style={{fontSize:56}}>📄</div>
          <div style={{fontSize:16,fontWeight:700,color:"var(--text-primary)",textAlign:"center"}}>Upload a CSV file</div>
          <div style={{fontSize:13,color:"var(--text-secondary)",textAlign:"center",lineHeight:1.6}}>
            Format: <span style={{fontFamily:"var(--font-mono)",fontSize:11}}>Name, Phone</span> — one contact per row
          </div>
          <div style={{width:"100%",height:120,background:"var(--bg-surface)",border:"2px dashed var(--border-strong)",
            borderRadius:"var(--r-lg)",display:"flex",flexDirection:"column",alignItems:"center",
            justifyContent:"center",gap:8,cursor:"pointer"}}
            onDragOver={e=>e.preventDefault()}>
            <Ic d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12" size={28} color="var(--accent)" sw={1.8}/>
            <div style={{fontSize:12,color:"var(--text-muted)"}}>Drag & drop or tap to browse</div>
          </div>
          <div style={{fontSize:11,color:"var(--text-muted)"}}>Supported: .csv, .vcf</div>
        </div>
      ) : (
        <>
          {/* Search */}
          <div style={{padding:"10px 16px 6px",background:"var(--bg-base)",flexShrink:0}}>
            <div style={{position:"relative"}}>
              <Ic d="M21 21l-4.35-4.35M17 11A6 6 0 115 11a6 6 0 0112 0z" size={14} color="var(--text-muted)"
                style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",pointerEvents:"none"}}/>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search contacts…"
                style={{width:"100%",height:38,borderRadius:"var(--r-md)",border:"1.5px solid var(--border)",
                  background:"var(--bg-surface)",paddingLeft:34,paddingRight:12,fontSize:13,
                  color:"var(--text-primary)",outline:"none"}}/>
            </div>
          </div>

          {/* Select all */}
          <div style={{padding:"6px 20px",background:"var(--bg-base)",display:"flex",alignItems:"center",
            justifyContent:"space-between",flexShrink:0}}>
            <span style={{fontSize:11,color:"var(--text-muted)",fontWeight:600,letterSpacing:0.5}}>
              {all.length} CONTACTS
            </span>
            <button onClick={()=>selected.size===all.length?setSelected(new Set()):setSelected(new Set(all.map(c=>c.phone)))}
              style={{fontSize:11,fontWeight:600,color:"var(--accent)",background:"none",border:"none",cursor:"pointer"}}>
              {selected.size===all.length?"Deselect all":"Select all"}
            </button>
          </div>

          <div style={{flex:1,overflowY:"auto",background:"var(--bg-surface)"}}>
            {all.map((c,i)=>{
              const isSel = selected.has(c.phone);
              const color = COLORS[i % COLORS.length];
              return (
                <div key={c.phone} onClick={()=>toggle(c.phone)} className="row-hover"
                  style={{display:"flex",alignItems:"center",gap:12,padding:"11px 18px",
                    borderBottom:"1px solid var(--border)",cursor:"pointer",
                    background:isSel?"var(--accent-dim)":"white",transition:"background 0.12s"}}>
                  <div style={{width:38,height:38,borderRadius:12,background:color+"22",
                    display:"flex",alignItems:"center",justifyContent:"center",
                    fontSize:13,fontWeight:700,color,flexShrink:0}}>{c.initials}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13.5,fontWeight:600,color:"var(--text-primary)"}}>{c.name}</div>
                    <div style={{fontSize:11,color:"var(--text-muted)",fontFamily:"var(--font-mono)",marginTop:2}}>{c.phone}</div>
                  </div>
                  <div style={{width:20,height:20,borderRadius:"50%",
                    border:`2px solid ${isSel?"var(--accent)":"var(--border-strong)"}`,
                    background:isSel?"var(--accent)":"transparent",
                    display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s",flexShrink:0}}>
                    {isSel&&<Ic d="M20 6L9 17l-5-5" size={11} color="var(--bg-base)" sw={2.5}/>}
                  </div>
                </div>
              );
            })}
          </div>

          {(selected.size > 0 || imported) && (
            <div className="slide-up" style={{background:"var(--bg-surface)",borderTop:"1px solid var(--border)",
              padding:"14px 18px 20px",flexShrink:0}}>
              {imported ? (
                <div className="fade-in" style={{display:"flex",alignItems:"center",justifyContent:"center",gap:8,
                  height:52,background:"var(--green-dim)",borderRadius:"var(--r-md)"}}>
                  <Ic d="M20 6L9 17l-5-5" size={16} color="var(--green)" sw={2.5}/>
                  <span style={{fontSize:14,fontWeight:700,color:"var(--green)"}}>Contacts imported!</span>
                </div>
              ) : (
                <button className="press" onClick={doImport} style={{width:"100%",height:52,
                  background:"var(--accent)",border:"none",borderRadius:"var(--r-md)",
                  color:"var(--bg-base)",fontSize:14,fontWeight:700,
                  boxShadow:"0 6px 20px var(--accent-glow)",transition:"transform 0.1s",cursor:"pointer"}}>
                  Import {selected.size} Contact{selected.size!==1?"s":""}  →
                </button>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
