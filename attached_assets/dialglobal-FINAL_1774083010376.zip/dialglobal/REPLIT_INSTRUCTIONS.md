# DialGlobal — Replit Setup & Telnyx Integration Guide

## 1. Upload this project to Replit

1. Create a new Replit → **Import from ZIP**
2. Upload `dialglobal.zip`
3. Replit will detect it as a React app (Create React App)
4. Open the Shell and run: `npm install`
5. Click **Run** — the app starts on port 3000

---

## 2. Environment Variables (Replit Secrets)

In Replit, go to **Tools → Secrets** and add:

```
REACT_APP_API_BASE_URL = https://your-backend.railway.app/api
```

> **Note:** Never put Telnyx keys in the React app. They must only live in your backend.

---

## 3. Backend Setup (Node/Express)

Create a separate Replit (or use Railway/Render) for your backend:

```bash
npm init -y
npm install express telnyx cors dotenv stripe
```

### Backend `.env`:
```
TELNYX_API_KEY=KEY01234_your_real_key_here
TELNYX_CONNECTION_ID=your_call_control_connection_id
TELNYX_MESSAGING_PROFILE_ID=your_messaging_profile_id
STRIPE_SECRET_KEY=sk_test_your_stripe_key
PORT=3001
```

### Telnyx Setup Steps:
1. Sign up at **https://telnyx.com** (includes free trial credit)
2. **API Keys** → Dashboard → API Keys → Create key → paste above
3. **Numbers** → Search & Buy numbers → assign to Messaging Profile
4. **Voice** → Call Control → Create connection → paste Connection ID
5. **Webhooks** → set your backend URL for inbound SMS/calls:
   - `https://your-backend.com/webhooks/telnyx`

---

## 4. Backend Routes (implement these in Express)

The React app calls these endpoints via `src/services/api.js`:

### Numbers
```js
GET  /api/numbers                        // telnyx.phoneNumbers.list()
GET  /api/numbers/search?country=US      // telnyx.availablePhoneNumbers.list()
POST /api/numbers/provision              // telnyx.phoneNumbers.create()
DELETE /api/numbers/:id                  // telnyx.phoneNumbers.delete()
```

### Messages
```js
GET  /api/numbers/:id/threads            // telnyx.messages.list()
POST /api/messages/send                  // telnyx.messages.create({ from, to, text })
```

### Calls (Telnyx Call Control)
```js
GET  /api/numbers/:id/calls              // telnyx.calls.list()
POST /api/calls/initiate                 // telnyx.calls.create({ connection_id, from, to })
POST /api/calls/hangup                   // telnyx.calls.hangup({ call_control_id })
```

### Webhooks (inbound calls & SMS)
```js
POST /webhooks/telnyx
// Telnyx sends events here:
// - call.initiated, call.answered, call.hangup
// - message.received
// Verify with telnyx-node SDK webhook signature validation
```

### Auth
```js
POST /api/auth/login                     // verify credentials, return JWT
POST /api/auth/signup                    // create user, return JWT
POST /api/auth/logout
```

### Billing (Stripe)
```js
POST /api/billing/checkout              // stripe.checkout.sessions.create()
POST /api/billing/cancel                // stripe.subscriptions.cancel()
POST /webhooks/stripe                   // handle payment events
```

### eSIM
```js
POST /api/esim/activate                 // Forward to eSIM provider (e.g., eSIM Access, Airalo API)
GET  /api/esim/plans                    // Return available eSIM plans
```

---

## 5. Minimal Express Server Starter

```js
// server.js
require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const Telnyx  = require('telnyx')(process.env.TELNYX_API_KEY);

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());

// ── Numbers ──────────────────────────────────────────────
app.get('/api/numbers', async (req, res) => {
  try {
    const { data } = await Telnyx.phoneNumbers.list();
    res.json(data);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

app.post('/api/numbers/provision', async (req, res) => {
  const { phone, plan } = req.body;
  try {
    const { data } = await Telnyx.phoneNumbers.create({
      phone_number: phone,
      messaging_profile_id: process.env.TELNYX_MESSAGING_PROFILE_ID,
      connection_id: process.env.TELNYX_CONNECTION_ID,
    });
    res.json(data);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── Messages ─────────────────────────────────────────────
app.post('/api/messages/send', async (req, res) => {
  const { from, to, text } = req.body;
  try {
    const { data } = await Telnyx.messages.create({
      from, to,
      text,
      messaging_profile_id: process.env.TELNYX_MESSAGING_PROFILE_ID,
    });
    res.json(data);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── Calls ─────────────────────────────────────────────────
app.post('/api/calls/initiate', async (req, res) => {
  const { from, to } = req.body;
  try {
    const { data } = await Telnyx.calls.create({
      connection_id: process.env.TELNYX_CONNECTION_ID,
      from, to,
    });
    res.json(data);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── Telnyx Webhooks ───────────────────────────────────────
app.post('/webhooks/telnyx', (req, res) => {
  const event = req.body.data;
  console.log('Telnyx event:', event.event_type, event.payload);
  // Handle: call.initiated, call.answered, message.received, etc.
  res.sendStatus(200);
});

app.listen(process.env.PORT || 3001, () =>
  console.log(`DialGlobal backend running on port ${process.env.PORT || 3001}`)
);
```

---

## 6. Screens & Features Reference

| Screen       | File                    | Description                          |
|---|---|---|
| Onboarding   | screens/Onboarding.jsx  | 3-slide animated intro               |
| Login/Signup | screens/Auth.jsx        | Email + social auth                  |
| Dashboard    | screens/Dashboard.jsx   | Numbers list, ghost mode, plan banner|
| Get Number   | screens/Picker.jsx      | Country picker, plan gating          |
| Pricing      | screens/Paywall.jsx     | 3 plans + credits, Stripe            |
| Credits      | screens/Credits.jsx     | Pay-as-you-go credit packs           |
| Inbox        | screens/Inbox.jsx       | Messages + chat view                 |
| Calls        | screens/Calls.jsx       | Call log with filters                |
| eSIM         | screens/ESim.jsx        | Buy/activate eSIM for travel         |
| Contacts     | screens/Contacts.jsx    | Import phone contacts or CSV         |
| Auto-Reply   | screens/AutoReply.jsx   | Per-number away messages             |
| Spam Blocker | screens/SpamBlocker.jsx | Robocall blocking, DND, Ghost Mode   |
| Number Detail| screens/NumberDetail.jsx| Per-number settings & activity       |
| Profile      | screens/Profile.jsx     | Edit info, plan, sign out            |
| Settings     | screens/Settings.jsx    | All feature toggles, navigation hub  |

---

## 7. Committing to GitHub from Replit

1. In Replit → **Version Control** (Git icon in sidebar)
2. Click **Connect to GitHub**
3. Authorize and create a new repository: `dialglobal`
4. Make your first commit: "Initial UI + Telnyx integration scaffold"
5. Push to main

---

## 8. Deployment Recommendations

| Service  | Use for           | Free tier? |
|---|---|---|
| Replit   | Frontend (React)  | Yes        |
| Railway  | Backend (Express) | Yes ($5 credit/mo) |
| Telnyx   | Numbers/SMS/Voice | Yes (trial credit) |
| Stripe   | Payments          | Yes (test mode) |
| Airalo   | eSIM data plans   | No (pay per plan)  |

---

## 9. Production Checklist

- [ ] Move all API keys to environment variables
- [ ] Enable HTTPS on backend
- [ ] Add JWT authentication middleware to all `/api` routes
- [ ] Validate Telnyx webhook signatures
- [ ] Add rate limiting (express-rate-limit)
- [ ] Set up Stripe webhook endpoint
- [ ] Test call quality with Telnyx WebRTC
- [ ] Add error boundaries in React for production
- [ ] Remove DevShell nav pills from App.jsx before publishing
